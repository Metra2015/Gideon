import { Link, useLocation } from 'wouter';
import { useHashLocation } from 'wouter/use-hash-location';
import {
  Sidebar, SidebarContent, SidebarFooter, SidebarGroup,
  SidebarGroupLabel, SidebarHeader, SidebarMenu, SidebarMenuButton,
  SidebarMenuItem, SidebarTrigger, useSidebar,
} from '@/components/ui/sidebar';
import {
  LayoutDashboard, Brain, Bot, CheckSquare, FolderOpen, FileSearch,
  Puzzle, Clock, Terminal, Settings, Cpu, Zap, Search, Code
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

const navItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard, group: "core" },
  { href: "/terminal", label: "Terminal", icon: Terminal, group: "core" },
  { href: "/research", label: "Research", icon: Search, group: "intelligence" },
  { href: "/coding", label: "Coding", icon: Code, group: "intelligence" },
  { href: "/memory", label: "Memory", icon: Brain, group: "intelligence" },
  { href: "/agents", label: "Agents", icon: Bot, group: "intelligence" },
  { href: "/tasks", label: "Tasks", icon: CheckSquare, group: "intelligence" },
  { href: "/projects", label: "Projects", icon: FolderOpen, group: "workspace" },
  { href: "/files", label: "File Intel", icon: FileSearch, group: "workspace" },
  { href: "/skills", label: "Skills", icon: Puzzle, group: "workspace" },
  { href: "/schedule", label: "Scheduler", icon: Clock, group: "automation" },
  { href: "/settings", label: "Settings", icon: Settings, group: "system" },
];

export function AppSidebar() {
  const [location] = useHashLocation();
  const { data: status } = useQuery({
    queryKey: ['/api/system/status'],
    refetchInterval: 5000,
  });

  const groups = [
    { key: "core", label: "Core" },
    { key: "intelligence", label: "Intelligence" },
    { key: "workspace", label: "Workspace" },
    { key: "automation", label: "Automation" },
    { key: "system", label: "System" },
  ];

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="p-3 border-b border-border">
        <div className="flex items-center gap-2 px-1">
          <div className="w-7 h-7 rounded bg-primary/20 border border-primary/40 flex items-center justify-center flex-shrink-0">
            <Cpu className="w-4 h-4 text-primary" />
          </div>
          <div className="group-data-[collapsible=icon]:hidden">
            <div className="font-mono font-bold text-sm text-primary text-glow-cyan tracking-widest">GIDEON</div>
            <div className="text-xs text-muted-foreground font-mono">v1.0 — Hermes Ed.</div>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="py-2">
        {groups.map(group => {
          const items = navItems.filter(n => n.group === group.key);
          return (
            <SidebarGroup key={group.key} className="py-1">
              <SidebarGroupLabel className="text-xs font-mono text-muted-foreground/60 uppercase tracking-wider px-3 py-1">
                {group.label}
              </SidebarGroupLabel>
              <SidebarMenu>
                {items.map(item => {
                  const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
                  return (
                    <SidebarMenuItem key={item.href}>
                      <SidebarMenuButton asChild isActive={isActive} tooltip={item.label}>
                        <Link href={item.href}>
                          <item.icon className="w-4 h-4" />
                          <span className="font-medium text-sm">{item.label}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroup>
          );
        })}
      </SidebarContent>

      <SidebarFooter className="p-3 border-t border-border">
        <div className="group-data-[collapsible=icon]:hidden">
          <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
            <span className={`w-2 h-2 rounded-full flex-shrink-0 ${status?.status === 'online' ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
            <span>{status?.status === 'online' ? 'System Online' : 'Offline'}</span>
          </div>
          {status && (
            <div className="mt-1 text-xs text-muted-foreground/50 font-mono">
              {status.agents?.active || 0} active · {status.tasks?.running || 0} running
            </div>
          )}
        </div>
        <div className="group-data-[collapsible=icon]:flex hidden justify-center">
          <span className={`w-2 h-2 rounded-full ${status?.status === 'online' ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
