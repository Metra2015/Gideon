import { SidebarTrigger } from '@/components/ui/sidebar';
import { useHashLocation } from 'wouter/use-hash-location';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import { Zap, Clock, Cpu, Wifi } from 'lucide-react';

const pageTitles: Record<string, string> = {
  "/": "Mission Control",
  "/memory": "Memory System",
  "/agents": "Agent Fleet",
  "/tasks": "Task Planner",
  "/projects": "Project Brain",
  "/files": "File Intelligence",
  "/skills": "Skills Registry",
  "/schedule": "Scheduler",
  "/terminal": "Gideon Terminal",
  "/settings": "Settings",
};

export function TopBar() {
  const [location] = useHashLocation();
  const title = pageTitles[location] || "Gideon";

  const { data: status } = useQuery({
    queryKey: ['/api/system/status'],
    refetchInterval: 5000,
  });

  const { data: llmStatus } = useQuery({
    queryKey: ['/api/llm/status'],
    refetchInterval: 20000,
    staleTime: 15000,
  });

  const now = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="h-12 border-b border-border flex items-center px-4 gap-3 bg-card/50 backdrop-blur-sm flex-shrink-0">
      <SidebarTrigger className="text-muted-foreground hover:text-foreground" />
      <div className="h-4 w-px bg-border" />
      <span className="font-mono font-semibold text-sm text-foreground tracking-wide">{title}</span>

      <div className="ml-auto flex items-center gap-3 text-xs font-mono text-muted-foreground">
        {status && (
          <>
            <div className="flex items-center gap-1.5">
              <Zap className="w-3 h-3 text-primary" />
              <span>{status.agents?.active || 0} active agents</span>
            </div>
            <div className="h-3 w-px bg-border" />
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse" />
              <span>{status.tasks?.running || 0} running</span>
            </div>
            <div className="h-3 w-px bg-border" />
            {llmStatus && (
              <>
                <div className="flex items-center gap-1.5">
                  {(llmStatus as { available?: boolean }).available
                    ? <Cpu className="w-3 h-3 text-green-400" />
                    : <Wifi className="w-3 h-3 text-blue-400" />
                  }
                  <span>{(llmStatus as { available?: boolean }).available ? 'Ollama' : 'Cloud LLM'}</span>
                </div>
                <div className="h-3 w-px bg-border" />
              </>
            )}
            <div className="flex items-center gap-1.5">
              <Clock className="w-3 h-3" />
              <span>{now}</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
