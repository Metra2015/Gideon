import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { FileSearch, Plus, Trash2, Cpu, File, Image, Video, Music, Code, Archive } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { File as GFile } from '@shared/schema';

const typeIcon = (type: string) => {
  const m: Record<string, React.ComponentType<{className?: string}>> = { document:File, image:Image, video:Video, audio:Music, code:Code, archive:Archive };
  const Icon = m[type] || File;
  return <Icon className="w-3.5 h-3.5" />;
};

export default function FilesPage() {
  const { toast } = useToast();
  const [filter, setFilter] = useState('all');
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name:'', path:'', type:'document', size:'', tags:'' });

  const { data: files=[] } = useQuery<GFile[]>({
    queryKey:['/api/files', filter],
    queryFn: ()=>apiRequest('GET',`/api/files${filter!=='all'?`?type=${filter}`:''}`).then(r=>r.json()),
  });

  const addFile = useMutation({
    mutationFn: (d: typeof form) => apiRequest('POST','/api/files',{
      ...d, size:d.size?Number(d.size):undefined,
      tags:JSON.stringify(d.tags.split(',').map(t=>t.trim()).filter(Boolean)),
    }).then(r=>r.json()),
    onSuccess: ()=>{ queryClient.invalidateQueries({queryKey:['/api/files']}); setOpen(false); toast({title:"File registered"}); },
  });

  const indexFile = useMutation({
    mutationFn: (id: number) => apiRequest('POST',`/api/files/${id}/index`).then(r=>r.json()),
    onSuccess: ()=>{ queryClient.invalidateQueries({queryKey:['/api/files']}); toast({title:"File indexed","description":"Added to semantic search index"}); },
  });

  const deleteFile = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE',`/api/files/${id}`).then(r=>r.json()),
    onSuccess: ()=>queryClient.invalidateQueries({queryKey:['/api/files']}),
  });

  const indexed = files.filter(f=>f.indexed).length;

  return (
    <div className="space-y-4 max-w-5xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-mono font-bold text-lg">File Intelligence</h1>
          <p className="text-xs text-muted-foreground font-mono">{files.length} registered · {indexed} indexed</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="font-mono gap-1.5" data-testid="button-add-file"><Plus className="w-3.5 h-3.5" /> Register File</Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader><DialogTitle className="font-mono">Register File</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label className="font-mono text-xs">Filename</Label><Input className="mt-1 font-mono" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} data-testid="input-filename" /></div>
              <div><Label className="font-mono text-xs">Path</Label><Input className="mt-1 font-mono" value={form.path} onChange={e=>setForm(f=>({...f,path:e.target.value}))} placeholder="/path/to/file" data-testid="input-filepath" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="font-mono text-xs">Type</Label>
                  <Select value={form.type} onValueChange={v=>setForm(f=>({...f,type:v}))}>
                    <SelectTrigger className="mt-1" data-testid="select-file-type"><SelectValue /></SelectTrigger>
                    <SelectContent>{['document','image','video','audio','code','archive'].map(t=><SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label className="font-mono text-xs">Size (bytes)</Label><Input type="number" className="mt-1 font-mono" value={form.size} onChange={e=>setForm(f=>({...f,size:e.target.value}))} data-testid="input-size" /></div>
              </div>
              <div><Label className="font-mono text-xs">Tags</Label><Input className="mt-1 font-mono" value={form.tags} onChange={e=>setForm(f=>({...f,tags:e.target.value}))} placeholder="auth, backend, docs" data-testid="input-file-tags" /></div>
              <Button className="w-full font-mono" onClick={()=>addFile.mutate(form)} disabled={!form.name||!form.path} data-testid="button-submit-file">Register</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex gap-1.5">
        {['all','document','code','image','video','audio','archive'].map(t=>(
          <Button key={t} variant={filter===t?'default':'outline'} size="sm" className="font-mono text-xs capitalize" onClick={()=>setFilter(t)} data-testid={`filter-type-${t}`}>{t}</Button>
        ))}
      </div>

      <div className="space-y-2">
        {files.length===0&&<div className="gideon-panel p-8 text-center"><FileSearch className="w-8 h-8 text-muted-foreground mx-auto mb-2"/><p className="text-xs text-muted-foreground font-mono">No files registered yet.</p></div>}
        {files.map(f=>{
          const tags=(() => { try{return JSON.parse(f.tags);}catch{return[];} })();
          return(
            <div key={f.id} className="gideon-panel p-3 hover:border-primary/30 transition-colors" data-testid={`file-card-${f.id}`}>
              <div className="flex items-start gap-3">
                <div className="p-1.5 bg-primary/10 rounded text-primary flex-shrink-0">{typeIcon(f.type)}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-semibold text-sm truncate">{f.name}</span>
                    <span className={`text-xs font-mono px-1.5 py-0.5 rounded ${f.indexed?'bg-green-500/20 text-green-400':'bg-muted text-muted-foreground'}`}>
                      {f.indexed?'indexed':'pending'}
                    </span>
                  </div>
                  <div className="text-xs text-muted-foreground font-mono mt-0.5">{f.path}</div>
                  {f.summary&&<div className="text-xs text-muted-foreground mt-1 line-clamp-1">{f.summary}</div>}
                  <div className="flex items-center gap-2 mt-1.5">
                    {f.size&&<span className="text-xs text-muted-foreground font-mono">{Math.round(f.size/1024)}KB</span>}
                    {tags.slice(0,3).map((t:string)=><span key={t} className="text-xs px-1.5 py-0.5 bg-muted rounded font-mono">{t}</span>)}
                  </div>
                </div>
                <div className="flex gap-1 flex-shrink-0">
                  {!f.indexed&&(
                    <Button variant="ghost" size="icon" className="w-7 h-7 text-cyan-400" onClick={()=>indexFile.mutate(f.id)} data-testid={`button-index-${f.id}`} title="Index file">
                      <Cpu className="w-3.5 h-3.5"/>
                    </Button>
                  )}
                  <Button variant="ghost" size="icon" className="w-7 h-7 text-muted-foreground hover:text-red-400" onClick={()=>deleteFile.mutate(f.id)} data-testid={`button-delete-file-${f.id}`}>
                    <Trash2 className="w-3.5 h-3.5"/>
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
