import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Clock, Plus, Trash2, Play } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { ScheduledJob } from '@shared/schema';

const CRON_PRESETS = [
  { label: 'Every morning 8am', value: '0 8 * * *' },
  { label: 'Every hour', value: '0 * * * *' },
  { label: 'Daily midnight', value: '0 0 * * *' },
  { label: 'Every Monday 9am', value: '0 9 * * 1' },
  { label: 'Every 15 minutes', value: '*/15 * * * *' },
];

const AGENT_TYPES = ['research','coding','automation','orchestrator','vision'];

export default function SchedulePage() {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name:'', description:'', cron:'0 8 * * *', agentType:'research', prompt:'' });

  const { data: jobs=[] } = useQuery<ScheduledJob[]>({ queryKey:['/api/scheduled-jobs'] });

  const createJob = useMutation({
    mutationFn: (d: typeof form) => apiRequest('POST','/api/scheduled-jobs',d).then(r=>r.json()),
    onSuccess: ()=>{ queryClient.invalidateQueries({queryKey:['/api/scheduled-jobs']}); setOpen(false); toast({title:"Job scheduled"}); },
  });

  const toggleJob = useMutation({
    mutationFn: ({ id, enabled }: { id: number; enabled: boolean }) => apiRequest('PATCH',`/api/scheduled-jobs/${id}`,{enabled}).then(r=>r.json()),
    onSuccess: ()=>queryClient.invalidateQueries({queryKey:['/api/scheduled-jobs']}),
  });

  const deleteJob = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE',`/api/scheduled-jobs/${id}`).then(r=>r.json()),
    onSuccess: ()=>queryClient.invalidateQueries({queryKey:['/api/scheduled-jobs']}),
  });

  const active = jobs.filter(j=>j.enabled).length;

  return (
    <div className="space-y-4 max-w-5xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-mono font-bold text-lg">Scheduler</h1>
          <p className="text-xs text-muted-foreground font-mono">{active}/{jobs.length} active jobs</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="font-mono gap-1.5" data-testid="button-new-job"><Plus className="w-3.5 h-3.5" /> Schedule Job</Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader><DialogTitle className="font-mono">Schedule Recurring Job</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label className="font-mono text-xs">Job Name</Label><Input className="mt-1 font-mono" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} placeholder="Morning News Brief" data-testid="input-job-name" /></div>
              <div>
                <Label className="font-mono text-xs">Cron Schedule</Label>
                <div className="flex gap-2 mt-1">
                  <Input className="font-mono flex-1" value={form.cron} onChange={e=>setForm(f=>({...f,cron:e.target.value}))} placeholder="0 8 * * *" data-testid="input-cron" />
                  <Select onValueChange={v=>setForm(f=>({...f,cron:v}))}>
                    <SelectTrigger className="w-40" data-testid="select-cron-preset"><SelectValue placeholder="Presets" /></SelectTrigger>
                    <SelectContent>{CRON_PRESETS.map(p=><SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="font-mono text-xs">Agent Type</Label>
                <Select value={form.agentType} onValueChange={v=>setForm(f=>({...f,agentType:v}))}>
                  <SelectTrigger className="mt-1" data-testid="select-agent-type"><SelectValue /></SelectTrigger>
                  <SelectContent>{AGENT_TYPES.map(t=><SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label className="font-mono text-xs">Prompt / Task</Label><Textarea className="mt-1 font-mono text-xs" rows={3} value={form.prompt} onChange={e=>setForm(f=>({...f,prompt:e.target.value}))} placeholder="Check crypto prices and summarize top movers. Store findings in memory." data-testid="input-job-prompt" /></div>
              <Button className="w-full font-mono" onClick={()=>createJob.mutate(form)} disabled={!form.name||!form.prompt} data-testid="button-submit-job">Schedule Job</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-2">
        {jobs.length===0&&(
          <div className="gideon-panel p-8 text-center">
            <Clock className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-xs text-muted-foreground font-mono">No scheduled jobs. Automate recurring tasks.</p>
          </div>
        )}
        {jobs.map(job=>(
          <div key={job.id} className={`gideon-panel p-3 transition-colors hover:border-primary/30 ${!job.enabled?'opacity-60':''}`} data-testid={`job-card-${job.id}`}>
            <div className="flex items-start gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                  <span className="font-mono font-semibold text-sm">{job.name}</span>
                  <span className="text-xs font-mono px-1.5 py-0.5 bg-cyan-500/10 text-cyan-400 rounded border border-cyan-500/20">{job.agentType}</span>
                </div>
                <div className="flex items-center gap-3 mt-1 text-xs font-mono text-muted-foreground">
                  <span className="bg-muted px-2 py-0.5 rounded">{job.cron}</span>
                  <span>{job.runCount} runs</span>
                  {job.lastRunAt&&<span>last: {new Date(job.lastRunAt).toLocaleDateString()}</span>}
                </div>
                <div className="text-xs text-muted-foreground mt-1 line-clamp-1">{job.prompt}</div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <Switch checked={job.enabled} onCheckedChange={v=>toggleJob.mutate({id:job.id,enabled:v})} data-testid={`toggle-job-${job.id}`} />
                <Button variant="ghost" size="icon" className="w-7 h-7 text-muted-foreground hover:text-red-400" onClick={()=>deleteJob.mutate(job.id)} data-testid={`button-delete-job-${job.id}`}>
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
