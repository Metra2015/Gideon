import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Puzzle, Plus, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Skill } from '@shared/schema';

const catColor: Record<string,string> = {
  research:'bg-cyan-500/20 text-cyan-400', coding:'bg-purple-500/20 text-purple-400',
  automation:'bg-yellow-500/20 text-yellow-400', files:'bg-green-500/20 text-green-400',
  data:'bg-blue-500/20 text-blue-400', finance:'bg-orange-500/20 text-orange-400', general:'bg-muted text-muted-foreground',
};

export default function SkillsPage() {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name:'', description:'', category:'general', agents:'', tools:'', workflows:'' });

  const { data: skills=[] } = useQuery<Skill[]>({ queryKey:['/api/skills'] });

  const createSkill = useMutation({
    mutationFn: (d: typeof form) => apiRequest('POST','/api/skills',{
      ...d,
      agents:JSON.stringify(d.agents.split(',').map(s=>s.trim()).filter(Boolean)),
      tools:JSON.stringify(d.tools.split(',').map(s=>s.trim()).filter(Boolean)),
      workflows:JSON.stringify(d.workflows.split(',').map(s=>s.trim()).filter(Boolean)),
    }).then(r=>r.json()),
    onSuccess: ()=>{ queryClient.invalidateQueries({queryKey:['/api/skills']}); setOpen(false); toast({title:"Skill added"}); },
  });

  const toggleSkill = useMutation({
    mutationFn: ({ id, enabled }: { id: number; enabled: boolean }) => apiRequest('PATCH',`/api/skills/${id}`,{ enabled }).then(r=>r.json()),
    onSuccess: ()=>queryClient.invalidateQueries({queryKey:['/api/skills']}),
  });

  const deleteSkill = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE',`/api/skills/${id}`).then(r=>r.json()),
    onSuccess: ()=>queryClient.invalidateQueries({queryKey:['/api/skills']}),
  });

  const enabled = skills.filter(s=>s.enabled).length;

  return (
    <div className="space-y-4 max-w-5xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-mono font-bold text-lg">Skills Registry</h1>
          <p className="text-xs text-muted-foreground font-mono">{enabled}/{skills.length} enabled</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="font-mono gap-1.5" data-testid="button-new-skill"><Plus className="w-3.5 h-3.5" /> New Skill</Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader><DialogTitle className="font-mono">Add Skill</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label className="font-mono text-xs">Skill Name</Label><Input className="mt-1 font-mono" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} data-testid="input-skill-name" /></div>
              <div><Label className="font-mono text-xs">Description</Label><Textarea className="mt-1 font-mono text-xs" rows={2} value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))} data-testid="input-skill-desc" /></div>
              <div><Label className="font-mono text-xs">Category</Label><Input className="mt-1 font-mono" value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))} data-testid="input-skill-cat" /></div>
              <div><Label className="font-mono text-xs">Agents (comma-sep)</Label><Input className="mt-1 font-mono" value={form.agents} onChange={e=>setForm(f=>({...f,agents:e.target.value}))} placeholder="research, coding" data-testid="input-skill-agents" /></div>
              <div><Label className="font-mono text-xs">Tools (comma-sep)</Label><Input className="mt-1 font-mono" value={form.tools} onChange={e=>setForm(f=>({...f,tools:e.target.value}))} placeholder="search, fetch, analyze" data-testid="input-skill-tools" /></div>
              <Button className="w-full font-mono" onClick={()=>createSkill.mutate(form)} disabled={!form.name} data-testid="button-submit-skill">Add Skill</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {skills.map(skill=>{
          const agents=(() => { try{return JSON.parse(skill.agents);}catch{return[];} })();
          const tools=(() => { try{return JSON.parse(skill.tools);}catch{return[];} })();
          return(
            <div key={skill.id} className={`gideon-panel p-3 transition-colors ${skill.enabled?'hover:border-primary/30':'opacity-60'}`} data-testid={`skill-card-${skill.id}`}>
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <Puzzle className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                    <span className="font-mono font-semibold text-sm">{skill.name}</span>
                    <span className={`text-xs px-1.5 py-0.5 rounded font-mono ${catColor[skill.category]||catColor.general}`}>{skill.category}</span>
                  </div>
                  {skill.description&&<div className="text-xs text-muted-foreground mt-1">{skill.description}</div>}
                  <div className="flex flex-wrap gap-1 mt-2">
                    {agents.map((a:string)=><span key={a} className="text-xs px-1.5 py-0.5 bg-cyan-500/10 text-cyan-400 rounded border border-cyan-500/20 font-mono">{a}</span>)}
                    {tools.slice(0,4).map((t:string)=><span key={t} className="text-xs px-1.5 py-0.5 bg-muted rounded font-mono">{t}</span>)}
                  </div>
                  <div className="text-xs text-muted-foreground font-mono mt-1.5">v{skill.version}</div>
                </div>
                <div className="flex flex-col items-end gap-2 flex-shrink-0">
                  <Switch checked={skill.enabled} onCheckedChange={v=>toggleSkill.mutate({id:skill.id,enabled:v})} data-testid={`toggle-skill-${skill.id}`} />
                  <Button variant="ghost" size="icon" className="w-6 h-6 text-muted-foreground hover:text-red-400" onClick={()=>deleteSkill.mutate(skill.id)} data-testid={`button-delete-skill-${skill.id}`}>
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
