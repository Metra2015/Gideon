import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Bot, Plus, Play, Pause, Trash2, Zap, Activity } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Agent, AgentRun } from '@shared/schema';

const AGENT_TYPES = ['orchestrator','research','coding','automation','vision','data','custom'];
const MODELS = [
  'ollama/qwen2.5-coder:7b','ollama/llama3.2:3b','ollama/llava:7b','ollama/mistral:7b',
  'ollama/deepseek-r1:7b','ollama/gemma3:4b','openai/gpt-4o','anthropic/claude-3-5-sonnet',
];

const typeIcon = (type: string) => {
  const icons: Record<string, string> = {
    orchestrator: '🧠', research: '🔍', coding: '⚙️',
    automation: '🤖', vision: '👁️', data: '📊', custom: '🔧',
  };
  return icons[type] || '🤖';
};

const statusColor: Record<string, string> = {
  active: 'text-green-400 border-green-500/30 bg-green-500/10',
  idle: 'text-muted-foreground border-border bg-muted/30',
  error: 'text-red-400 border-red-500/30 bg-red-500/10',
  paused: 'text-yellow-400 border-yellow-500/30 bg-yellow-500/10',
};

export default function AgentsPage() {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', type: 'research', model: 'ollama/llama3.2:3b', capabilities: '', config: '{}' });
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);

  const { data: agents = [] } = useQuery<Agent[]>({ queryKey: ['/api/agents'] });
  const { data: runs = [] } = useQuery<AgentRun[]>({
    queryKey: ['/api/agent-runs', selectedAgent?.id],
    queryFn: () => apiRequest('GET', `/api/agent-runs${selectedAgent ? `?agentId=${selectedAgent.id}` : ''}`).then(r => r.json()),
  });

  const createAgent = useMutation({
    mutationFn: (data: typeof form) => apiRequest('POST', '/api/agents', {
      ...data,
      capabilities: JSON.stringify(data.capabilities.split(',').map(c => c.trim()).filter(Boolean)),
    }).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/agents'] });
      setOpen(false);
      setForm({ name: '', type: 'research', model: 'ollama/llama3.2:3b', capabilities: '', config: '{}' });
      toast({ title: "Agent spawned", description: "New agent registered in Hermes runtime" });
    },
  });

  const activateAgent = useMutation({
    mutationFn: (id: number) => apiRequest('POST', `/api/agents/${id}/activate`).then(r => r.json()),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/agents'] }),
  });

  const deactivateAgent = useMutation({
    mutationFn: (id: number) => apiRequest('POST', `/api/agents/${id}/deactivate`).then(r => r.json()),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/agents'] }),
  });

  const deleteAgent = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE', `/api/agents/${id}`).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/agents'] });
      if (selectedAgent) setSelectedAgent(null);
    },
  });

  const stats = {
    active: agents.filter(a => a.status === 'active').length,
    idle: agents.filter(a => a.status === 'idle').length,
    total: agents.length,
    totalRuns: agents.reduce((s, a) => s + a.taskCount, 0),
  };

  return (
    <div className="space-y-4 max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-mono font-bold text-lg">Agent Fleet</h1>
          <p className="text-xs text-muted-foreground font-mono">{stats.active} active · {stats.idle} idle · {stats.totalRuns} total runs</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="font-mono gap-1.5" data-testid="button-spawn-agent">
              <Plus className="w-3.5 h-3.5" /> Spawn Agent
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle className="font-mono">Spawn New Agent</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div>
                <Label className="font-mono text-xs">Agent Name</Label>
                <Input className="mt-1 font-mono" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Prometheus" data-testid="input-agent-name" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="font-mono text-xs">Type</Label>
                  <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v }))}>
                    <SelectTrigger className="mt-1" data-testid="select-agent-type"><SelectValue /></SelectTrigger>
                    <SelectContent>{AGENT_TYPES.map(t => <SelectItem key={t} value={t}>{typeIcon(t)} {t}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="font-mono text-xs">Model</Label>
                  <Select value={form.model} onValueChange={v => setForm(f => ({ ...f, model: v }))}>
                    <SelectTrigger className="mt-1" data-testid="select-agent-model"><SelectValue /></SelectTrigger>
                    <SelectContent>{MODELS.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="font-mono text-xs">Capabilities (comma-separated)</Label>
                <Input className="mt-1 font-mono" value={form.capabilities} onChange={e => setForm(f => ({ ...f, capabilities: e.target.value }))} placeholder="search, summarize, analyze" data-testid="input-capabilities" />
              </div>
              <Button className="w-full font-mono" onClick={() => createAgent.mutate(form)} disabled={!form.name} data-testid="button-submit-agent">
                Spawn Agent
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Agent Grid */}
        <div className="space-y-2">
          {agents.map(agent => {
            const caps = (() => { try { return JSON.parse(agent.capabilities); } catch { return []; } })();
            return (
              <div key={agent.id}
                className={`gideon-panel p-3 cursor-pointer hover:border-primary/40 transition-colors ${selectedAgent?.id === agent.id ? 'border-primary/60' : ''}`}
                onClick={() => setSelectedAgent(agent)} data-testid={`agent-card-${agent.id}`}>
                <div className="flex items-start gap-3">
                  <div className="text-xl flex-shrink-0">{typeIcon(agent.type)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-sm">{agent.name}</span>
                      <span className={`text-xs px-1.5 py-0.5 rounded border font-mono ${statusColor[agent.status] || statusColor.idle}`}>
                        {agent.status}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground font-mono mt-0.5">{agent.model}</div>
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {caps.slice(0,4).map((c: string) => (
                        <span key={c} className="text-xs px-1.5 py-0.5 bg-muted rounded font-mono">{c}</span>
                      ))}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1 flex-shrink-0">
                    <div className="text-xs font-mono text-muted-foreground">{agent.taskCount} runs</div>
                    <div className="flex gap-1">
                      {agent.status === 'idle' ? (
                        <Button variant="ghost" size="icon" className="w-6 h-6 text-green-400" onClick={e => { e.stopPropagation(); activateAgent.mutate(agent.id); }} data-testid={`button-activate-${agent.id}`}>
                          <Play className="w-3 h-3" />
                        </Button>
                      ) : (
                        <Button variant="ghost" size="icon" className="w-6 h-6 text-yellow-400" onClick={e => { e.stopPropagation(); deactivateAgent.mutate(agent.id); }} data-testid={`button-deactivate-${agent.id}`}>
                          <Pause className="w-3 h-3" />
                        </Button>
                      )}
                      <Button variant="ghost" size="icon" className="w-6 h-6 text-muted-foreground hover:text-red-400" onClick={e => { e.stopPropagation(); deleteAgent.mutate(agent.id); }} data-testid={`button-delete-agent-${agent.id}`}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Agent Detail Panel */}
        <div className="gideon-panel">
          {!selectedAgent ? (
            <div className="p-8 text-center">
              <Bot className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-xs text-muted-foreground font-mono">Select an agent to view details</p>
            </div>
          ) : (
            <>
              <div className="gideon-panel-header">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{typeIcon(selectedAgent.type)}</span>
                  <span className="font-mono font-bold">{selectedAgent.name}</span>
                </div>
                <span className={`text-xs px-1.5 py-0.5 rounded border font-mono ${statusColor[selectedAgent.status] || statusColor.idle}`}>
                  {selectedAgent.status}
                </span>
              </div>
              <div className="p-4 space-y-4">
                <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                  <div><span className="text-muted-foreground">Model: </span>{selectedAgent.model}</div>
                  <div><span className="text-muted-foreground">Type: </span>{selectedAgent.type}</div>
                  <div><span className="text-muted-foreground">Task count: </span>{selectedAgent.taskCount}</div>
                  <div><span className="text-muted-foreground">ID: </span>#{selectedAgent.id}</div>
                </div>
                <div>
                  <div className="text-xs font-mono text-muted-foreground mb-1.5">CAPABILITIES</div>
                  <div className="flex flex-wrap gap-1">
                    {(() => { try { return JSON.parse(selectedAgent.capabilities); } catch { return []; } })().map((c: string) => (
                      <span key={c} className="text-xs px-2 py-1 bg-primary/10 text-primary rounded font-mono border border-primary/20">{c}</span>
                    ))}
                  </div>
                </div>
                <div>
                  <div className="text-xs font-mono text-muted-foreground mb-1.5">RECENT RUNS</div>
                  {runs.slice(0,5).length === 0 ? (
                    <p className="text-xs text-muted-foreground font-mono">No runs yet</p>
                  ) : (
                    <div className="space-y-1.5">
                      {runs.slice(0,5).map(run => (
                        <div key={run.id} className="flex items-center gap-2 text-xs font-mono p-1.5 bg-muted/30 rounded">
                          <span className={run.status === 'completed' ? 'text-green-400' : run.status === 'failed' ? 'text-red-400' : 'text-yellow-400'}>●</span>
                          <span className="flex-1 truncate">{run.input.slice(0,40)}...</span>
                          <span className="text-muted-foreground">{run.durationMs ? `${run.durationMs}ms` : '—'}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
