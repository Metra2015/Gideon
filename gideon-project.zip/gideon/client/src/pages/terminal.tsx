import { useState, useRef, useEffect, useCallback } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Terminal as TermIcon, Trash2, Send, Zap, Cpu, Wifi, WifiOff } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Conversation } from '@shared/schema';

interface Message {
  role: 'user' | 'assistant' | 'system' | 'error';
  content: string;
  ts: string;
  source?: string;
  streaming?: boolean;
}

const API_BASE = (window as unknown as { __PORT_5000__?: string }).__PORT_5000__ || '';

const SUGGESTIONS = [
  "Explain how you would build a JWT authentication system in Node.js",
  "Research the best local LLM models for coding tasks in 2026",
  "Write a Python script to monitor CPU and memory usage every 5 seconds",
  "How would you design a vector database for semantic memory search?",
  "Create a detailed plan to set up a self-hosted CI/CD pipeline with Docker",
  "What is the best architecture for a real-time chat app using WebSockets?",
];

export default function TerminalPage() {
  const { toast } = useToast();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'system',
      content: '╔══════════════════════════════════════════════╗\n║        GIDEON CORE v1.0 — ONLINE             ║\n║   Hermes Edition · Memory + LLM Active       ║\n╚══════════════════════════════════════════════╝\n\nConnecting to LLM engine...',
      ts: new Date().toISOString(),
    },
  ]);
  const [convId, setConvId] = useState<number | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [llmSource, setLlmSource] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // LLM status check
  const { data: llmStatus } = useQuery({
    queryKey: ['/api/llm/status'],
    refetchInterval: 15000,
    staleTime: 10000,
  });

  // Update intro message once LLM status known
  useEffect(() => {
    if (!llmStatus) return;
    const status = llmStatus as { available?: boolean; models?: string[]; fallback?: string | null; ollamaUrl?: string };
    const modelInfo = status.available
      ? `Ollama connected at ${status.ollamaUrl}\nModels: ${(status.models || []).slice(0, 4).join(', ') || 'none loaded'}`
      : `Ollama offline — using ${status.fallback || 'cloud'} fallback\nSet Ollama URL in Settings to use local models`;

    setMessages(prev => [{
      ...prev[0],
      content: `╔══════════════════════════════════════════════╗\n║        GIDEON CORE v1.0 — ONLINE             ║\n║   Hermes Edition · Memory + LLM Active       ║\n╚══════════════════════════════════════════════╝\n\n${modelInfo}\n\nType any task, question, or command.\nGideon will reason, plan, and respond with full context.`,
    }, ...prev.slice(1)]);
  }, [llmStatus]);

  const initConv = useMutation({
    mutationFn: () => apiRequest('POST', '/api/conversations', {
      title: 'Terminal Session', messages: '[]',
    }).then(r => r.json()),
    onSuccess: (data: Conversation) => setConvId(data.id),
  });

  const handleSend = useCallback(async () => {
    if (!input.trim() || isStreaming) return;
    const text = input.trim();
    setInput('');

    // Add user message
    setMessages(prev => [...prev, { role: 'user', content: `> ${text}`, ts: new Date().toISOString() }]);

    // Ensure conversation exists
    let currentConvId = convId;
    if (!currentConvId) {
      try {
        const conv = await apiRequest('POST', '/api/conversations', { title: text.slice(0, 50), messages: '[]' }).then(r => r.json());
        currentConvId = conv.id;
        setConvId(conv.id);
        // Store user message in conv
        await apiRequest('POST', `/api/conversations/${conv.id}/messages`, { role: 'user', content: text });
      } catch {
        // continue anyway
      }
    }

    // Get the orchestrator agent for attribution
    const agentsResp = await apiRequest('GET', '/api/agents').then(r => r.json()).catch(() => []);
    const orchestrator = agentsResp.find((a: { type: string; id: number }) => a.type === 'orchestrator');

    // Build message history from current conversation
    const history = messages
      .filter(m => m.role === 'user' || m.role === 'assistant')
      .slice(-10)
      .map(m => ({
        role: m.role as 'user' | 'assistant',
        content: m.role === 'user' ? m.content.replace(/^> /, '') : m.content,
      }));
    history.push({ role: 'user', content: text });

    // Add placeholder streaming message
    const streamingIdx = messages.length + 1;
    setMessages(prev => [...prev, { role: 'assistant', content: '', ts: new Date().toISOString(), streaming: true }]);
    setIsStreaming(true);

    abortRef.current = new AbortController();

    try {
      const response = await fetch(`${API_BASE}/api/llm/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: history,
          conversationId: currentConvId,
          agentId: orchestrator?.id,
        }),
        signal: abortRef.current.signal,
      });

      if (!response.ok || !response.body) throw new Error(`HTTP ${response.status}`);

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let accumulated = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          try {
            const data = JSON.parse(line.slice(6)) as {
              text?: string; done?: boolean; source?: string; error?: string; tokensUsed?: number;
            };
            if (data.error) {
              setMessages(prev => {
                const updated = [...prev];
                const last = updated[updated.length - 1];
                if (last.streaming) updated[updated.length - 1] = { ...last, content: `Error: ${data.error}`, streaming: false, role: 'error' };
                return updated;
              });
              break;
            }
            if (data.text) {
              accumulated += data.text;
              setMessages(prev => {
                const updated = [...prev];
                const last = updated[updated.length - 1];
                if (last.streaming) updated[updated.length - 1] = { ...last, content: accumulated };
                return updated;
              });
            }
            if (data.source) setLlmSource(data.source);
            if (data.done && !data.text) {
              setMessages(prev => {
                const updated = [...prev];
                const last = updated[updated.length - 1];
                if (last.streaming) {
                  updated[updated.length - 1] = {
                    ...last,
                    streaming: false,
                    source: data.source,
                  };
                }
                return updated;
              });
            }
          } catch {
            // malformed JSON chunk
          }
        }
      }
    } catch (err: unknown) {
      if ((err as Error)?.name !== 'AbortError') {
        setMessages(prev => {
          const updated = [...prev];
          const last = updated[updated.length - 1];
          if (last.streaming) {
            updated[updated.length - 1] = {
              ...last,
              content: `Connection error: ${(err as Error).message || 'Unknown error'}. Check server status.`,
              streaming: false,
              role: 'error',
            };
          }
          return updated;
        });
      }
    } finally {
      setIsStreaming(false);
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/memories'] });
      queryClient.invalidateQueries({ queryKey: ['/api/agents'] });
      queryClient.invalidateQueries({ queryKey: ['/api/system/status'] });
      inputRef.current?.focus();
    }
  }, [input, isStreaming, convId, messages]);

  const handleStop = () => {
    abortRef.current?.abort();
    setIsStreaming(false);
    setMessages(prev => {
      const updated = [...prev];
      const last = updated[updated.length - 1];
      if (last.streaming) updated[updated.length - 1] = { ...last, streaming: false };
      return updated;
    });
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
    if (e.key === 'Escape' && isStreaming) handleStop();
  };

  const status = llmStatus as { available?: boolean; models?: string[]; fallback?: string } | undefined;
  const modelLabel = status?.available
    ? `Ollama · ${(status.models || [])[0]?.split(':')[0] || 'local'}`
    : `Cloud · ${status?.fallback || 'anthropic'}`;

  const roleStyle = (role: string) => {
    if (role === 'user') return 'text-cyan-400';
    if (role === 'assistant') return 'text-emerald-400';
    if (role === 'error') return 'text-red-400';
    return 'text-muted-foreground';
  };

  return (
    <div className="flex flex-col h-full max-h-[calc(100vh-8rem)] max-w-5xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <TermIcon className="w-4 h-4 text-primary" />
          <span className="font-mono font-bold text-lg">Gideon Terminal</span>
          <span className="gideon-status-dot status-active animate-pulse-glow ml-1" />
        </div>
        <div className="flex items-center gap-3">
          {/* LLM source indicator */}
          <div className="flex items-center gap-1.5 text-xs font-mono text-muted-foreground">
            {status?.available
              ? <Cpu className="w-3 h-3 text-green-400" />
              : <Wifi className="w-3 h-3 text-blue-400" />
            }
            <span>{modelLabel}</span>
          </div>
          {isStreaming && (
            <Button variant="outline" size="sm" className="font-mono text-xs h-7 text-red-400 border-red-500/30" onClick={handleStop} data-testid="button-stop">
              Stop
            </Button>
          )}
          <Button variant="ghost" size="icon" className="w-7 h-7 text-muted-foreground" onClick={() => {
            setMessages([messages[0]]);
            setConvId(null);
          }} data-testid="button-clear">
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* Terminal output */}
      <div
        className="flex-1 terminal-surface border border-border rounded-md p-4 overflow-y-auto font-mono text-xs leading-relaxed mb-3 min-h-0"
        data-testid="terminal-output"
        onClick={() => inputRef.current?.focus()}
      >
        {messages.map((msg, i) => (
          <div key={i} className={`mb-4 ${roleStyle(msg.role)}`}>
            {msg.role !== 'system' && (
              <div className="flex items-center gap-2 text-muted-foreground/40 text-xs mb-1">
                <span>{new Date(msg.ts).toLocaleTimeString()}</span>
                {msg.source && <span className="px-1 py-0.5 bg-muted/30 rounded">{msg.source}</span>}
              </div>
            )}
            <div className="whitespace-pre-wrap leading-relaxed">{msg.content}</div>
            {msg.streaming && (
              <span className="inline-block w-2 h-3.5 bg-primary animate-pulse ml-0.5 align-middle" />
            )}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Suggestions */}
      {messages.length <= 2 && (
        <div className="mb-2 grid grid-cols-1 md:grid-cols-2 gap-1.5">
          {SUGGESTIONS.slice(0, 4).map((s, i) => (
            <button
              key={i}
              className="text-xs font-mono px-3 py-2 bg-muted/30 hover:bg-primary/10 hover:text-primary border border-border hover:border-primary/30 rounded transition-colors text-muted-foreground text-left truncate"
              onClick={() => { setInput(s); inputRef.current?.focus(); }}
              data-testid={`suggestion-${i}`}
            >
              {s}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div className="flex gap-2" data-testid="terminal-input-area">
        <div className="flex-1 flex items-center gap-2 bg-muted/30 border border-border rounded-md px-3 focus-within:border-primary/50 transition-colors">
          <span className="text-primary font-mono text-sm flex-shrink-0">{'>'}</span>
          <Input
            ref={inputRef}
            className="border-0 bg-transparent font-mono text-sm focus-visible:ring-0 p-0 h-10"
            placeholder={isStreaming ? 'Gideon is thinking... (Esc to stop)' : 'Enter any task, question, or command...'}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKey}
            disabled={isStreaming}
            data-testid="terminal-input"
          />
        </div>
        <Button
          className="font-mono gap-1.5"
          onClick={handleSend}
          disabled={!input.trim() || isStreaming}
          data-testid="button-send"
        >
          <Send className="w-3.5 h-3.5" />
          {isStreaming ? 'Thinking...' : 'Send'}
        </Button>
      </div>

      <div className="text-xs text-muted-foreground/40 font-mono text-center mt-1.5">
        Enter to send · Esc to stop · Responses stored in episodic memory
      </div>
    </div>
  );
}
