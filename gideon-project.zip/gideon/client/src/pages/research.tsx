/**
 * Research — Atlas Agent UI
 *
 * Sections:
 *   1. Query input + pipeline controls
 *   2. Live SSE pipeline progress (7 steps)
 *   3. Sources panel (URLs, titles, indexed status)
 *   4. Insights cards (ranked, categorized)
 *   5. Synthesis summary
 *   6. Qdrant semantic search panel
 *   7. Vector store stats
 */

import { useState, useRef, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import {
  Search, BookOpen, ExternalLink, Database, Zap, CheckCircle2,
  Loader2, Brain, Globe, Star, Tag, Clock, BarChart3, Trash2,
  ChevronRight, AlertCircle, Sparkles, FileText, Code, Info,
  ArrowRight, RefreshCw, Key
} from "lucide-react";

// ── Types ──────────────────────────────────────────────────────────────
interface ResearchInsight {
  title: string;
  content: string;
  relevance: number;
  category: "fact" | "insight" | "code" | "summary" | "process";
  sourceUrl: string;
  sourceTitle: string;
  tags: string[];
}

interface ResearchSource {
  url: string;
  title: string;
  indexed: boolean;
}

interface ResearchResult {
  query: string;
  subQueries: string[];
  sources: ResearchSource[];
  insights: ResearchInsight[];
  summary: string;
  memoryIds: number[];
  qdrantIds: string[];
  projectLogId?: number;
  durationMs: number;
  model: string;
}

interface PipelineStep {
  step: number;
  label: string;
  status: "pending" | "active" | "completed" | "error";
  detail?: string;
}

interface QdrantPoint {
  id: string;
  title: string;
  content: string;
  source_url?: string;
  source_title?: string;
  category: string;
  tags: string[];
  importance: number;
  created_at: string;
}

interface QdrantStats {
  total: number;
  categories: Record<string, number>;
  status: string;
}

// ── Constants ──────────────────────────────────────────────────────────
const PIPELINE_STEPS = [
  { step: 1, label: "Decomposing query into sub-queries" },
  { step: 2, label: "Scraping sources via Firecrawl" },
  { step: 3, label: "Extracting insights per source" },
  { step: 4, label: "Ranking & deduplicating insights" },
  { step: 5, label: "Generating synthesis summary" },
  { step: 6, label: "Storing to SQLite + Qdrant vectors" },
  { step: 7, label: "Logging to Project Brain" },
];

const CATEGORY_CONFIG: Record<string, { icon: typeof FileText; color: string; label: string }> = {
  fact:     { icon: CheckCircle2, color: "text-blue-400",   label: "Fact" },
  insight:  { icon: Sparkles,     color: "text-purple-400", label: "Insight" },
  code:     { icon: Code,         color: "text-green-400",  label: "Code" },
  summary:  { icon: FileText,     color: "text-yellow-400", label: "Summary" },
  process:  { icon: ArrowRight,   color: "text-orange-400", label: "Process" },
};

// ── Helpers ────────────────────────────────────────────────────────────
function RelevanceDots({ score }: { score: number }) {
  return (
    <div className="flex gap-0.5 items-center" title={`Relevance: ${score}/10`}>
      {Array.from({ length: 10 }, (_, i) => (
        <div
          key={i}
          className={`w-1.5 h-1.5 rounded-full ${i < score ? "bg-primary" : "bg-muted"}`}
        />
      ))}
      <span className="ml-1 text-xs text-muted-foreground font-mono">{score}/10</span>
    </div>
  );
}

function CategoryBadge({ category }: { category: string }) {
  const cfg = CATEGORY_CONFIG[category] || { icon: Info, color: "text-muted-foreground", label: category };
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-mono ${cfg.color}`}>
      <Icon className="w-3 h-3" />
      {cfg.label}
    </span>
  );
}

// ── Main Component ─────────────────────────────────────────────────────
export default function Research() {
  const { toast } = useToast();
  const qc = useQueryClient();

  // Input state
  const [query, setQuery]                 = useState("");
  const [firecrawlKey, setFirecrawlKey]   = useState("");
  const [showKeyInput, setShowKeyInput]   = useState(false);
  const [maxSources, setMaxSources]       = useState(5);

  // Pipeline state
  const [isRunning, setIsRunning]         = useState(false);
  const [steps, setSteps]                 = useState<PipelineStep[]>([]);
  const [result, setResult]               = useState<ResearchResult | null>(null);
  const [activeTab, setActiveTab]         = useState("pipeline");

  // Semantic search state
  const [searchQuery, setSearchQuery]     = useState("");
  const [searchResults, setSearchResults] = useState<QdrantPoint[]>([]);
  const [isSearching, setIsSearching]     = useState(false);

  const eventSourceRef = useRef<EventSource | null>(null);

  // ── Qdrant stats ────────────────────────────────────────────────────
  const { data: qdrantStats, refetch: refetchStats } = useQuery<QdrantStats>({
    queryKey: ["/api/qdrant/stats"],
    refetchInterval: 10000,
  });

  // ── Run research via SSE ────────────────────────────────────────────
  const runResearch = useCallback(async () => {
    if (!query.trim() || isRunning) return;

    setIsRunning(true);
    setResult(null);
    setActiveTab("pipeline");

    // Initialize pipeline steps as pending
    setSteps(PIPELINE_STEPS.map(s => ({ ...s, status: "pending" as const })));

    // Close any existing EventSource
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    // POST to SSE endpoint
    try {
      const res = await fetch("/api/hermes/research/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: query.trim(),
          maxSources,
          firecrawlKey: firecrawlKey || undefined,
        }),
      });

      if (!res.ok || !res.body) {
        throw new Error(`HTTP ${res.status}`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      const processSSE = async () => {
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop() || "";

            for (const line of lines) {
              if (!line.trim() || !line.startsWith("data:")) continue;
              const jsonStr = line.slice(5).trim();
              if (!jsonStr) continue;

              try {
                const evt = JSON.parse(jsonStr) as {
                  event?: string;
                  step?: number;
                  total?: number;
                  message?: string;
                  detail?: string;
                  queries?: string[];
                  sources?: ResearchSource[];
                  insights?: ResearchInsight[];
                  summary?: string;
                  memoryIds?: number[];
                  qdrantIds?: string[];
                  projectLogId?: number;
                  durationMs?: number;
                  model?: string;
                  query?: string;
                  subQueries?: string[];
                  vectors?: number;
                  memories?: number;
                  error?: string;
                };

                const eventType = evt.event;

                if (eventType === "status" && evt.step !== undefined) {
                  const stepNum = evt.step;
                  setSteps(prev => prev.map(s => {
                    if (s.step === stepNum) return { ...s, status: "active", detail: evt.message };
                    if (s.step < stepNum) return { ...s, status: "completed" };
                    return s;
                  }));
                }

                if (eventType === "decomposed" && evt.queries) {
                  setSteps(prev => prev.map(s =>
                    s.step === 1 ? { ...s, status: "completed", detail: `${evt.queries!.length} sub-queries` } : s
                  ));
                }

                if (eventType === "scraped" && evt.sources) {
                  setSteps(prev => prev.map(s =>
                    s.step === 2 ? { ...s, status: "completed", detail: `${evt.sources!.length} sources` } : s
                  ));
                }

                if (eventType === "insights" && evt.insights) {
                  setSteps(prev => prev.map(s =>
                    s.step === 3 ? { ...s, status: "completed", detail: `${evt.insights!.length} insights extracted` } : s
                  ));
                }

                if (eventType === "summary" && evt.summary) {
                  setSteps(prev => prev.map(s =>
                    s.step === 5 ? { ...s, status: "completed", detail: "synthesis complete" } : s
                  ));
                }

                if (eventType === "stored") {
                  setSteps(prev => prev.map(s =>
                    s.step === 6 ? { ...s, status: "completed", detail: `${evt.vectors || 0} vectors stored` } : s
                  ));
                  refetchStats();
                }

                if (eventType === "complete") {
                  // Mark all steps complete
                  setSteps(prev => prev.map(s => ({ ...s, status: "completed" as const })));

                  // Build result object from event
                  const finalResult: ResearchResult = {
                    query: evt.query || query,
                    subQueries: evt.subQueries || [],
                    sources: evt.sources || [],
                    insights: evt.insights || [],
                    summary: evt.summary || "",
                    memoryIds: evt.memoryIds || [],
                    qdrantIds: evt.qdrantIds || [],
                    projectLogId: evt.projectLogId,
                    durationMs: evt.durationMs || 0,
                    model: evt.model || "unknown",
                  };
                  setResult(finalResult);
                  setIsRunning(false);
                  setActiveTab("insights");
                  refetchStats();
                  toast({
                    title: "Research Complete",
                    description: `${finalResult.insights.length} insights · ${finalResult.qdrantIds.length} vectors stored`,
                  });
                }

                if (eventType === "error") {
                  setSteps(prev => prev.map(s =>
                    s.status === "active" ? { ...s, status: "error", detail: evt.error } : s
                  ));
                  setIsRunning(false);
                  toast({ title: "Research Error", description: evt.error, variant: "destructive" });
                }
              } catch {
                // skip malformed JSON
              }
            }
          }
        } catch (err) {
          console.error("[Research UI] SSE read error:", err);
          setIsRunning(false);
        }
      };

      await processSSE();
    } catch (err) {
      console.error("[Research UI] fetch error:", err);
      setIsRunning(false);
      toast({
        title: "Connection Error",
        description: "Could not reach the Atlas pipeline. Is the server running?",
        variant: "destructive",
      });
    }
  }, [query, maxSources, firecrawlKey, isRunning, toast, refetchStats]);

  // ── Qdrant semantic search ──────────────────────────────────────────
  const runSemanticSearch = useCallback(async () => {
    if (!searchQuery.trim() || isSearching) return;
    setIsSearching(true);
    try {
      const res = await apiRequest("GET", `/api/qdrant/search?q=${encodeURIComponent(searchQuery)}&limit=8`);
      const data = await res.json() as { results: QdrantPoint[] };
      setSearchResults(data.results || []);
    } catch (err) {
      toast({ title: "Search Failed", description: String(err), variant: "destructive" });
    } finally {
      setIsSearching(false);
    }
  }, [searchQuery, isSearching, toast]);

  // ── Delete a Qdrant vector ──────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/qdrant/${id}`),
    onSuccess: () => {
      refetchStats();
      toast({ title: "Vector deleted" });
    },
  });

  // ── Pipeline step renderer ──────────────────────────────────────────
  const renderPipelineStep = (step: PipelineStep) => {
    const icons = {
      pending:   <div className="w-5 h-5 rounded-full border border-border flex-shrink-0" />,
      active:    <Loader2 className="w-5 h-5 text-primary animate-spin flex-shrink-0" />,
      completed: <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />,
      error:     <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0" />,
    };

    return (
      <div
        key={step.step}
        data-testid={`pipeline-step-${step.step}`}
        className={`flex items-start gap-3 p-3 rounded-lg transition-all ${
          step.status === "active"    ? "bg-primary/10 border border-primary/30" :
          step.status === "completed" ? "bg-muted/30" :
          step.status === "error"     ? "bg-destructive/10 border border-destructive/30" :
          "opacity-40"
        }`}
      >
        {icons[step.status]}
        <div className="flex-1 min-w-0">
          <div className={`text-sm font-medium font-mono ${
            step.status === "pending" ? "text-muted-foreground" : "text-foreground"
          }`}>
            <span className="text-muted-foreground/60 mr-2">{String(step.step).padStart(2, "0")}.</span>
            {step.label}
          </div>
          {step.detail && (
            <div className="text-xs text-muted-foreground mt-0.5 font-mono">{step.detail}</div>
          )}
        </div>
      </div>
    );
  };

  // ── Insight card ────────────────────────────────────────────────────
  const renderInsight = (insight: ResearchInsight, idx: number) => (
    <Card
      key={idx}
      data-testid={`insight-card-${idx}`}
      className="bg-card border-border hover:border-primary/40 transition-colors"
    >
      <CardContent className="p-4 space-y-3">
        {/* Header */}
        <div className="flex items-start justify-between gap-2">
          <h4 className="text-sm font-semibold leading-snug flex-1">{insight.title}</h4>
          <CategoryBadge category={insight.category} />
        </div>

        {/* Content */}
        <p className="text-sm text-muted-foreground leading-relaxed">{insight.content}</p>

        {/* Footer */}
        <div className="space-y-2 pt-1">
          <RelevanceDots score={insight.relevance} />
          <div className="flex flex-wrap gap-1">
            {insight.tags.map(tag => (
              <Badge key={tag} variant="outline" className="text-xs font-mono py-0 px-1.5">
                <Tag className="w-2.5 h-2.5 mr-1" />{tag}
              </Badge>
            ))}
          </div>
          <a
            href={insight.sourceUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs text-primary/70 hover:text-primary transition-colors font-mono"
          >
            <ExternalLink className="w-3 h-3" />
            {insight.sourceTitle.slice(0, 50)}
          </a>
        </div>
      </CardContent>
    </Card>
  );

  // ── Qdrant result card ──────────────────────────────────────────────
  const renderQdrantResult = (pt: QdrantPoint, idx: number) => (
    <Card
      key={pt.id}
      data-testid={`qdrant-result-${idx}`}
      className="bg-card border-border"
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold mb-1">{pt.title}</div>
            <CategoryBadge category={pt.category} />
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <span className="flex items-center gap-1 text-xs text-muted-foreground font-mono">
              <Star className="w-3 h-3" />{pt.importance}
            </span>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 text-muted-foreground hover:text-destructive"
              onClick={() => deleteMutation.mutate(pt.id)}
              data-testid={`delete-vector-${idx}`}
            >
              <Trash2 className="w-3 h-3" />
            </Button>
          </div>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed mb-2">{pt.content.slice(0, 200)}...</p>
        <div className="flex flex-wrap gap-1 mb-2">
          {pt.tags?.slice(0, 4).map(tag => (
            <Badge key={tag} variant="outline" className="text-xs py-0 px-1.5">{tag}</Badge>
          ))}
        </div>
        {pt.source_url && (
          <a
            href={pt.source_url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 text-xs text-primary/70 hover:text-primary font-mono"
          >
            <Globe className="w-3 h-3" />{pt.source_url.slice(0, 60)}
          </a>
        )}
        <div className="text-xs text-muted-foreground/40 font-mono mt-1">
          {new Date(pt.created_at).toLocaleDateString()}
        </div>
      </CardContent>
    </Card>
  );

  // ── Render ──────────────────────────────────────────────────────────
  const completedSteps = steps.filter(s => s.status === "completed").length;
  const progress = steps.length > 0 ? (completedSteps / steps.length) * 100 : 0;

  return (
    <div className="flex flex-col gap-6 max-w-7xl mx-auto" data-testid="research-page">

      {/* ── Header ── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-primary/20 border border-primary/40 flex items-center justify-center">
            <Search className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-lg font-bold font-mono tracking-wide">Atlas Research Agent</h1>
            <p className="text-xs text-muted-foreground font-mono">Firecrawl · Qdrant · Project Brain</p>
          </div>
        </div>

        {/* Stats bar */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
            <Database className={`w-3.5 h-3.5 ${qdrantStats?.status === "online" ? "text-green-500" : "text-red-500"}`} />
            <span className={qdrantStats?.status === "online" ? "text-green-500" : "text-red-500"}>
              Qdrant {qdrantStats?.status || "connecting..."}
            </span>
          </div>
          {qdrantStats && qdrantStats.total > 0 && (
            <Badge variant="outline" className="font-mono text-xs">
              <Brain className="w-3 h-3 mr-1" />
              {qdrantStats.total} vectors
            </Badge>
          )}
        </div>
      </div>

      {/* ── Query Input ── */}
      <Card className="bg-card border-border" data-testid="query-card">
        <CardContent className="p-4 space-y-3">
          <div className="flex gap-3">
            <div className="flex-1">
              <Textarea
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Describe what you want to research… e.g. 'How do transformer models handle long-context reasoning?'"
                className="font-mono text-sm resize-none min-h-[72px] bg-background"
                data-testid="input-query"
                onKeyDown={e => {
                  if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) runResearch();
                }}
              />
            </div>
            <Button
              onClick={runResearch}
              disabled={isRunning || !query.trim()}
              className="h-auto px-6 font-mono"
              data-testid="button-run-research"
            >
              {isRunning ? (
                <><Loader2 className="w-4 h-4 animate-spin mr-2" />Running</>
              ) : (
                <><Zap className="w-4 h-4 mr-2" />Run Atlas</>
              )}
            </Button>
          </div>

          {/* Controls row */}
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-muted-foreground">Max sources:</span>
              <div className="flex gap-1">
                {[3, 5, 8, 12].map(n => (
                  <Button
                    key={n}
                    variant={maxSources === n ? "default" : "outline"}
                    size="sm"
                    className="h-6 w-8 text-xs font-mono px-0"
                    onClick={() => setMaxSources(n)}
                    data-testid={`button-sources-${n}`}
                  >
                    {n}
                  </Button>
                ))}
              </div>
            </div>

            <Button
              variant="ghost"
              size="sm"
              className="h-6 text-xs font-mono text-muted-foreground gap-1"
              onClick={() => setShowKeyInput(!showKeyInput)}
              data-testid="button-toggle-key"
            >
              <Key className="w-3 h-3" />
              {showKeyInput ? "Hide" : "Firecrawl API Key (optional)"}
            </Button>

            {result && (
              <div className="flex items-center gap-1 text-xs font-mono text-muted-foreground ml-auto">
                <Clock className="w-3 h-3" />
                Last run: {(result.durationMs / 1000).toFixed(1)}s · {result.model}
              </div>
            )}
          </div>

          {showKeyInput && (
            <Input
              type="password"
              value={firecrawlKey}
              onChange={e => setFirecrawlKey(e.target.value)}
              placeholder="fc-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
              className="font-mono text-sm bg-background"
              data-testid="input-firecrawl-key"
            />
          )}

          {!firecrawlKey && (
            <div className="flex items-center gap-2 text-xs text-muted-foreground/60 font-mono bg-muted/20 rounded px-3 py-2">
              <Info className="w-3 h-3 flex-shrink-0" />
              No Firecrawl key — using DuckDuckGo Instant API as free fallback. Add a key for full web scraping.
            </div>
          )}
        </CardContent>
      </Card>

      {/* ── Pipeline progress bar ── */}
      {isRunning && steps.length > 0 && (
        <div className="space-y-1">
          <div className="flex items-center justify-between text-xs font-mono text-muted-foreground">
            <span>Pipeline progress</span>
            <span>{completedSteps}/{steps.length}</span>
          </div>
          <Progress value={progress} className="h-1.5" />
        </div>
      )}

      {/* ── Tabs ── */}
      {(steps.length > 0 || result) && (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="font-mono text-xs">
            <TabsTrigger value="pipeline" className="gap-1.5" data-testid="tab-pipeline">
              <Zap className="w-3.5 h-3.5" />Pipeline
              {isRunning && <Loader2 className="w-3 h-3 animate-spin" />}
            </TabsTrigger>
            <TabsTrigger value="sources" disabled={!result} className="gap-1.5" data-testid="tab-sources">
              <Globe className="w-3.5 h-3.5" />Sources
              {result && <Badge variant="secondary" className="text-xs ml-1">{result.sources.length}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="insights" disabled={!result} className="gap-1.5" data-testid="tab-insights">
              <Sparkles className="w-3.5 h-3.5" />Insights
              {result && <Badge variant="secondary" className="text-xs ml-1">{result.insights.length}</Badge>}
            </TabsTrigger>
            <TabsTrigger value="summary" disabled={!result} className="gap-1.5" data-testid="tab-summary">
              <BookOpen className="w-3.5 h-3.5" />Summary
            </TabsTrigger>
            <TabsTrigger value="semantic" className="gap-1.5" data-testid="tab-semantic">
              <Database className="w-3.5 h-3.5" />Qdrant
              {qdrantStats?.total ? (
                <Badge variant="secondary" className="text-xs ml-1">{qdrantStats.total}</Badge>
              ) : null}
            </TabsTrigger>
          </TabsList>

          {/* Pipeline steps */}
          <TabsContent value="pipeline" className="mt-4">
            <div className="space-y-2">
              {steps.map(renderPipelineStep)}
            </div>
          </TabsContent>

          {/* Sources */}
          <TabsContent value="sources" className="mt-4">
            {result && (
              <div className="space-y-3">
                <p className="text-xs text-muted-foreground font-mono">
                  {result.sources.length} sources indexed from {result.subQueries.length} sub-queries
                </p>
                {result.subQueries.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-3">
                    {result.subQueries.map((q, i) => (
                      <Badge key={i} variant="outline" className="text-xs font-mono">
                        <Search className="w-2.5 h-2.5 mr-1" />{q}
                      </Badge>
                    ))}
                  </div>
                )}
                {result.sources.length === 0 ? (
                  <Card className="bg-muted/20">
                    <CardContent className="p-6 text-center text-muted-foreground">
                      <Globe className="w-8 h-8 mx-auto mb-2 opacity-30" />
                      <p className="text-sm font-mono">No sources retrieved.</p>
                      <p className="text-xs mt-1">Try adding a Firecrawl API key for richer results.</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-2">
                    {result.sources.map((source, idx) => (
                      <Card
                        key={idx}
                        data-testid={`source-card-${idx}`}
                        className="bg-card border-border hover:border-primary/30 transition-colors"
                      >
                        <CardContent className="p-3 flex items-center gap-3">
                          <div className={`w-2 h-2 rounded-full flex-shrink-0 ${source.indexed ? "bg-green-500" : "bg-muted"}`} />
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium truncate">{source.title}</div>
                            <div className="text-xs text-muted-foreground font-mono truncate">{source.url}</div>
                          </div>
                          <div className="flex items-center gap-2 flex-shrink-0">
                            <Badge variant={source.indexed ? "default" : "outline"} className="text-xs font-mono">
                              {source.indexed ? "indexed" : "skipped"}
                            </Badge>
                            <a href={source.url} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="w-3.5 h-3.5 text-muted-foreground hover:text-primary" />
                            </a>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
            )}
          </TabsContent>

          {/* Insights */}
          <TabsContent value="insights" className="mt-4">
            {result && (
              <div className="space-y-4">
                {/* Category filter summary */}
                {result.insights.length > 0 && (
                  <div className="flex gap-2 flex-wrap">
                    {Object.entries(
                      result.insights.reduce<Record<string, number>>((acc, i) => {
                        acc[i.category] = (acc[i.category] || 0) + 1;
                        return acc;
                      }, {})
                    ).map(([cat, count]) => (
                      <Badge key={cat} variant="outline" className="text-xs font-mono gap-1">
                        <CategoryBadge category={cat} />
                        <span className="ml-1">{count}</span>
                      </Badge>
                    ))}
                  </div>
                )}

                {result.insights.length === 0 ? (
                  <Card className="bg-muted/20">
                    <CardContent className="p-6 text-center text-muted-foreground">
                      <Sparkles className="w-8 h-8 mx-auto mb-2 opacity-30" />
                      <p className="text-sm font-mono">No insights extracted.</p>
                      <p className="text-xs mt-1">Try a more specific query or add a Firecrawl key.</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {result.insights.map(renderInsight)}
                  </div>
                )}
              </div>
            )}
          </TabsContent>

          {/* Summary */}
          <TabsContent value="summary" className="mt-4">
            {result && (
              <div className="space-y-4">
                {/* Storage confirmation */}
                <div className="flex gap-4 flex-wrap">
                  <div className="flex items-center gap-2 text-xs font-mono text-green-500">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {result.memoryIds.length} SQLite memories
                  </div>
                  <div className="flex items-center gap-2 text-xs font-mono text-blue-400">
                    <Database className="w-3.5 h-3.5" />
                    {result.qdrantIds.length} Qdrant vectors
                  </div>
                  {result.projectLogId && (
                    <div className="flex items-center gap-2 text-xs font-mono text-purple-400">
                      <Brain className="w-3.5 h-3.5" />
                      Project Brain logged
                    </div>
                  )}
                </div>

                <Card className="bg-card border-border">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-mono flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-primary" />
                      Research Synthesis
                    </CardTitle>
                    <CardDescription className="font-mono text-xs">{result.query}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-relaxed whitespace-pre-line text-muted-foreground">
                      {result.summary}
                    </p>
                  </CardContent>
                </Card>

                {/* Sub-queries used */}
                {result.subQueries.length > 0 && (
                  <div>
                    <p className="text-xs font-mono text-muted-foreground mb-2">Sub-queries used:</p>
                    <div className="space-y-1">
                      {result.subQueries.map((q, i) => (
                        <div key={i} className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
                          <ChevronRight className="w-3 h-3 flex-shrink-0 text-primary" />
                          {q}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </TabsContent>

          {/* Qdrant semantic search */}
          <TabsContent value="semantic" className="mt-4">
            <div className="space-y-4">
              {/* Stats */}
              {qdrantStats && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <Card className="bg-card border-border">
                    <CardContent className="p-3">
                      <div className="text-2xl font-bold font-mono text-primary">{qdrantStats.total}</div>
                      <div className="text-xs text-muted-foreground font-mono">Total vectors</div>
                    </CardContent>
                  </Card>
                  {Object.entries(qdrantStats.categories).map(([cat, count]) => (
                    <Card key={cat} className="bg-card border-border">
                      <CardContent className="p-3">
                        <div className="text-2xl font-bold font-mono">{count}</div>
                        <CategoryBadge category={cat} />
                      </CardContent>
                    </Card>
                  ))}
                  <Card className={`border ${qdrantStats.status === "online" ? "border-green-500/30 bg-green-500/5" : "border-red-500/30 bg-red-500/5"}`}>
                    <CardContent className="p-3">
                      <div className={`text-sm font-bold font-mono ${qdrantStats.status === "online" ? "text-green-500" : "text-red-500"}`}>
                        {qdrantStats.status.toUpperCase()}
                      </div>
                      <div className="text-xs text-muted-foreground font-mono">Qdrant status</div>
                    </CardContent>
                  </Card>
                </div>
              )}

              <Separator />

              {/* Search */}
              <div>
                <p className="text-xs font-mono text-muted-foreground mb-3">
                  Semantic search across all stored research findings
                </p>
                <div className="flex gap-2">
                  <Input
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    placeholder="Search by meaning… e.g. 'transformer attention mechanism'"
                    className="font-mono text-sm bg-background flex-1"
                    data-testid="input-semantic-search"
                    onKeyDown={e => e.key === "Enter" && runSemanticSearch()}
                  />
                  <Button
                    onClick={runSemanticSearch}
                    disabled={isSearching || !searchQuery.trim()}
                    className="font-mono"
                    data-testid="button-semantic-search"
                  >
                    {isSearching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => refetchStats()}
                    title="Refresh stats"
                    data-testid="button-refresh-stats"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Search results */}
              {searchResults.length > 0 && (
                <div className="space-y-3">
                  <p className="text-xs font-mono text-muted-foreground">
                    {searchResults.length} semantic matches for "{searchQuery}"
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {searchResults.map(renderQdrantResult)}
                  </div>
                </div>
              )}

              {searchResults.length === 0 && searchQuery && !isSearching && (
                <Card className="bg-muted/20">
                  <CardContent className="p-6 text-center text-muted-foreground">
                    <Database className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm font-mono">No matches found.</p>
                    <p className="text-xs mt-1">Run some research queries first to populate the vector store.</p>
                  </CardContent>
                </Card>
              )}

              {qdrantStats?.total === 0 && !searchQuery && (
                <Card className="bg-muted/20">
                  <CardContent className="p-6 text-center text-muted-foreground">
                    <Brain className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm font-mono">Vector store is empty.</p>
                    <p className="text-xs mt-1">Run a research query above to populate Qdrant with embeddings.</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      )}

      {/* ── Empty state ── */}
      {steps.length === 0 && !result && (
        <Card className="bg-card border-border border-dashed">
          <CardContent className="p-10 text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto">
              <Search className="w-8 h-8 text-primary/60" />
            </div>
            <div>
              <h3 className="font-mono font-semibold mb-1">Atlas Ready</h3>
              <p className="text-sm text-muted-foreground max-w-md mx-auto">
                Enter a research intent above and press <kbd className="font-mono bg-muted px-1.5 py-0.5 rounded text-xs">Run Atlas</kbd>.
                The agent will decompose your query, scrape sources, extract ranked insights,
                and store everything into the Qdrant semantic memory.
              </p>
            </div>
            <div className="flex justify-center gap-6 text-xs font-mono text-muted-foreground/60">
              <span className="flex items-center gap-1"><Zap className="w-3 h-3" /> Query decomposition</span>
              <span className="flex items-center gap-1"><Globe className="w-3 h-3" /> Web scraping</span>
              <span className="flex items-center gap-1"><Sparkles className="w-3 h-3" /> Insight extraction</span>
              <span className="flex items-center gap-1"><Database className="w-3 h-3" /> Vector storage</span>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
