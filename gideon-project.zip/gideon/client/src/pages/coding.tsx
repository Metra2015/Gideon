/**
 * Coding — Vulcan Agent UI
 *
 * Sections:
 *   1. Task input (title, description, language, framework)
 *   2. Run Vulcan → live result
 *   3. Generated files viewer (syntax-highlighted)
 *   4. Automation tab — Mercury agent
 *   5. Vision tab — Minerva file analysis
 *   6. Agent runs history
 */

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import {
  Code, Play, FileCode, Globe, Eye, Clock, CheckCircle2,
  AlertCircle, Loader2, Copy, Download, ChevronRight, Zap,
  FileText, Bot, BarChart3, Tag
} from "lucide-react";
import type { AgentRun } from "@shared/schema";

// ── Types ─────────────────────────────────────────────────────────────
interface GeneratedFile {
  filename: string;
  content: string;
  language: string;
  description: string;
}

interface VulcanResult {
  task: string;
  language: string;
  framework: string;
  files: GeneratedFile[];
  explanation: string;
  memoryIds: number[];
  fileIds: number[];
  durationMs: number;
  model: string;
  taskId?: number;
}

interface MercuryResult {
  task: string;
  steps: { action: string; target?: string; result?: string; status: string; durationMs?: number }[];
  data: Record<string, unknown>;
  output: string;
  durationMs: number;
}

interface MinervaResult {
  task: string;
  fileType: string;
  filename: string;
  analysis: string;
  summary: string;
  entities: { type: string; value: string; context?: string }[];
  keyPoints: string[];
  wordCount: number;
  durationMs: number;
}

const LANGUAGES = ["auto", "typescript", "javascript", "python", "go", "rust", "bash", "sql", "html", "css"];
const FRAMEWORKS = ["auto", "express", "fastapi", "react", "vue", "django", "flask", "none"];

// ── Copy to clipboard ─────────────────────────────────────────────────
function copyToClipboard(text: string) {
  navigator.clipboard.writeText(text).catch(() => {});
}

// ── File viewer ───────────────────────────────────────────────────────
function FileViewer({ file }: { file: GeneratedFile }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    copyToClipboard(file.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const handleDownload = () => {
    const blob = new Blob([file.content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = file.filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Card className="bg-card border-border" data-testid={`file-viewer-${file.filename}`}>
      <CardHeader className="p-3 pb-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileCode className="w-4 h-4 text-primary" />
            <span className="font-mono text-sm font-semibold">{file.filename}</span>
            <Badge variant="outline" className="text-xs font-mono">{file.language}</Badge>
          </div>
          <div className="flex gap-1">
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleCopy} data-testid={`copy-${file.filename}`}>
              {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
            </Button>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={handleDownload} data-testid={`download-${file.filename}`}>
              <Download className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
        <p className="text-xs text-muted-foreground font-mono mt-1">{file.description}</p>
      </CardHeader>
      <CardContent className="p-3">
        <ScrollArea className="h-64">
          <pre className="text-xs font-mono whitespace-pre-wrap text-foreground/90 leading-relaxed">
            {file.content}
          </pre>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

// ── Agent run row ─────────────────────────────────────────────────────
function RunRow({ run }: { run: AgentRun }) {
  const [expanded, setExpanded] = useState(false);
  const statusColors = {
    completed: "text-green-500",
    failed: "text-red-500",
    running: "text-yellow-500",
  };

  return (
    <div className="border border-border rounded-lg overflow-hidden" data-testid={`run-row-${run.id}`}>
      <button
        className="w-full flex items-center gap-3 p-3 hover:bg-muted/20 transition-colors text-left"
        onClick={() => setExpanded(!expanded)}
      >
        <ChevronRight className={`w-3.5 h-3.5 text-muted-foreground transition-transform ${expanded ? "rotate-90" : ""}`} />
        <span className={`text-xs font-mono font-semibold ${statusColors[run.status as keyof typeof statusColors] || "text-muted-foreground"}`}>
          {run.status.toUpperCase()}
        </span>
        <span className="text-xs font-mono text-foreground flex-1 truncate">
          {JSON.parse(run.input || "{}").title || `Run #${run.id}`}
        </span>
        {run.durationMs && (
          <span className="text-xs font-mono text-muted-foreground">
            {(run.durationMs / 1000).toFixed(1)}s
          </span>
        )}
        <span className="text-xs text-muted-foreground/50 font-mono">
          {run.createdAt ? new Date(run.createdAt).toLocaleTimeString() : ""}
        </span>
      </button>
      {expanded && run.output && (
        <div className="border-t border-border p-3 bg-muted/10">
          <ScrollArea className="h-32">
            <pre className="text-xs font-mono whitespace-pre-wrap text-muted-foreground">
              {run.output.slice(0, 1000)}
            </pre>
          </ScrollArea>
        </div>
      )}
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────
export default function Coding() {
  const { toast } = useToast();
  const qc = useQueryClient();

  // Vulcan state
  const [vTask, setVTask]           = useState("");
  const [vDesc, setVDesc]           = useState("");
  const [vLang, setVLang]           = useState("auto");
  const [vFw, setVFw]               = useState("auto");
  const [vResult, setVResult]       = useState<VulcanResult | null>(null);

  // Mercury state
  const [mTask, setMTask]           = useState("");
  const [mDesc, setMDesc]           = useState("");
  const [mUrl, setMUrl]             = useState("");
  const [mResult, setMResult]       = useState<MercuryResult | null>(null);

  // Minerva state
  const [mnTask, setMnTask]         = useState("");
  const [mnContent, setMnContent]   = useState("");
  const [mnType, setMnType]         = useState("document");
  const [mnResult, setMnResult]     = useState<MinervaResult | null>(null);

  // Agent runs
  const { data: runs = [] } = useQuery<AgentRun[]>({
    queryKey: ["/api/agent-runs"],
    refetchInterval: 5000,
  });

  // Vulcan mutation
  const vulcanMut = useMutation({
    mutationFn: (d: object) => apiRequest("POST", "/api/vulcan/generate", d).then(r => r.json()),
    onSuccess: (data: VulcanResult) => {
      setVResult(data);
      qc.invalidateQueries({ queryKey: ["/api/agent-runs"] });
      qc.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({ title: "Vulcan complete", description: `${data.files.length} file(s) generated` });
    },
    onError: (err) => toast({ title: "Vulcan failed", description: String(err), variant: "destructive" }),
  });

  // Mercury mutation
  const mercuryMut = useMutation({
    mutationFn: (d: object) => apiRequest("POST", "/api/mercury/run", d).then(r => r.json()),
    onSuccess: (data: MercuryResult) => {
      setMResult(data);
      qc.invalidateQueries({ queryKey: ["/api/agent-runs"] });
      toast({ title: "Mercury complete", description: data.output.slice(0, 80) });
    },
    onError: (err) => toast({ title: "Mercury failed", description: String(err), variant: "destructive" }),
  });

  // Minerva mutation
  const minervaMut = useMutation({
    mutationFn: (d: object) => apiRequest("POST", "/api/minerva/analyze", d).then(r => r.json()),
    onSuccess: (data: MinervaResult) => {
      setMnResult(data);
      qc.invalidateQueries({ queryKey: ["/api/agent-runs"] });
      toast({ title: "Minerva complete", description: data.summary.slice(0, 80) });
    },
    onError: (err) => toast({ title: "Minerva failed", description: String(err), variant: "destructive" }),
  });

  const stepColors = { completed: "text-green-500", failed: "text-red-500", pending: "text-muted-foreground", skipped: "text-yellow-500" };

  return (
    <div className="flex flex-col gap-6 max-w-7xl mx-auto" data-testid="coding-page">

      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-primary/20 border border-primary/40 flex items-center justify-center">
          <Code className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h1 className="text-lg font-bold font-mono tracking-wide">Agent Divisions</h1>
          <p className="text-xs text-muted-foreground font-mono">Vulcan · Mercury · Minerva</p>
        </div>
      </div>

      <Tabs defaultValue="vulcan">
        <TabsList className="font-mono text-xs">
          <TabsTrigger value="vulcan" className="gap-1.5" data-testid="tab-vulcan">
            <Code className="w-3.5 h-3.5" />Vulcan
          </TabsTrigger>
          <TabsTrigger value="mercury" className="gap-1.5" data-testid="tab-mercury">
            <Globe className="w-3.5 h-3.5" />Mercury
          </TabsTrigger>
          <TabsTrigger value="minerva" className="gap-1.5" data-testid="tab-minerva">
            <Eye className="w-3.5 h-3.5" />Minerva
          </TabsTrigger>
          <TabsTrigger value="runs" className="gap-1.5" data-testid="tab-runs">
            <BarChart3 className="w-3.5 h-3.5" />Runs
            {runs.length > 0 && <Badge variant="secondary" className="text-xs ml-1">{runs.length}</Badge>}
          </TabsTrigger>
        </TabsList>

        {/* ── VULCAN ── */}
        <TabsContent value="vulcan" className="mt-4 space-y-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-mono flex items-center gap-2">
                <Zap className="w-4 h-4 text-green-400" />
                Vulcan — Code Generation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-xs font-mono">Task</Label>
                <Input
                  value={vTask}
                  onChange={e => setVTask(e.target.value)}
                  placeholder="Write a REST API endpoint for user authentication"
                  className="mt-1 font-mono text-sm bg-background"
                  data-testid="input-vulcan-task"
                />
              </div>
              <div>
                <Label className="text-xs font-mono">Description (optional)</Label>
                <Textarea
                  value={vDesc}
                  onChange={e => setVDesc(e.target.value)}
                  placeholder="JWT-based auth, bcrypt password hashing, Express middleware..."
                  className="mt-1 font-mono text-sm bg-background resize-none"
                  rows={2}
                  data-testid="input-vulcan-desc"
                />
              </div>
              <div className="flex gap-3">
                <div className="flex-1">
                  <Label className="text-xs font-mono">Language</Label>
                  <Select value={vLang} onValueChange={setVLang}>
                    <SelectTrigger className="mt-1 font-mono text-xs" data-testid="select-language">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {LANGUAGES.map(l => <SelectItem key={l} value={l} className="font-mono text-xs">{l}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex-1">
                  <Label className="text-xs font-mono">Framework</Label>
                  <Select value={vFw} onValueChange={setVFw}>
                    <SelectTrigger className="mt-1 font-mono text-xs" data-testid="select-framework">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {FRAMEWORKS.map(f => <SelectItem key={f} value={f} className="font-mono text-xs">{f}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button
                    onClick={() => vulcanMut.mutate({
                      task: vTask, description: vDesc,
                      language: vLang === "auto" ? undefined : vLang,
                      framework: vFw === "auto" ? undefined : vFw,
                    })}
                    disabled={vulcanMut.isPending || !vTask.trim()}
                    className="font-mono"
                    data-testid="button-vulcan-run"
                  >
                    {vulcanMut.isPending
                      ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Running</>
                      : <><Play className="w-4 h-4 mr-2" />Generate</>}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {vResult && (
            <div className="space-y-4">
              {/* Summary */}
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex flex-wrap gap-3 mb-3">
                    <Badge variant="outline" className="font-mono text-xs gap-1">
                      <Code className="w-3 h-3" />{vResult.language}
                    </Badge>
                    {vResult.framework && vResult.framework !== "none" && (
                      <Badge variant="outline" className="font-mono text-xs">{vResult.framework}</Badge>
                    )}
                    <Badge variant="outline" className="font-mono text-xs gap-1">
                      <FileCode className="w-3 h-3" />{vResult.files.length} file(s)
                    </Badge>
                    <Badge variant="outline" className="font-mono text-xs gap-1">
                      <Clock className="w-3 h-3" />{(vResult.durationMs / 1000).toFixed(1)}s
                    </Badge>
                    <Badge variant="outline" className="font-mono text-xs">{vResult.model}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">{vResult.explanation}</p>
                </CardContent>
              </Card>

              {/* Files */}
              <div className="space-y-3">
                {vResult.files.map(f => <FileViewer key={f.filename} file={f} />)}
              </div>
            </div>
          )}

          {!vResult && !vulcanMut.isPending && (
            <Card className="bg-muted/10 border-dashed border-border">
              <CardContent className="p-8 text-center text-muted-foreground">
                <Code className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p className="text-sm font-mono">Enter a coding task above to generate code.</p>
                <p className="text-xs mt-1">Vulcan detects language, generates files, reviews for bugs, writes to disk.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* ── MERCURY ── */}
        <TabsContent value="mercury" className="mt-4 space-y-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-mono flex items-center gap-2">
                <Globe className="w-4 h-4 text-blue-400" />
                Mercury — Web Automation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-xs font-mono">Task</Label>
                <Input
                  value={mTask}
                  onChange={e => setMTask(e.target.value)}
                  placeholder="Extract pricing from competitor website"
                  className="mt-1 font-mono text-sm bg-background"
                  data-testid="input-mercury-task"
                />
              </div>
              <div>
                <Label className="text-xs font-mono">Description</Label>
                <Textarea
                  value={mDesc}
                  onChange={e => setMDesc(e.target.value)}
                  placeholder="What to do and what to extract..."
                  className="mt-1 font-mono text-sm bg-background resize-none"
                  rows={2}
                  data-testid="input-mercury-desc"
                />
              </div>
              <div className="flex gap-3">
                <div className="flex-1">
                  <Label className="text-xs font-mono">Target URL (optional)</Label>
                  <Input
                    value={mUrl}
                    onChange={e => setMUrl(e.target.value)}
                    placeholder="https://example.com"
                    className="mt-1 font-mono text-sm bg-background"
                    data-testid="input-mercury-url"
                  />
                </div>
                <div className="flex items-end">
                  <Button
                    onClick={() => mercuryMut.mutate({ task: mTask, description: mDesc, targetUrl: mUrl || undefined })}
                    disabled={mercuryMut.isPending || !mTask.trim()}
                    className="font-mono"
                    data-testid="button-mercury-run"
                  >
                    {mercuryMut.isPending
                      ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Running</>
                      : <><Play className="w-4 h-4 mr-2" />Execute</>}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {mResult && (
            <div className="space-y-3">
              {/* Steps */}
              <div className="space-y-1.5">
                {mResult.steps.map((step, i) => (
                  <div key={i} className="flex items-center gap-3 p-2.5 rounded-lg bg-muted/20 font-mono text-xs" data-testid={`mercury-step-${i}`}>
                    <span className={stepColors[step.status as keyof typeof stepColors] || "text-muted-foreground"}>
                      {step.status === "completed" ? "✓" : step.status === "failed" ? "✗" : step.status === "skipped" ? "—" : "○"}
                    </span>
                    <span className="text-muted-foreground/60 w-16 flex-shrink-0">{step.action}</span>
                    <span className="flex-1 truncate text-foreground/80">{step.result || step.target}</span>
                    {step.durationMs && <span className="text-muted-foreground/40">{step.durationMs}ms</span>}
                  </div>
                ))}
              </div>

              {/* Output */}
              <Card className="bg-card border-border">
                <CardContent className="p-4">
                  <p className="text-sm text-muted-foreground leading-relaxed mb-3">{mResult.output}</p>
                  {Object.keys(mResult.data).length > 0 && (
                    <>
                      <Separator className="my-3" />
                      <p className="text-xs font-mono text-muted-foreground mb-2">Extracted data:</p>
                      <pre className="text-xs font-mono text-foreground/80 whitespace-pre-wrap">
                        {JSON.stringify(mResult.data, null, 2).slice(0, 600)}
                      </pre>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {!mResult && !mercuryMut.isPending && (
            <Card className="bg-muted/10 border-dashed border-border">
              <CardContent className="p-8 text-center text-muted-foreground">
                <Globe className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p className="text-sm font-mono">Describe an automation task above.</p>
                <p className="text-xs mt-1">Mercury fetches URLs, extracts data, transforms, and stores results.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* ── MINERVA ── */}
        <TabsContent value="minerva" className="mt-4 space-y-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-mono flex items-center gap-2">
                <Eye className="w-4 h-4 text-purple-400" />
                Minerva — Vision & File Intelligence
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <Label className="text-xs font-mono">Task</Label>
                <Input
                  value={mnTask}
                  onChange={e => setMnTask(e.target.value)}
                  placeholder="Analyze this document and extract key information"
                  className="mt-1 font-mono text-sm bg-background"
                  data-testid="input-minerva-task"
                />
              </div>
              <div className="flex gap-3">
                <div className="w-36 flex-shrink-0">
                  <Label className="text-xs font-mono">File type</Label>
                  <Select value={mnType} onValueChange={setMnType}>
                    <SelectTrigger className="mt-1 font-mono text-xs" data-testid="select-filetype">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {["document", "code", "image", "data", "unknown"].map(t =>
                        <SelectItem key={t} value={t} className="font-mono text-xs">{t}</SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex-1">
                  <Label className="text-xs font-mono">File content (paste text or code)</Label>
                  <Textarea
                    value={mnContent}
                    onChange={e => setMnContent(e.target.value)}
                    placeholder="Paste document content, code, CSV, or any text to analyze..."
                    className="mt-1 font-mono text-xs bg-background resize-none"
                    rows={4}
                    data-testid="input-minerva-content"
                  />
                </div>
              </div>
              <Button
                onClick={() => minervaMut.mutate({ task: mnTask, fileContent: mnContent, fileType: mnType })}
                disabled={minervaMut.isPending || !mnTask.trim()}
                className="font-mono"
                data-testid="button-minerva-run"
              >
                {minervaMut.isPending
                  ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Analyzing</>
                  : <><Eye className="w-4 h-4 mr-2" />Analyze</>}
              </Button>
            </CardContent>
          </Card>

          {mnResult && (
            <div className="space-y-3">
              {/* Summary card */}
              <Card className="bg-card border-border">
                <CardContent className="p-4 space-y-3">
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline" className="font-mono text-xs">{mnResult.fileType}</Badge>
                    {mnResult.wordCount > 0 && (
                      <Badge variant="outline" className="font-mono text-xs">{mnResult.wordCount} words</Badge>
                    )}
                    <Badge variant="outline" className="font-mono text-xs gap-1">
                      <Clock className="w-3 h-3" />{(mnResult.durationMs / 1000).toFixed(1)}s
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">{mnResult.summary}</p>
                </CardContent>
              </Card>

              {/* Key points */}
              {mnResult.keyPoints.length > 0 && (
                <Card className="bg-card border-border">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Key Points</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 pt-0 space-y-1.5">
                    {mnResult.keyPoints.map((pt, i) => (
                      <div key={i} className="flex items-start gap-2 text-sm">
                        <ChevronRight className="w-3.5 h-3.5 text-primary mt-0.5 flex-shrink-0" />
                        <span className="text-muted-foreground">{pt}</span>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              )}

              {/* Entities */}
              {mnResult.entities.length > 0 && (
                <Card className="bg-card border-border">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Entities</CardTitle>
                  </CardHeader>
                  <CardContent className="p-4 pt-0">
                    <div className="flex flex-wrap gap-2">
                      {mnResult.entities.map((e, i) => (
                        <div key={i} className="flex items-center gap-1.5 bg-muted/30 rounded px-2 py-1 text-xs font-mono" data-testid={`entity-${i}`}>
                          <Tag className="w-3 h-3 text-primary" />
                          <span className="text-muted-foreground">{e.type}:</span>
                          <span className="text-foreground">{e.value}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Full analysis */}
              <Card className="bg-card border-border">
                <CardHeader className="pb-2">
                  <CardTitle className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Full Analysis</CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <ScrollArea className="h-56">
                    <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line">
                      {mnResult.analysis}
                    </p>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          )}

          {!mnResult && !minervaMut.isPending && (
            <Card className="bg-muted/10 border-dashed border-border">
              <CardContent className="p-8 text-center text-muted-foreground">
                <Eye className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p className="text-sm font-mono">Paste file content above for Minerva to analyze.</p>
                <p className="text-xs mt-1">Supports documents, code, data files, and more.</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* ── AGENT RUNS ── */}
        <TabsContent value="runs" className="mt-4">
          <div className="space-y-2">
            {runs.length === 0 ? (
              <Card className="bg-muted/10 border-dashed border-border">
                <CardContent className="p-8 text-center text-muted-foreground">
                  <Bot className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p className="text-sm font-mono">No agent runs yet.</p>
                  <p className="text-xs mt-1">Runs appear here after executing Vulcan, Mercury, or Minerva tasks.</p>
                </CardContent>
              </Card>
            ) : (
              <>
                <p className="text-xs font-mono text-muted-foreground">{runs.length} agent execution(s)</p>
                {runs.map(run => <RunRow key={run.id} run={run} />)}
              </>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
