import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { FolderOpen, Plus, Trash2, BookOpen, GitBranch } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Project } from '@shared/schema';

const statusColor: Record<string,string> = {
  active:'text-green-400', paused:'text-yellow-400', completed:'text-blue-400', archived:'text-muted-foreground',
};

export default function ProjectsPage() {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState<Project|null>(null);
  const [form, setForm] = useState({ name:'', description:'', path:'', stack:'' });
  const [decision, setDecision] = useState({ decision:'', reason:'', alternatives:'' });

  const { data: projects=[] } = useQuery<Project[]>({ queryKey:['/api/projects'] });

  const createProject = useMutation({
    mutationFn: (d: typeof form) => apiRequest('POST','/api/projects',{
      ...d, stack: JSON.stringify(d.stack.split(',').map(s=>s.trim()).filter(Boolean)),
    }).then(r=>r.json()),
    onSuccess: () => { queryClient.invalidateQueries({queryKey:['/api/projects']}); setOpen(false); toast({title:"Project created"}); },
  });

  const addDecision = useMutation({
    mutationFn: ({ project, dec }: { project: Project; dec: typeof decision }) => {
      const existing = (() => { try { return JSON.parse(project.decisions); } catch { return []; } })();
      const newDecisions = [...existing, { ...dec, date: new Date().toISOString().split('T')[0] }];
      return apiRequest('PATCH',`/api/projects/${project.id}`,{ decisions: JSON.stringify(newDecisions) }).then(r=>r.json());
    },
    onSuccess: (data: Project) => {
      queryClient.invalidateQueries({queryKey:['/api/projects']});
      setSelected(data);
      setDecision({decision:'',reason:'',alternatives:''});
    },
  });

  const deleteProject = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE',`/api/projects/${id}`).then(r=>r.json()),
    onSuccess: () => { queryClient.invalidateQueries({queryKey:['/api/projects']}); setSelected(null); },
  });

  return (
    <div className="space-y-4 max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-mono font-bold text-lg">Project Brain</h1>
          <p className="text-xs text-muted-foreground font-mono">{projects.length} projects tracked</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="font-mono gap-1.5" data-testid="button-new-project">
              <Plus className="w-3.5 h-3.5" /> New Project
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader><DialogTitle className="font-mono">Create Project</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div>
                <Label className="font-mono text-xs">Project Name</Label>
                <Input className="mt-1 font-mono" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} data-testid="input-project-name" />
              </div>
              <div>
                <Label className="font-mono text-xs">Description</Label>
                <Textarea className="mt-1 font-mono text-xs" rows={3} value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))} data-testid="input-project-desc" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="font-mono text-xs">Path</Label>
                  <Input className="mt-1 font-mono" value={form.path} onChange={e=>setForm(f=>({...f,path:e.target.value}))} placeholder="/home/user/projects/..." data-testid="input-project-path" />
                </div>
                <div>
                  <Label className="font-mono text-xs">Stack (comma-separated)</Label>
                  <Input className="mt-1 font-mono" value={form.stack} onChange={e=>setForm(f=>({...f,stack:e.target.value}))} placeholder="React, Node, PostgreSQL" data-testid="input-stack" />
                </div>
              </div>
              <Button className="w-full font-mono" onClick={()=>createProject.mutate(form)} disabled={!form.name} data-testid="button-submit-project">
                Create Project
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Project list */}
        <div className="space-y-2">
          {projects.length===0 && (
            <div className="gideon-panel p-8 text-center">
              <FolderOpen className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-xs text-muted-foreground font-mono">No projects yet.</p>
            </div>
          )}
          {projects.map(p=>{
            const stack = (() => { try{return JSON.parse(p.stack);}catch{return[];} })();
            return (
              <div key={p.id} className={`gideon-panel p-3 cursor-pointer hover:border-primary/40 transition-colors ${selected?.id===p.id?'border-primary/60':''}`} onClick={()=>setSelected(p)} data-testid={`project-card-${p.id}`}>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <FolderOpen className="w-3.5 h-3.5 text-primary" />
                      <span className="font-mono font-semibold text-sm">{p.name}</span>
                      <span className={`text-xs font-mono ${statusColor[p.status]}`}>{p.status}</span>
                    </div>
                    {p.description && <div className="text-xs text-muted-foreground mt-1 line-clamp-1">{p.description}</div>}
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {stack.slice(0,4).map((s:string)=>(
                        <span key={s} className="text-xs px-1.5 py-0.5 bg-primary/10 text-primary rounded font-mono border border-primary/20">{s}</span>
                      ))}
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="w-6 h-6 text-muted-foreground hover:text-red-400" onClick={e=>{e.stopPropagation();deleteProject.mutate(p.id);}} data-testid={`button-delete-project-${p.id}`}>
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Project Detail */}
        <div className="lg:col-span-2 gideon-panel">
          {!selected ? (
            <div className="p-8 text-center">
              <BookOpen className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-xs text-muted-foreground font-mono">Select a project to view its Brain</p>
            </div>
          ) : (
            <>
              <div className="gideon-panel-header">
                <div className="flex items-center gap-2">
                  <GitBranch className="w-3.5 h-3.5 text-primary" />
                  <span className="font-mono font-bold">{selected.name}</span>
                  <span className="text-xs text-muted-foreground font-mono">{selected.path}</span>
                </div>
              </div>
              <div className="p-4 space-y-4">
                {/* Decision Log */}
                <div>
                  <div className="text-xs font-mono text-muted-foreground mb-2 uppercase tracking-wider">Decision Log</div>
                  {(() => { const decs = (() => { try{return JSON.parse(selected.decisions);}catch{return[];} })();
                    return decs.length===0 ? <p className="text-xs text-muted-foreground font-mono">No decisions logged.</p> : (
                      <div className="space-y-2">
                        {decs.map((d: {decision:string;reason:string;alternatives:string;date:string}, i: number) => (
                          <div key={i} className="p-2 bg-muted/30 rounded border border-border text-xs font-mono">
                            <div className="font-semibold text-foreground">{d.decision}</div>
                            <div className="text-muted-foreground mt-0.5">Reason: {d.reason}</div>
                            {d.alternatives && <div className="text-muted-foreground mt-0.5">Alternatives: {d.alternatives}</div>}
                            <div className="text-muted-foreground/50 mt-0.5">{d.date}</div>
                          </div>
                        ))}
                      </div>
                    );
                  })()}
                  <div className="mt-3 space-y-2 border-t border-border pt-3">
                    <div className="text-xs font-mono text-muted-foreground">Log a Decision</div>
                    <Input className="font-mono text-xs" placeholder="Decision made..." value={decision.decision} onChange={e=>setDecision(d=>({...d,decision:e.target.value}))} data-testid="input-decision" />
                    <Input className="font-mono text-xs" placeholder="Reason..." value={decision.reason} onChange={e=>setDecision(d=>({...d,reason:e.target.value}))} data-testid="input-reason" />
                    <Input className="font-mono text-xs" placeholder="Alternatives considered..." value={decision.alternatives} onChange={e=>setDecision(d=>({...d,alternatives:e.target.value}))} data-testid="input-alternatives" />
                    <Button size="sm" className="font-mono" onClick={()=>selected&&addDecision.mutate({project:selected,dec:decision})} disabled={!decision.decision} data-testid="button-log-decision">
                      Log Decision
                    </Button>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
