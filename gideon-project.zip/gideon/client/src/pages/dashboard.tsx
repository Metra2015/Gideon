import { useQuery } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Brain, Bot, CheckSquare, Database, Zap, Clock, TrendingUp, AlertTriangle, Activity } from 'lucide-react';
import type { Task, Agent, Memory } from '@shared/schema';

function StatCard({ title, value, sub, icon: Icon, accent }: {
  title: string; value: string | number; sub?: string;
  icon: React.ComponentType<{ className?: string }>; accent?: string;
}) {
  return (
    <div className="gideon-panel p-4 flex items-start gap-3">
      <div className={`p-2 rounded-md ${accent || 'bg-primary/10'} flex-shrink-0`}>
        <Icon className={`w-4 h-4 ${accent ? 'text-inherit' : 'text-primary'}`} />
      </div>
      <div>
        <div className="text-xs font-mono text-muted-foreground uppercase tracking-wider">{title}</div>
        <div className="text-xl font-bold font-mono mt-0.5">{value}</div>
        {sub && <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { data: status } = useQuery({ queryKey: ['/api/system/status'], refetchInterval: 5000 });
  const { data: tasks = [] } = useQuery<Task[]>({ queryKey: ['/api/tasks'] });
  const { data: agents = [] } = useQuery<Agent[]>({ queryKey: ['/api/agents'] });
  const { data: memStats } = useQuery({ queryKey: ['/api/memory/stats'] });
  const { data: memories = [] } = useQuery<Memory[]>({ queryKey: ['/api/memories'] });

  const recentTasks = tasks.slice(0, 6);
  const recentMemories = memories.slice(0, 5);

  const taskStats = {
    total: tasks.length,
    running: tasks.filter(t => t.status === 'in_progress').length,
    completed: tasks.filter(t => t.status === 'completed').length,
    failed: tasks.filter(t => t.status === 'failed').length,
    pending: tasks.filter(t => t.status === 'pending').length,
  };

  const agentStats = {
    total: agents.length,
    active: agents.filter(a => a.status === 'active').length,
    idle: agents.filter(a => a.status === 'idle').length,
    error: agents.filter(a => a.status === 'error').length,
  };

  const statusColor = (s: string) => {
    if (s === 'completed') return 'text-green-400';
    if (s === 'in_progress') return 'text-yellow-400';
    if (s === 'failed') return 'text-red-400';
    if (s === 'pending') return 'text-blue-400';
    return 'text-muted-foreground';
  };

  const agentColor = (s: string) => {
    if (s === 'active') return 'status-active';
    if (s === 'error') return 'status-error';
    return 'status-idle';
  };

  const memCatColor: Record<string, string> = {
    working: 'bg-yellow-500/20 text-yellow-400',
    episodic: 'bg-purple-500/20 text-purple-400',
    semantic: 'bg-cyan-500/20 text-cyan-400',
    procedural: 'bg-green-500/20 text-green-400',
    long_term: 'bg-blue-500/20 text-blue-400',
  };

  return (
    <div className="space-y-4 max-w-7xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-mono font-bold text-lg text-primary text-glow-cyan">GIDEON CORE</h1>
          <p className="text-xs text-muted-foreground font-mono mt-0.5">
            {status ? `Uptime: ${Math.floor((status.uptime || 0) / 60)}m · ${status.memories || 0} memories stored` : 'Loading system status...'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className={`gideon-status-dot ${status?.status === 'online' ? 'status-active animate-pulse-glow' : 'status-error'}`} />
          <span className="text-xs font-mono text-muted-foreground">{status?.status?.toUpperCase() || 'OFFLINE'}</span>
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard title="Agents" value={agentStats.total} sub={`${agentStats.active} active`} icon={Bot} accent="bg-cyan-500/10" />
        <StatCard title="Tasks" value={taskStats.total} sub={`${taskStats.running} running`} icon={CheckSquare} accent="bg-purple-500/10" />
        <StatCard title="Memories" value={memStats?.total || memories.length} sub={`${memStats?.highImportance || 0} high importance`} icon={Brain} accent="bg-green-500/10" />
        <StatCard title="System" value={status?.status === 'online' ? 'ONLINE' : 'OFFLINE'} sub={`v1.0 · Hermes Ed.`} icon={Activity} accent="bg-yellow-500/10" />
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* Agent Fleet */}
        <div className="gideon-panel">
          <div className="gideon-panel-header">
            <div className="flex items-center gap-2">
              <Bot className="w-3.5 h-3.5 text-primary" />
              <span className="font-mono text-xs font-semibold uppercase tracking-wider">Agent Fleet</span>
            </div>
            <Badge variant="outline" className="font-mono text-xs">{agentStats.active}/{agentStats.total}</Badge>
          </div>
          <div className="p-3 space-y-2">
            {agents.map(agent => (
              <div key={agent.id} className="flex items-center gap-3 p-2 rounded bg-muted/30 hover:bg-muted/50 transition-colors">
                <span className={`gideon-status-dot ${agentColor(agent.status)} ${agent.status === 'active' ? 'animate-pulse-glow' : ''}`} />
                <div className="flex-1 min-w-0">
                  <div className="font-mono text-xs font-semibold truncate">{agent.name}</div>
                  <div className="text-xs text-muted-foreground capitalize">{agent.type}</div>
                </div>
                <div className="text-xs font-mono text-muted-foreground">{agent.taskCount} tasks</div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Tasks */}
        <div className="gideon-panel">
          <div className="gideon-panel-header">
            <div className="flex items-center gap-2">
              <CheckSquare className="w-3.5 h-3.5 text-primary" />
              <span className="font-mono text-xs font-semibold uppercase tracking-wider">Recent Tasks</span>
            </div>
            <Badge variant="outline" className="font-mono text-xs">{taskStats.running} live</Badge>
          </div>
          <div className="p-3 space-y-2">
            {recentTasks.length === 0 && (
              <div className="text-xs text-muted-foreground text-center py-4 font-mono">No tasks yet. Use the Terminal to start.</div>
            )}
            {recentTasks.map(task => (
              <div key={task.id} className="p-2 rounded bg-muted/30 hover:bg-muted/50 transition-colors">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-mono truncate flex-1">{task.title}</span>
                  <span className={`text-xs font-mono flex-shrink-0 ${statusColor(task.status)}`}>{task.status}</span>
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <span className={`text-xs ${task.priority === 'high' || task.priority === 'critical' ? 'text-red-400' : task.priority === 'medium' ? 'text-yellow-400' : 'text-muted-foreground'}`}>
                    {task.priority}
                  </span>
                  <span className="text-xs text-muted-foreground">risk:{task.riskScore}/10</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Memory Feed */}
        <div className="gideon-panel">
          <div className="gideon-panel-header">
            <div className="flex items-center gap-2">
              <Brain className="w-3.5 h-3.5 text-primary" />
              <span className="font-mono text-xs font-semibold uppercase tracking-wider">Memory Feed</span>
            </div>
            <Badge variant="outline" className="font-mono text-xs">{memories.length} stored</Badge>
          </div>
          <div className="p-3 space-y-2">
            {recentMemories.map(mem => (
              <div key={mem.id} className="p-2 rounded bg-muted/30 hover:bg-muted/50 transition-colors">
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-xs px-1.5 py-0.5 rounded font-mono ${memCatColor[mem.category] || 'bg-muted text-muted-foreground'}`}>
                    {mem.category}
                  </span>
                  <span className="text-xs text-muted-foreground">imp:{mem.importance}/10</span>
                </div>
                <div className="text-xs font-mono truncate">{mem.title}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Memory Category Distribution */}
      {memStats?.byCategory && (
        <div className="gideon-panel">
          <div className="gideon-panel-header">
            <div className="flex items-center gap-2">
              <Database className="w-3.5 h-3.5 text-primary" />
              <span className="font-mono text-xs font-semibold uppercase tracking-wider">Memory Distribution</span>
            </div>
          </div>
          <div className="p-4 grid grid-cols-2 md:grid-cols-5 gap-3">
            {memStats.byCategory.map((cat: { category: string; count: number }) => (
              <div key={cat.category} className="text-center">
                <div className={`text-lg font-bold font-mono ${memCatColor[cat.category]?.split(' ')[1] || 'text-foreground'}`}>{cat.count}</div>
                <div className="text-xs text-muted-foreground font-mono capitalize mt-0.5">{cat.category.replace('_', ' ')}</div>
                <div className="mt-1 h-1 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full bg-primary/60"
                    style={{ width: `${memStats.total > 0 ? (cat.count / memStats.total) * 100 : 0}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
