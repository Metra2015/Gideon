import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Settings, Save, Shield, Cpu, Database, Network } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { User } from '@shared/schema';

const MODELS = [
  'ollama/qwen2.5-coder:7b', 'ollama/llama3.2:3b', 'ollama/llama3.1:8b',
  'ollama/deepseek-r1:7b', 'ollama/gemma3:4b', 'ollama/mistral:7b',
  'ollama/llava:7b', 'openai/gpt-4o', 'anthropic/claude-3-5-sonnet-20241022',
];

const RISK_LEVELS = [
  { range: '0–4', label: 'Automatic execution', color: 'text-green-400' },
  { range: '5–7', label: 'Confirmation required', color: 'text-yellow-400' },
  { range: '8–10', label: 'Explicit approval required', color: 'text-red-400' },
];

export default function SettingsPage() {
  const { toast } = useToast();
  const { data: users=[] } = useQuery<User[]>({ queryKey:['/api/users'] });
  const user = users[0];
  const [form, setForm] = useState({ name:'', preferredModel:'', ollamaUrl:'', openaiKey:'', anthropicKey:'' });
  const [initialized, setInitialized] = useState(false);

  if (user && !initialized) {
    setForm({ name:user.name, preferredModel:user.preferredModel, ollamaUrl:user.ollamaUrl, openaiKey:user.openaiKey||'', anthropicKey:user.anthropicKey||'' });
    setInitialized(true);
  }

  const saveSettings = useMutation({
    mutationFn: (d: typeof form) => apiRequest('PATCH',`/api/users/${user?.id}`,d).then(r=>r.json()),
    onSuccess: () => { queryClient.invalidateQueries({queryKey:['/api/users']}); toast({title:"Settings saved"}); },
  });

  const { data: status } = useQuery({ queryKey:['/api/system/status'], refetchInterval: 5000 });

  return (
    <div className="space-y-5 max-w-3xl">
      <div>
        <h1 className="font-mono font-bold text-lg">Settings</h1>
        <p className="text-xs text-muted-foreground font-mono">Gideon Core configuration</p>
      </div>

      {/* System Status */}
      <div className="gideon-panel">
        <div className="gideon-panel-header">
          <div className="flex items-center gap-2"><Cpu className="w-3.5 h-3.5 text-primary" /><span className="font-mono text-xs font-semibold uppercase tracking-wider">System Status</span></div>
        </div>
        <div className="p-4 grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: 'Status', value: status?.status || 'unknown', color: status?.status==='online'?'text-green-400':'text-red-400' },
            { label: 'Uptime', value: status ? `${Math.floor(status.uptime/60)}m` : '—' },
            { label: 'Agents', value: `${status?.agents?.active||0}/${status?.agents?.total||0}` },
            { label: 'Memories', value: status?.memories || 0 },
          ].map(item => (
            <div key={item.label} className="text-center">
              <div className={`font-mono font-bold text-base ${item.color||'text-foreground'}`}>{item.value}</div>
              <div className="text-xs text-muted-foreground font-mono mt-0.5">{item.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* User & Model Config */}
      <div className="gideon-panel">
        <div className="gideon-panel-header">
          <div className="flex items-center gap-2"><Settings className="w-3.5 h-3.5 text-primary" /><span className="font-mono text-xs font-semibold uppercase tracking-wider">Operator Config</span></div>
        </div>
        <div className="p-4 space-y-4">
          <div>
            <Label className="font-mono text-xs">Operator Name</Label>
            <Input className="mt-1 font-mono" value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} data-testid="input-name" />
          </div>
          <div>
            <Label className="font-mono text-xs">Default Model</Label>
            <Select value={form.preferredModel} onValueChange={v=>setForm(f=>({...f,preferredModel:v}))}>
              <SelectTrigger className="mt-1" data-testid="select-model"><SelectValue /></SelectTrigger>
              <SelectContent>{MODELS.map(m=><SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Connections */}
      <div className="gideon-panel">
        <div className="gideon-panel-header">
          <div className="flex items-center gap-2"><Network className="w-3.5 h-3.5 text-primary" /><span className="font-mono text-xs font-semibold uppercase tracking-wider">Connections</span></div>
        </div>
        <div className="p-4 space-y-4">
          <div>
            <Label className="font-mono text-xs">Ollama URL</Label>
            <Input className="mt-1 font-mono" value={form.ollamaUrl} onChange={e=>setForm(f=>({...f,ollamaUrl:e.target.value}))} placeholder="http://localhost:11434" data-testid="input-ollama-url" />
            <p className="text-xs text-muted-foreground font-mono mt-1">Local Ollama inference server URL</p>
          </div>
          <div>
            <Label className="font-mono text-xs">OpenAI API Key (optional)</Label>
            <Input type="password" className="mt-1 font-mono" value={form.openaiKey} onChange={e=>setForm(f=>({...f,openaiKey:e.target.value}))} placeholder="sk-..." data-testid="input-openai-key" />
          </div>
          <div>
            <Label className="font-mono text-xs">Anthropic API Key (optional)</Label>
            <Input type="password" className="mt-1 font-mono" value={form.anthropicKey} onChange={e=>setForm(f=>({...f,anthropicKey:e.target.value}))} placeholder="sk-ant-..." data-testid="input-anthropic-key" />
          </div>
        </div>
      </div>

      {/* Security Policy */}
      <div className="gideon-panel">
        <div className="gideon-panel-header">
          <div className="flex items-center gap-2"><Shield className="w-3.5 h-3.5 text-primary" /><span className="font-mono text-xs font-semibold uppercase tracking-wider">Security Policy</span></div>
        </div>
        <div className="p-4">
          <div className="space-y-2">
            {RISK_LEVELS.map(level => (
              <div key={level.range} className="flex items-center gap-3 p-2 bg-muted/30 rounded">
                <span className={`font-mono font-bold text-sm w-10 flex-shrink-0 ${level.color}`}>{level.range}</span>
                <span className="text-xs font-mono text-muted-foreground">{level.label}</span>
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground font-mono mt-3">Risk scores are auto-calculated by Gideon Core based on action type, scope, and reversibility.</p>
        </div>
      </div>

      {/* Stack */}
      <div className="gideon-panel">
        <div className="gideon-panel-header">
          <div className="flex items-center gap-2"><Database className="w-3.5 h-3.5 text-primary" /><span className="font-mono text-xs font-semibold uppercase tracking-wider">Recommended Stack</span></div>
        </div>
        <div className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {['Hermes Runtime','OpenHands','PostgreSQL','Qdrant','Neo4j','Ollama','LiteLLM','Firecrawl',
              'Playwright','Faster-Whisper','Piper','OpenWakeWord','PaddleOCR','OmniParser','Syncthing','Tailscale'].map(item => (
              <div key={item} className="text-xs font-mono px-2 py-1.5 bg-muted/30 rounded border border-border text-muted-foreground hover:border-primary/30 hover:text-primary transition-colors cursor-default">
                {item}
              </div>
            ))}
          </div>
        </div>
      </div>

      <Button className="font-mono gap-1.5" onClick={()=>saveSettings.mutate(form)} disabled={saveSettings.isPending} data-testid="button-save-settings">
        <Save className="w-3.5 h-3.5" /> Save Configuration
      </Button>
    </div>
  );
}
