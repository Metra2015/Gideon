import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Brain, Plus, Search, Trash2, Star, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Memory } from '@shared/schema';

const CATEGORIES = ['all', 'working', 'episodic', 'semantic', 'procedural', 'long_term'];
const catColor: Record<string, string> = {
  working:    'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  episodic:   'bg-purple-500/20 text-purple-400 border-purple-500/30',
  semantic:   'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
  procedural: 'bg-green-500/20 text-green-400 border-green-500/30',
  long_term:  'bg-blue-500/20 text-blue-400 border-blue-500/30',
};

export default function MemoryPage() {
  const { toast } = useToast();
  const [category, setCategory] = useState('all');
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ category: 'semantic', type: 'fact', title: '', content: '', importance: 5, tags: '' });

  const { data: memories = [], isLoading } = useQuery<Memory[]>({
    queryKey: ['/api/memories', category, search],
    queryFn: () => {
      const params = new URLSearchParams();
      if (category !== 'all') params.set('category', category);
      if (search) params.set('search', search);
      return apiRequest('GET', `/api/memories?${params}`).then(r => r.json());
    },
  });

  const { data: stats } = useQuery({ queryKey: ['/api/memory/stats'] });

  const createMem = useMutation({
    mutationFn: (data: typeof form) => apiRequest('POST', '/api/memories', {
      ...data,
      importance: Number(data.importance),
      tags: JSON.stringify(data.tags.split(',').map(t => t.trim()).filter(Boolean)),
    }).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/memories'] });
      queryClient.invalidateQueries({ queryKey: ['/api/memory/stats'] });
      setOpen(false);
      setForm({ category: 'semantic', type: 'fact', title: '', content: '', importance: 5, tags: '' });
      toast({ title: "Memory stored", description: "Added to knowledge base" });
    },
  });

  const deleteMem = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE', `/api/memories/${id}`).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/memories'] });
      queryClient.invalidateQueries({ queryKey: ['/api/memory/stats'] });
    },
  });

  return (
    <div className="space-y-4 max-w-6xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-mono font-bold text-lg">Memory System</h1>
          <p className="text-xs text-muted-foreground font-mono">
            {stats?.total || 0} memories · {stats?.highImportance || 0} critical
          </p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="font-mono gap-1.5" data-testid="button-add-memory">
              <Plus className="w-3.5 h-3.5" /> Store Memory
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle className="font-mono">Store New Memory</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="font-mono text-xs">Category</Label>
                  <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                    <SelectTrigger className="mt-1" data-testid="select-category">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.filter(c => c !== 'all').map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="font-mono text-xs">Type</Label>
                  <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v }))}>
                    <SelectTrigger className="mt-1" data-testid="select-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {['fact','event','process','conversation','project'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label className="font-mono text-xs">Title</Label>
                <Input className="mt-1 font-mono" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} data-testid="input-title" placeholder="Memory title..." />
              </div>
              <div>
                <Label className="font-mono text-xs">Content</Label>
                <Textarea className="mt-1 font-mono text-xs" rows={4} value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} data-testid="input-content" placeholder="What should Gideon remember..." />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="font-mono text-xs">Importance (1-10)</Label>
                  <Input type="number" min={1} max={10} className="mt-1 font-mono" value={form.importance} onChange={e => setForm(f => ({ ...f, importance: Number(e.target.value) }))} data-testid="input-importance" />
                </div>
                <div>
                  <Label className="font-mono text-xs">Tags (comma-separated)</Label>
                  <Input className="mt-1 font-mono" value={form.tags} onChange={e => setForm(f => ({ ...f, tags: e.target.value }))} data-testid="input-tags" placeholder="tag1, tag2" />
                </div>
              </div>
              <Button className="w-full font-mono" onClick={() => createMem.mutate(form)} disabled={!form.title || !form.content} data-testid="button-submit-memory">
                Store Memory
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats row */}
      {stats?.byCategory && (
        <div className="grid grid-cols-5 gap-2">
          {stats.byCategory.map((cat: { category: string; count: number }) => (
            <button key={cat.category} onClick={() => setCategory(cat.category)}
              className={`p-2 rounded gideon-panel text-center cursor-pointer hover:border-primary/50 transition-colors ${category === cat.category ? 'border-primary' : ''}`}
              data-testid={`filter-${cat.category}`}>
              <div className={`text-base font-bold font-mono ${catColor[cat.category]?.split(' ')[1] || ''}`}>{cat.count}</div>
              <div className="text-xs text-muted-foreground font-mono capitalize mt-0.5">{cat.category.replace('_',' ')}</div>
            </button>
          ))}
        </div>
      )}

      {/* Filter bar */}
      <div className="flex gap-2">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input className="pl-8 font-mono text-xs" placeholder="Search memories..." value={search} onChange={e => setSearch(e.target.value)} data-testid="input-search" />
        </div>
        <Button variant="outline" size="sm" className="font-mono text-xs" onClick={() => setCategory('all')} data-testid="button-show-all">All</Button>
        {CATEGORIES.filter(c => c !== 'all').map(c => (
          <Button key={c} variant={category === c ? 'default' : 'outline'} size="sm" className="font-mono text-xs capitalize hidden md:flex" onClick={() => setCategory(c)} data-testid={`button-cat-${c}`}>
            {c.replace('_',' ')}
          </Button>
        ))}
      </div>

      {/* Memory list */}
      <div className="space-y-2">
        {isLoading && <div className="text-xs text-muted-foreground font-mono p-4">Loading memories...</div>}
        {!isLoading && memories.length === 0 && (
          <div className="gideon-panel p-8 text-center">
            <Brain className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-xs text-muted-foreground font-mono">No memories found. Start storing knowledge.</p>
          </div>
        )}
        {memories.map(mem => {
          const tags = (() => { try { return JSON.parse(mem.tags); } catch { return []; } })();
          return (
            <div key={mem.id} className="gideon-panel p-3 hover:border-primary/30 transition-colors" data-testid={`memory-card-${mem.id}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`text-xs px-1.5 py-0.5 rounded border font-mono ${catColor[mem.category] || 'bg-muted text-muted-foreground border-border'}`}>
                      {mem.category.replace('_',' ')}
                    </span>
                    <span className="text-xs text-muted-foreground font-mono">{mem.type}</span>
                    <div className="flex items-center gap-0.5">
                      {Array.from({ length: Math.min(10, mem.importance) }).map((_, i) => (
                        <span key={i} className={`text-xs ${i < mem.importance ? 'text-primary' : 'text-muted-foreground/20'}`}>●</span>
                      ))}
                    </div>
                  </div>
                  <div className="font-mono font-semibold text-sm mt-1">{mem.title}</div>
                  <div className="text-xs text-muted-foreground mt-1 leading-relaxed line-clamp-2">{mem.content}</div>
                  <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground font-mono">
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {new Date(mem.createdAt!).toLocaleDateString()}</span>
                    <span>accessed {mem.accessCount}×</span>
                    {tags.length > 0 && tags.slice(0,3).map((t: string) => (
                      <span key={t} className="px-1.5 py-0.5 bg-muted rounded text-xs">{t}</span>
                    ))}
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="w-7 h-7 text-muted-foreground hover:text-red-400 flex-shrink-0"
                  onClick={() => deleteMem.mutate(mem.id)} data-testid={`button-delete-memory-${mem.id}`}>
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
