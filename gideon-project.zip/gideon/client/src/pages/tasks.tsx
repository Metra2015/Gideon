import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { CheckSquare, Plus, Play, X, AlertTriangle, Cpu, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Task, Agent, Project } from '@shared/schema';

const statusColor: Record<string,string> = {
  pending:'text-blue-400', in_progress:'text-yellow-400',
  completed:'text-green-400', failed:'text-red-400', cancelled:'text-muted-foreground',
};
const priorityColor: Record<string,string> = {
  low:'text-muted-foreground', medium:'text-yellow-400', high:'text-orange-400', critical:'text-red-400',
};

export default function TasksPage() {
  const { toast } = useToast();
  const [filter, setFilter] = useState('all');
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: '', description: '', priority: 'medium', projectId: '', riskScore: 0 });

  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ['/api/tasks', filter],
    queryFn: () => apiRequest('GET', `/api/tasks${filter !== 'all' ? `?status=${filter}` : ''}`).then(r => r.json()),
  });
  const { data: agents = [] } = useQuery<Agent[]>({ queryKey: ['/api/agents'] });
  const { data: projects = [] } = useQuery<Project[]>({ queryKey: ['/api/projects'] });

  const createTask = useMutation({
    mutationFn: (data: typeof form) => apiRequest('POST', '/api/tasks', {
      ...data, riskScore: Number(data.riskScore),
      projectId: data.projectId ? Number(data.projectId) : undefined,
    }).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      setOpen(false);
      toast({ title: "Task created" });
    },
  });

  const updateStatus = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) =>
      apiRequest('PATCH', `/api/tasks/${id}`, { status, ...(status === 'in_progress' ? { startedAt: new Date() } : {}), ...(status === 'completed' ? { completedAt: new Date() } : {}) }).then(r => r.json()),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/tasks'] }),
  });

  const deleteTask = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE', `/api/tasks/${id}`).then(r => r.json()),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/tasks'] }),
  });

  const executeTask = useMutation({
    mutationFn: (id: number) => apiRequest('POST', '/api/llm/execute-task', { taskId: id }).then(r => r.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/memories'] });
      toast({ title: 'Task executed', description: 'LLM completed the task. Result stored in memory.' });
    },
    onError: () => toast({ title: 'Execution failed', description: 'Check Ollama or API key in Settings.', variant: 'destructive' }),
  });

  const stats = {
    total: tasks.length,
    pending: tasks.filter(t=>t.status==='pending').length,
    running: tasks.filter(t=>t.status==='in_progress').length,
    done: tasks.filter(t=>t.status==='completed').length,
  };

  return (
    <div className="space-y-4 max-w-5xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-mono font-bold text-lg">Task Planner</h1>
          <p className="text-xs text-muted-foreground font-mono">{stats.running} running · {stats.pending} queued · {stats.done} done</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" className="font-mono gap-1.5" data-testid="button-new-task">
              <Plus className="w-3.5 h-3.5" /> New Task
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader><DialogTitle className="font-mono">Create Task</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div>
                <Label className="font-mono text-xs">Title</Label>
                <Input className="mt-1 font-mono" value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))} placeholder="What needs to be done..." data-testid="input-task-title" />
              </div>
              <div>
                <Label className="font-mono text-xs">Description</Label>
                <Textarea className="mt-1 font-mono text-xs" rows={3} value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))} data-testid="input-task-desc" />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label className="font-mono text-xs">Priority</Label>
                  <Select value={form.priority} onValueChange={v=>setForm(f=>({...f,priority:v}))}>
                    <SelectTrigger className="mt-1" data-testid="select-priority"><SelectValue /></SelectTrigger>
                    <SelectContent>{['low','medium','high','critical'].map(p=><SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="font-mono text-xs">Project</Label>
                  <Select value={form.projectId} onValueChange={v=>setForm(f=>({...f,projectId:v}))}>
                    <SelectTrigger className="mt-1" data-testid="select-project"><SelectValue placeholder="None" /></SelectTrigger>
                    <SelectContent><SelectItem value="">None</SelectItem>{projects.map(p=><SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="font-mono text-xs">Risk Score (0-10)</Label>
                  <Input type="number" min={0} max={10} className="mt-1 font-mono" value={form.riskScore} onChange={e=>setForm(f=>({...f,riskScore:Number(e.target.value)}))} data-testid="input-risk" />
                </div>
              </div>
              {form.riskScore >= 8 && (
                <div className="flex items-center gap-2 p-2 bg-red-500/10 border border-red-500/30 rounded text-xs text-red-400 font-mono">
                  <AlertTriangle className="w-3.5 h-3.5" /> High risk — will require explicit approval before execution
                </div>
              )}
              <Button className="w-full font-mono" onClick={()=>createTask.mutate(form)} disabled={!form.title} data-testid="button-submit-task">
                Create Task
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Status filters */}
      <div className="flex gap-1.5">
        {['all','pending','in_progress','completed','failed'].map(s=>(
          <Button key={s} variant={filter===s?'default':'outline'} size="sm" className="font-mono text-xs" onClick={()=>setFilter(s)} data-testid={`filter-${s}`}>
            {s==='all'?'All':s.replace('_',' ')}
          </Button>
        ))}
      </div>

      {/* Task list */}
      <div className="space-y-2">
        {tasks.length === 0 && (
          <div className="gideon-panel p-8 text-center">
            <CheckSquare className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-xs text-muted-foreground font-mono">No tasks. Use the Terminal to execute intents.</p>
          </div>
        )}
        {tasks.map(task => {
          const steps = (() => { try { return JSON.parse(task.steps); } catch { return []; } })();
          return (
            <div key={task.id} className="gideon-panel p-3 hover:border-primary/30 transition-colors" data-testid={`task-card-${task.id}`}>
              <div className="flex items-start gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`font-mono text-xs font-semibold ${statusColor[task.status]}`}>{task.status.replace('_',' ')}</span>
                    <span className={`text-xs font-mono ${priorityColor[task.priority]}`}>{task.priority}</span>
                    <span className={`text-xs font-mono ${task.riskScore >= 8 ? 'text-red-400' : task.riskScore >= 5 ? 'text-yellow-400' : 'text-muted-foreground'}`}>
                      risk:{task.riskScore}/10
                    </span>
                  </div>
                  <div className="font-mono font-semibold text-sm mt-1">{task.title}</div>
                  {task.description && <div className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{task.description}</div>}
                  {steps.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {steps.map((step: {step:number;label:string;status:string}, i: number) => (
                        <span key={i} className={`text-xs font-mono px-1.5 py-0.5 rounded border
                          ${step.status==='completed'?'text-green-400 border-green-500/20 bg-green-500/5':
                            step.status==='active'?'text-primary border-primary/30 bg-primary/10':
                            'text-muted-foreground border-border bg-muted/20'}`}>
                          {step.step}. {step.label}
                        </span>
                      ))}
                    </div>
                  )}
                  {task.result && <div className="mt-1.5 text-xs text-muted-foreground font-mono bg-muted/20 p-1.5 rounded line-clamp-2">{task.result}</div>}
                </div>
                <div className="flex gap-1 flex-shrink-0">
                  {task.status === 'pending' && (
                    <Button variant="ghost" size="icon" className="w-7 h-7 text-green-400" onClick={()=>updateStatus.mutate({id:task.id,status:'in_progress'})} data-testid={`button-start-${task.id}`}>
                      <Play className="w-3.5 h-3.5" />
                    </Button>
                  )}
                  {task.status === 'in_progress' && (
                    <Button variant="ghost" size="icon" className="w-7 h-7 text-green-400" onClick={()=>updateStatus.mutate({id:task.id,status:'completed'})} data-testid={`button-complete-${task.id}`}>
                      <CheckSquare className="w-3.5 h-3.5" />
                    </Button>
                  )}
                  {(task.status === 'pending' || task.status === 'in_progress') && (
                    <Button variant="ghost" size="icon" className="w-7 h-7 text-primary" title="Execute with LLM"
                      onClick={() => executeTask.mutate(task.id)}
                      disabled={executeTask.isPending}
                      data-testid={`button-llm-exec-${task.id}`}>
                      {executeTask.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Cpu className="w-3.5 h-3.5" />}
                    </Button>
                  )}
                  <Button variant="ghost" size="icon" className="w-7 h-7 text-muted-foreground hover:text-red-400" onClick={()=>deleteTask.mutate(task.id)} data-testid={`button-delete-task-${task.id}`}>
                    <X className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
