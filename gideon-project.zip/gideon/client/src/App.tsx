import { Switch, Route, Router } from 'wouter';
import { useHashLocation } from 'wouter/use-hash-location';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from './lib/queryClient';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { SidebarProvider } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/app-sidebar';
import { TopBar } from '@/components/top-bar';

import Dashboard from '@/pages/dashboard';
import Memory from '@/pages/memory';
import Agents from '@/pages/agents';
import Tasks from '@/pages/tasks';
import Projects from '@/pages/projects';
import Files from '@/pages/files';
import Skills from '@/pages/skills';
import Schedule from '@/pages/schedule';
import Terminal from '@/pages/terminal';
import Settings from '@/pages/settings';
import Research from '@/pages/research';
import Coding from '@/pages/coding';
import NotFound from '@/pages/not-found';

const sidebarStyle = {
  "--sidebar-width": "15rem",
  "--sidebar-width-icon": "3.5rem",
} as React.CSSProperties;

function AppLayout() {
  return (
    <SidebarProvider style={sidebarStyle} defaultOpen={true}>
      <div className="flex h-screen w-full overflow-hidden bg-background">
        <AppSidebar />
        <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
          <TopBar />
          <main className="flex-1 overflow-y-auto p-4">
            <Switch>
              <Route path="/" component={Dashboard} />
              <Route path="/memory" component={Memory} />
              <Route path="/agents" component={Agents} />
              <Route path="/tasks" component={Tasks} />
              <Route path="/projects" component={Projects} />
              <Route path="/files" component={Files} />
              <Route path="/skills" component={Skills} />
              <Route path="/schedule" component={Schedule} />
              <Route path="/terminal" component={Terminal} />
              <Route path="/settings" component={Settings} />
              <Route path="/research" component={Research} />
              <Route path="/coding" component={Coding} />
              <Route component={NotFound} />
            </Switch>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router hook={useHashLocation}>
          <AppLayout />
        </Router>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
