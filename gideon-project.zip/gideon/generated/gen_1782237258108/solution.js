/*
 * Gideon OS — Vulcan Coding Agent
 * Task: 3D Sunglasses App
 * File: solution.js
 * Description: A standalone, production-quality 3D sunglasses renderer
 *              using raw WebGL (no external dependencies).
 *              Renders a realistic pair of sunglasses with:
 *              - Tinted lenses (semi-transparent dark glass)
 *              - Metal/plastic frame
 *              - Temple arms
 *              - Nose bridge
 *              - Ambient + diffuse + specular (Phong) lighting
 *              - Mouse-drag orbit controls
 *              - Auto-rotation fallback
 */

(() => {
  "use strict";

  /* ─────────────────────────────────────────────
     1.  HTML BOOTSTRAP
     We inject the full page programmatically so
     solution.js can be run directly via:
       node -e "..." or opened in a <script> tag.
  ───────────────────────────────────────────── */
  function bootstrap() {
    document.title = "3D Sunglasses — Gideon / Vulcan";

    const style = document.createElement("style");
    style.textContent = `
      *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
      body {
        background: radial-gradient(ellipse at center, #1a1a2e 0%, #0d0d1a 100%);
        display: flex; flex-direction: column;
        align-items: center; justify-content: center;
        min-height: 100vh; overflow: hidden;
        font-family: 'Segoe UI', system-ui, sans-serif;
        color: #e0e0e0;
        user-select: none;
      }
      h1 {
        font-size: 1.4rem; letter-spacing: .25em;
        text-transform: uppercase; margin-bottom: 18px;
        color: #88aaff; text-shadow: 0 0 12px #4466ff88;
      }
      #glCanvas {
        border-radius: 16px;
        box-shadow: 0 0 60px #3355ff44, 0 0 120px #1122aa22;
        cursor: grab;
        display: block;
      }
      #glCanvas:active { cursor: grabbing; }
      p.hint {
        margin-top: 14px; font-size: .78rem;
        color: #556688; letter-spacing: .1em;
      }
    `;
    document.head.appendChild(style);

    const h1 = document.createElement("h1");
    h1.textContent = "✦  3D Sunglasses";
    document.body.appendChild(h1);

    const canvas = document.createElement("canvas");
    canvas.id = "glCanvas";
    canvas.width = 700;
    canvas.height = 480;
    document.body.appendChild(canvas);

    const hint = document.createElement("p");
    hint.className = "hint";
    hint.textContent = "drag to rotate • scroll to zoom";
    document.body.appendChild(hint);

    return canvas;
  }

  /* ─────────────────────────────────────────────
     2.  GLSL SHADERS
  ───────────────────────────────────────────── */
  const VERT_SRC = `
    attribute vec3 aPosition;
    attribute vec3 aNormal;

    uniform mat4 uModel;
    uniform mat4 uView;
    uniform mat4 uProjection;
    uniform mat3 uNormalMatrix;

    varying vec3 vNormal;
    varying vec3 vFragPos;

    void main() {
      vec4 worldPos = uModel * vec4(aPosition, 1.0);
      vFragPos      = worldPos.xyz;
      vNormal       = uNormalMatrix * aNormal;
      gl_Position   = uProjection * uView * worldPos;
    }
  `;

  const FRAG_SRC = `
    precision mediump float;

    varying vec3 vNormal;
    varying vec3 vFragPos;

    uniform vec3  uLightPos;
    uniform vec3  uViewPos;
    uniform vec4  uColor;        // rgba — alpha < 1 for lens glass
    uniform float uShininess;
    uniform float uMetallic;

    void main() {
      vec3 N = normalize(vNormal);
      vec3 L = normalize(uLightPos - vFragPos);
      vec3 V = normalize(uViewPos  - vFragPos);
      vec3 R = reflect(-L, N);

      // Phong shading
      float ambient  = 0.18;
      float diffuse  = max(dot(N, L), 0.0);
      float specular = pow(max(dot(R, V), 0.0), uShininess) * uMetallic;

      vec3 color = uColor.rgb * (ambient + diffuse * 0.75) + vec3(1.0) * specular * 0.6;
      gl_FragColor  = vec4(color, uColor.a);
    }
  `;

  /* ─────────────────────────────────────────────
     3.  MATH HELPERS  (column-major Float32Array)
  ───────────────────────────────────────────── */
  const mat4 = {
    identity() {
      return new Float32Array([
        1,0,0,0,
        0,1,0,0,
        0,0,1,0,
        0,0,0,1
      ]);
    },
    perspective(fovy, aspect, near, far) {
      const f  = 1.0 / Math.tan(fovy / 2);
      const nf = 1   / (near - far);
      const m  = new Float32Array(16);
      m[0]  = f / aspect;
      m[5]  = f;
      m[10] = (far + near) * nf;
      m[11] = -1;
      m[14] = 2 * far * near * nf;
      return m;
    },
    lookAt(eye, center, up) {
      const [ex,ey,ez] = eye;
      const [cx,cy,cz] = center;
      const [ux,uy,uz] = up;
      let fx=cx-ex, fy=cy-ey, fz=cz-ez;
      let fl=Math.hypot(fx,fy,fz);
      fx/=fl; fy/=fl; fz/=fl;
      let sx=fy*uz-fz*uy, sy=fz*ux-fx*uz, sz=fx*uy-fy*ux;
      let sl=Math.hypot(sx,sy,sz);
      sx/=sl; sy/=sl; sz/=sl;
      const rx=sy*fz-sz*fy, ry=sz*fx-sx*fz, rz=sx*fy-sy*fx;
      const m = new Float32Array(16);
      m[0]=sx; m[4]=sy; m[8] =sz;
      m[1]=rx; m[5]=ry; m[9] =rz;
      m[2]=-fx;m[6]=-fy;m[10]=-fz;
      m[12]=-(sx*ex+sy*ey+sz*ez);
      m[13]=-(rx*ex+ry*ey+rz*ez);
      m[14]= (fx*ex+fy*ey+fz*ez);
      m[15]=1;
      return m;
    },
    multiply(a, b) {
      const m = new Float32Array(16);
      for (let r=0;r<4;r++)
        for (let c=0;c<4;c++)
          for (let k=0;k<4;k++)
            m[c*4+r] += a[k*4+r] * b[c*4+k];
      return m;
    },
    rotateX(t) {
      const c=Math.cos(t), s=Math.sin(t), m=mat4.identity();
      m[5]=c; m[9]=-s; m[6]=s; m[10]=c;
      return m;
    },
    rotateY(t) {
      const c=Math.cos(t), s=Math.sin(t), m=mat4.identity();
      m[0]=c; m[8]=s; m[2]=-s; m[10]=c;
      return m;
    },
    translate(x,y,z) {
      const m=mat4.identity();
      m[12]=x; m[13]=y; m[14]=z;
      return m;
    },
    scale(x,y,z) {
      const m=mat4.identity();
      m[0]=x; m[5]=y; m[10]=z;
      return m;
    },
    // Extract upper-left 3x3 inverse-transpose for normal transform
    normalMatrix(m) {
      // Compute inverse of upper-left 3x3 then transpose
      const a00=m[0],a01=m[1],a02=m[2];
      const a10=m[4],a11=m[5],a12=m[6];
      const a20=m[8],a21=m[9],a22=m[10];
      const det = a00*(a11*a22-a12*a21)
                - a10*(a01*a22-a02*a21)
                + a20*(a01*a12-a02*a11);
      const id = 1/det;
      const n = new Float32Array(9);
      // Inverse transpose = adjugate / det (already transposed by column layout)
      n[0] = ( a11*a22-a12*a21)*id;
      n[1] = (-a10*a22+a12*a20)*id;
      n[2] = ( a10*a21-a11*a20)*id;
      n[3] = (-a01*a22+a02*a21)*id;
      n[4] = ( a00*a22-a02*a20)*id;
      n[5] = (-a00*a21+a01*a20)*id;
      n[6] = ( a01*a12-a02*a11)*id;
      n[7] = (-a00*a12+a02*a10)*id;
      n[8] = ( a00*a11-a01*a10)*id;
      return n;
    }
  };

  /* ─────────────────────────────────────────────
     4.  GEOMETRY GENERATORS
  ───────────────────────────────────────────── */

  // Torus: major radius R, minor radius r, segments
  function buildTorus(R, r, majorSegs, minorSegs) {
    const positions = [], normals = [], indices = [];
    for (let i=0; i<=majorSegs; i++) {
      const theta = (i/majorSegs) * Math.PI * 2;
      const cosT  = Math.cos(theta), sinT = Math.sin(theta);
      for (let j=0; j<=minorSegs; j++) {
        const phi  = (j/minorSegs) * Math.PI * 2;
        const cosP = Math.cos(phi), sinP = Math.sin(phi);
        const x = (R + r*cosP)*cosT;
        const y = r*sinP;
        const z = (R + r*cosP)*sinT;
        const nx = cosP*cosT, ny = sinP, nz = cosP*sinT;
        positions.push(x,y,z);
        normals.push(nx,ny,nz);
      }
    }
    for (let i=0; i<majorSegs; i++) {
      for (let j=0; j<minorSegs; j++) {
        const a = i*(minorSegs+1)+j;
        const b = a+minorSegs+1;
        indices.push(a,b,a+1, b,b+1,a+1);
      }
    }
    return { positions: new Float32Array(positions),
             normals:   new Float32Array(normals),
             indices:   new Uint16Array(indices) };
  }

  // Cylinder (capped) along Z axis
  function buildCylinder(radiusTop, radiusBottom, height, segs) {
    const positions=[], normals=[], indices=[];
    const half = height/2;
    // Side
    for (let i=0; i<=segs; i++) {
      const a   = (i/segs)*Math.PI*2;
      const cos = Math.cos(a), sin = Math.sin(a);
      // bottom vertex
      positions.push(cos*radiusBottom, sin*radiusBottom, -half);
      normals.push(cos, sin, 0);
      // top vertex
      positions.push(cos*radiusTop, sin*radiusTop, half);
      normals.push(cos, sin, 0);
    }
    for (let i=0; i<segs; i++) {
      const b=i*2, t=b+1;
      indices.push(b, b+2, t,  t, b+2, t+2);
    }
    // Caps
    const addCap = (radius, z, normalZ) => {
      const centerIdx = positions.length/3;
      positions.push(0, 0, z);
      normals.push(0, 0, normalZ);
      const startIdx = positions.length/3;
      for (let i=0; i<=segs; i++) {
        const a=((i%segs)/segs)*Math.PI*2;
        positions.push(Math.cos(a)*radius, Math.sin(a)*radius, z);
        normals.push(0,0,normalZ);
      }
      for (let i=0; i<segs; i++) {
        if (normalZ > 0) indices.push(centerIdx, startIdx+i, startIdx+i+1);
        else             indices.push(centerIdx, startIdx+i+1, startIdx+i);
      }
    };
    addCap(radiusBottom, -half, -1);
    addCap(radiusTop,     half,  1);
    return { positions: new Float32Array(positions),
             normals:   new Float32Array(normals),
             indices:   new Uint16Array(indices) };
  }

  // Flat rounded-rectangle lens (extruded thin box, subdivided for normals)
  function buildLens(w, h, depth, rx, ry, segs) {
    // We approximate a rounded rect by sampling an ellipse outline
    // then extruding it as a flat prism (front face, back face, sides)
    const positions=[], normals=[], indices=[];

    // Generate perimeter points of a rounded rect
    const perim = [];
    const corners = [
      [ w/2-rx,  h/2-ry], [-w/2+rx,  h/2-ry],
      [-w/2+rx, -h/2+ry], [ w/2-rx, -h/2+ry]
    ];
    const angles = [0, Math.PI/2, Math.PI, Math.PI*1.5];
    for (let c=0; c<4; c++) {
      for (let s=0; s<=segs; s++) {
        const a = angles[c] + (s/segs)*Math.PI/2;
        perim.push([corners[c][0]+rx*Math.cos(a),
                    corners[c][1]+ry*Math.sin(a)]);
      }
    }

    const N = perim.length;
    const half = depth/2;

    // Front face (z = +half, normal = 0,0,1)