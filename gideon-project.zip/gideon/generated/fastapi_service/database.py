"""
database.py — async SQLAlchemy engine + session factory.

We use an async engine (asyncpg driver) so FastAPI's async route handlers
never block the event loop on DB I/O.
"""
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from config import settings


# ── Engine ────────────────────────────────────────────────────────────────────
# DATABASE_URL must use the "postgresql+asyncpg" scheme.
# Example: postgresql+asyncpg://user:pass@localhost:5432/mydb
engine = create_async_engine(
    settings.database_url,
    echo=settings.db_echo,      # SQL logging — disable in production
    pool_pre_ping=True,         # cheap liveness check before checkout
    pool_size=10,
    max_overflow=20,
)

# ── Session factory ───────────────────────────────────────────────────────────
AsyncSessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,     # keep ORM objects usable after commit
    autoflush=False,
    autocommit=False,
)


# ── Base class for ORM models ─────────────────────────────────────────────────
class Base(DeclarativeBase):
    pass


# ── Dependency — yields a session, rolls back on error, always closes ─────────
async def get_db() -> AsyncSession:
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
