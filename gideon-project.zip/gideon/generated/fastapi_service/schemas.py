"""
schemas.py — Pydantic v2 request / response models.
"""
import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field


# ── Shared config ─────────────────────────────────────────────────────────────
class _OrmBase(BaseModel):
    model_config = ConfigDict(from_attributes=True)


# ── Auth / Token ──────────────────────────────────────────────────────────────
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenPayload(BaseModel):
    sub: str          # user id (UUID as string)
    exp: int | None = None


# ── User ──────────────────────────────────────────────────────────────────────
class UserCreate(BaseModel):
    email: EmailStr
    username: str = Field(..., min_length=3, max_length=100)
    password: str = Field(..., min_length=8, max_length=128)


class UserRead(_OrmBase):
    id: uuid.UUID
    email: str
    username: str
    is_active: bool
    is_superuser: bool
    created_at: datetime
    updated_at: datetime


class UserUpdate(BaseModel):
    email: EmailStr | None = None
    username: str | None = Field(default=None, min_length=3, max_length=100)
    password: str | None = Field(default=None, min_length=8, max_length=128)


# ── Post ──────────────────────────────────────────────────────────────────────
class PostCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=255)
    body: str = Field(default="")
    is_published: bool = False


class PostRead(_OrmBase):
    id: uuid.UUID
    title: str
    body: str
    is_published: bool
    author_id: uuid.UUID
    created_at: datetime
    updated_at: datetime


class PostUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=255)
    body: str | None = None
    is_published: bool | None = None
