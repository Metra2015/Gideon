# solution.py
# Gideon / Vulcan — Full-Stack FastAPI Service (Multi-file bundle)
# This single file writes all project files to disk when executed directly,
# or can be imported to access the write_files() helper programmatically.
#
# Usage:  python solution.py
# Effect: Creates the following files in ./fastapi_service/
#   main.py, auth.py, models.py, schemas.py, database.py, config.py,
#   requirements.txt, README.md

import os
import textwrap

PROJECT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fastapi_service")

FILES: dict[str, str] = {}

# ---------------------------------------------------------------------------
# requirements.txt
# ---------------------------------------------------------------------------
FILES["requirements.txt"] = textwrap.dedent("""\
    fastapi==0.111.0
    uvicorn[standard]==0.29.0
    sqlalchemy==2.0.30
    asyncpg==0.29.0
    alembic==1.13.1
    pydantic==2.7.1
    pydantic-settings==2.2.1
    python-jose[cryptography]==3.3.0
    passlib[bcrypt]==1.7.4
    python-multipart==0.0.9
    greenlet==3.0.3
""")

# ---------------------------------------------------------------------------
# config.py  (was missing — database.py imports it but it was never generated)
# ---------------------------------------------------------------------------
FILES["config.py"] = textwrap.dedent('''\
    """
    config.py — centralised settings loaded from environment variables / .env file.
    """
    from pydantic_settings import BaseSettings, SettingsConfigDict


    class Settings(BaseSettings):
        # Database
        database_url: str = "postgresql+asyncpg://postgres:password@localhost:5432/appdb"
        db_echo: bool = False

        # JWT / Auth
        secret_key: str = "change-me-in-production-use-a-long-random-string"
        algorithm: str = "HS256"
        access_token_expire_minutes: int = 30

        # App
        app_title: str = "FastAPI Service"
        app_version: str = "1.0.0"
        debug: bool = False

        model_config = SettingsConfigDict(
            env_file=".env",
            env_file_encoding="utf-8",
            case_sensitive=False,
        )


    settings = Settings()
''')

# ---------------------------------------------------------------------------
# database.py
# ---------------------------------------------------------------------------
FILES["database.py"] = textwrap.dedent('''\
    """
    database.py — async SQLAlchemy engine + session factory.

    We use async engine (asyncpg driver) so FastAPI\'s async route handlers
    never block the event loop on DB I/O.
    """
    from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
    from sqlalchemy.orm import DeclarativeBase

    from config import settings


    # -------------------------------------------------------------------------
    # Engine
    # -------------------------------------------------------------------------
    # The DATABASE_URL must use the "postgresql+asyncpg" scheme.
    # Example: postgresql+asyncpg://user:pass@localhost:5432/mydb
    engine = create_async_engine(
        settings.database_url,
        echo=settings.db_echo,      # SQL logging — disable in production
        pool_pre_ping=True,         # cheap liveness check before checkout
        pool_size=10,
        max_overflow=20,
    )

    # -------------------------------------------------------------------------
    # Session factory
    # -------------------------------------------------------------------------
    AsyncSessionLocal = async_sessionmaker(
        bind=engine,
        class_=AsyncSession,
        expire_on_commit=False,     # keep ORM objects usable after commit
        autoflush=False,
        autocommit=False,
    )


    # -------------------------------------------------------------------------
    # Base class for ORM models
    # -------------------------------------------------------------------------
    class Base(DeclarativeBase):
        pass


    # -------------------------------------------------------------------------
    # Dependency — yields a session, rolls back on error, always closes
    # -------------------------------------------------------------------------
    async def get_db() -> AsyncSession:
        async with AsyncSessionLocal() as session:
            try:
                yield session
                await session.commit()
            except Exception:
                await session.rollback()
                raise
''')

# ---------------------------------------------------------------------------
# models.py
# ---------------------------------------------------------------------------
FILES["models.py"] = textwrap.dedent('''\
    """
    models.py — SQLAlchemy ORM models backed by PostgreSQL.
    """
    import uuid
    from datetime import datetime, timezone

    from sqlalchemy import Boolean, DateTime, ForeignKey, String, Text
    from sqlalchemy.dialects.postgresql import UUID
    from sqlalchemy.orm import Mapped, mapped_column, relationship

    from database import Base


    def _utcnow() -> datetime:
        return datetime.now(timezone.utc)


    class User(Base):
        __tablename__ = "users"

        id: Mapped[uuid.UUID] = mapped_column(
            UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True
        )
        email: Mapped[str] = mapped_column(
            String(255), unique=True, nullable=False, index=True
        )
        username: Mapped[str] = mapped_column(
            String(100), unique=True, nullable=False, index=True
        )
        hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
        is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
        is_superuser: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
        created_at: Mapped[datetime] = mapped_column(
            DateTime(timezone=True), default=_utcnow, nullable=False
        )
        updated_at: Mapped[datetime] = mapped_column(
            DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
        )

        # Relationships
        posts: Mapped[list["Post"]] = relationship(
            "Post", back_populates="author", cascade="all, delete-orphan"
        )

        def __repr__(self) -> str:
            return f"<User id={self.id} email={self.email!r}>"


    class Post(Base):
        __tablename__ = "posts"

        id: Mapped[uuid.UUID] = mapped_column(
            UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True
        )
        title: Mapped[str] = mapped_column(String(255), nullable=False)
        body: Mapped[str] = mapped_column(Text, nullable=False, default="")
        is_published: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
        created_at: Mapped[datetime] = mapped_column(
            DateTime(timezone=True), default=_utcnow, nullable=False
        )
        updated_at: Mapped[datetime] = mapped_column(
            DateTime(timezone=True), default=_utcnow, onupdate=_utcnow, nullable=False
        )

        author_id: Mapped[uuid.UUID] = mapped_column(
            UUID(as_uuid=True),
            ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
            index=True,
        )
        author: Mapped["User"] = relationship("User", back_populates="posts")

        def __repr__(self) -> str:
            return f"<Post id={self.id} title={self.title!r}>"
''')

# ---------------------------------------------------------------------------
# schemas.py
# ---------------------------------------------------------------------------
FILES["schemas.py"] = textwrap.dedent('''\
    """
    schemas.py — Pydantic v2 request / response models.
    """
    import uuid
    from datetime import datetime

    from pydantic import BaseModel, ConfigDict, EmailStr, Field


    # ── Shared config ──────────────────────────────────────────────────────────
    class _OrmBase(BaseModel):
        model_config = ConfigDict(from_attributes=True)


    # ── Auth / Token ───────────────────────────────────────────────────────────
    class Token(BaseModel):
        access_token: str
        token_type: str = "bearer"


    class TokenPayload(BaseModel):
        sub: str          # user id (UUID as string)
        exp: int | None = None


    # ── User ───────────────────────────────────────────────────────────────────
    class UserCreate(BaseModel):
        email: EmailStr
        username: str = Field(..., min_length=3, max_length=100)
        password: str = Field(..., min_length=8, max_length=128)


    class UserRead(_OrmBase):
        id: uuid.UUID
        email: str
        username: str
        is_active: bool
        is_superuser: bool
        created_at: datetime
        updated_at: datetime


    class UserUpdate(BaseModel):
        email: EmailStr | None = None
        username: str | None = Field(default=None, min_length=3, max_length=100)
        password: str | None = Field(default=None, min_length=8, max_length=128)


    # ── Post ───────────────────────────────────────────────────────────────────
    class PostCreate(BaseModel):
        title: str = Field(..., min_length=1, max_length=255)
        body: str = Field(default="")
        is_published: bool = False


    class PostRead(_OrmBase):
        id: uuid.UUID
        title: str
        body: str
        is_published: bool
        author_id: uuid.UUID
        created_at: datetime
        updated_at: datetime


    class PostUpdate(BaseModel):
        title: str | None = Field(default=None, min_length=1, max_length=255)
        body: str | None = None
        is_published: bool | None = None
''')

# ---------------------------------------------------------------------------
# auth.py
# ---------------------------------------------------------------------------
FILES["auth.py"] = textwrap.dedent('''\
    """
    auth.py — password hashing, JWT creation/verification, and the
              get_current_user FastAPI dependency.
    """
    from datetime import datetime, timedelta, timezone
    from typing import Annotated

    from fastapi import Depends, HTTPException, status
    from fastapi.security import OAuth2PasswordBearer
    from jose import JWTError, jwt
    from passlib.context import CryptContext
    from sqlalchemy import select
    from sqlalchemy.ext.asyncio import AsyncSession

    from config import settings
    from database import get_db
    from models import User
    from schemas import TokenPayload

    # ── Password hashing ──────────────────────────────────────────────────────
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

    oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


    def verify_password(plain: str, hashed: str) -> bool:
        return pwd_context.verify(plain, hashed)


    def hash_password(plain: str) -> str:
        return pwd_context.hash(plain)


    # ── JWT ───────────────────────────────────────────────────────────────────
    def create_access_token(subject: str, expires_delta: timedelta | None = None) -> str:
        expire = datetime.now(timezone.utc) + (
            expires_delta or timedelta(minutes=settings.access_token_expire_minutes)
        )
        payload = {"sub": subject, "exp": expire}
        return jwt.encode(payload, settings.secret_key, algorithm=settings.algorithm)


    def decode_token(token: str) -> TokenPayload:
        try:
            raw = jwt.decode(token, settings.secret_key, algorithms=[settings.algorithm])
            return TokenPayload(**raw)
        except JWTError as exc:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials",
                headers={"WWW-Authenticate": "Bearer"},
            ) from exc


    # ── Dependencies ──────────────────────────────────────────────────────────
    async def get_current_user(
        token: Annotated[str, Depends(oauth2_scheme)],
        db: Annotated[AsyncSession, Depends(get_db)],
    ) -> User:
        payload = decode_token(token)
        result = await db.execute(select(User).where(User.id == payload.sub))
        user = result.scalar_one_or_none()
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found",
                headers={"WWW-Authenticate": "Bearer"},
            )
        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Inactive user",
            )
        return user


    async def get_current_superuser(
        current_user: Annotated[User, Depends(get_current_user)],
    ) -> User:
        if not current_user.is_superuser:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient privileges",
            )
        return current_user
''')

# ---------------------------------------------------------------------------
# main.py
# ---------------------------------------------------------------------------
FILES["main.py"] = textwrap.dedent('''\
    """
    main.py — FastAPI application entry point.

    Routers
    -------
    /auth   — register, login (returns JWT)
    /users  — profile read/update (authenticated)
    /posts  — CRUD posts (authenticated)
    """
    import uuid
    from contextlib import asynccontextmanager
    from typing import Annotated

    from fastapi import Depends, FastAPI, HTTPException, status
    from fastapi.security import OAuth2PasswordRequestForm
    from sqlalchemy import select
    from sqlalchemy.ext.asyncio import AsyncSession

    from auth import (
        create_access_token,
        get_current_superuser,
        get_current_user,
        hash_password,
        verify_password,
    )
    from config import settings
    from database import Base, engine, get_db
    from models import Post, User
    from schemas import (
        PostCreate,
        PostRead,
        PostUpdate,
        Token,
        UserCreate,
        UserRead,
        UserUpdate,
    )


    # ── Lifespan: create tables on startup (use Alembic in production) ─────────
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        yield
        await engine.dispose()


    app = FastAPI(
        title=settings.app_title,
        version=settings.app_version,
        debug=settings.debug,
        lifespan=lifespan,
    )


    # ==========================================================================
    # Auth router
    # ==========================================================================
    @app.post("/auth/register", response_model=UserRead, status_code=status.HTTP_201_CREATED)
    async def register(
        body: UserCreate,
        db: Annotated[AsyncSession, Depends(get_db)],
    ) -> User:
        # Duplicate e-mail / username check
        existing = await db.execute(
            select(User).where(
                (User.email == body.email) | (User.username == body.username)
            )
        )
        if existing.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Email or username already registered",
            )
        user = User(
            email=body.email,
            username=body.username,
            hashed_password=hash_password(body.password),
        )
        db.add(user)
        await db.flush()        # assign PK without committing
        await db.refresh(user)
        return user


    @app.post("/auth/login", response_model=Token)
    async def login(
        form