import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ─── USERS ───────────────────────────────────────────────
export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull().default("Gideon"),
  avatar: text("avatar"),
  preferredModel: text("preferred_model").notNull().default("ollama/llama3"),
  ollamaUrl: text("ollama_url").notNull().default("http://localhost:11434"),
  openaiKey: text("openai_key"),
  anthropicKey: text("anthropic_key"),
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// ─── MEMORY ──────────────────────────────────────────────
export const memories = sqliteTable("memories", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  category: text("category").notNull(), // working | episodic | semantic | procedural | long_term
  type: text("type").notNull(),         // fact | event | process | conversation | project
  title: text("title").notNull(),
  content: text("content").notNull(),
  tags: text("tags").notNull().default("[]"), // JSON array
  projectId: integer("project_id"),
  importance: integer("importance").notNull().default(5), // 1-10
  accessCount: integer("access_count").notNull().default(0),
  expiresAt: integer("expires_at", { mode: "timestamp" }),
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
  updatedAt: integer("updated_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertMemorySchema = createInsertSchema(memories).omit({ id: true, createdAt: true, updatedAt: true, accessCount: true });
export type InsertMemory = z.infer<typeof insertMemorySchema>;
export type Memory = typeof memories.$inferSelect;

// ─── PROJECTS ────────────────────────────────────────────
export const projects = sqliteTable("projects", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  description: text("description"),
  status: text("status").notNull().default("active"), // active | paused | completed | archived
  path: text("path"),
  stack: text("stack").notNull().default("[]"),      // JSON array of tech
  architecture: text("architecture"),                // JSON blob
  decisions: text("decisions").notNull().default("[]"), // JSON array
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
  updatedAt: integer("updated_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertProjectSchema = createInsertSchema(projects).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// ─── TASKS ───────────────────────────────────────────────
export const tasks = sqliteTable("tasks", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  description: text("description"),
  status: text("status").notNull().default("pending"), // pending | in_progress | completed | failed | cancelled
  priority: text("priority").notNull().default("medium"), // low | medium | high | critical
  projectId: integer("project_id"),
  agentId: integer("agent_id"),
  steps: text("steps").notNull().default("[]"),       // JSON array of plan steps
  result: text("result"),
  riskScore: integer("risk_score").notNull().default(0),
  scheduledAt: integer("scheduled_at", { mode: "timestamp" }),
  startedAt: integer("started_at", { mode: "timestamp" }),
  completedAt: integer("completed_at", { mode: "timestamp" }),
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true, createdAt: true, startedAt: true, completedAt: true });
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

// ─── AGENTS ──────────────────────────────────────────────
export const agents = sqliteTable("agents", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  type: text("type").notNull(), // research | coding | automation | vision | voice | data | custom
  status: text("status").notNull().default("idle"), // idle | active | paused | error
  model: text("model").notNull().default("ollama/llama3"),
  capabilities: text("capabilities").notNull().default("[]"), // JSON array
  config: text("config").notNull().default("{}"),             // JSON config blob
  taskCount: integer("task_count").notNull().default(0),
  lastActiveAt: integer("last_active_at", { mode: "timestamp" }),
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertAgentSchema = createInsertSchema(agents).omit({ id: true, createdAt: true, taskCount: true, lastActiveAt: true });
export type InsertAgent = z.infer<typeof insertAgentSchema>;
export type Agent = typeof agents.$inferSelect;

// ─── AGENT RUNS (execution log) ──────────────────────────
export const agentRuns = sqliteTable("agent_runs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  agentId: integer("agent_id").notNull(),
  taskId: integer("task_id"),
  input: text("input").notNull(),
  output: text("output"),
  status: text("status").notNull().default("running"), // running | completed | failed
  tokensUsed: integer("tokens_used").notNull().default(0),
  durationMs: integer("duration_ms"),
  error: text("error"),
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertAgentRunSchema = createInsertSchema(agentRuns).omit({ id: true, createdAt: true });
export type InsertAgentRun = z.infer<typeof insertAgentRunSchema>;
export type AgentRun = typeof agentRuns.$inferSelect;

// ─── SKILLS ──────────────────────────────────────────────
export const skills = sqliteTable("skills", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").notNull().default("general"),
  enabled: integer("enabled", { mode: "boolean" }).notNull().default(true),
  config: text("config").notNull().default("{}"),    // JSON
  agents: text("agents").notNull().default("[]"),    // JSON agent type list
  tools: text("tools").notNull().default("[]"),      // JSON tool list
  workflows: text("workflows").notNull().default("[]"), // JSON workflow list
  version: text("version").notNull().default("1.0.0"),
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertSkillSchema = createInsertSchema(skills).omit({ id: true, createdAt: true });
export type InsertSkill = z.infer<typeof insertSkillSchema>;
export type Skill = typeof skills.$inferSelect;

// ─── FILES ───────────────────────────────────────────────
export const files = sqliteTable("files", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  path: text("path").notNull(),
  type: text("type").notNull(),      // document | image | video | audio | code | archive
  mimeType: text("mime_type"),
  size: integer("size"),
  summary: text("summary"),
  tags: text("tags").notNull().default("[]"),
  projectId: integer("project_id"),
  indexed: integer("indexed", { mode: "boolean" }).notNull().default(false),
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
  indexedAt: integer("indexed_at", { mode: "timestamp" }),
});

export const insertFileSchema = createInsertSchema(files).omit({ id: true, createdAt: true, indexedAt: true });
export type InsertFile = z.infer<typeof insertFileSchema>;
export type File = typeof files.$inferSelect;

// ─── CONVERSATIONS ────────────────────────────────────────
export const conversations = sqliteTable("conversations", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title"),
  messages: text("messages").notNull().default("[]"), // JSON array of {role, content, ts}
  projectId: integer("project_id"),
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
  updatedAt: integer("updated_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertConversationSchema = createInsertSchema(conversations).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;

// ─── SCHEDULED JOBS ──────────────────────────────────────
export const scheduledJobs = sqliteTable("scheduled_jobs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  description: text("description"),
  cron: text("cron"),           // cron expression
  runAt: integer("run_at", { mode: "timestamp" }),
  enabled: integer("enabled", { mode: "boolean" }).notNull().default(true),
  agentType: text("agent_type").notNull(),
  prompt: text("prompt").notNull(),
  lastRunAt: integer("last_run_at", { mode: "timestamp" }),
  nextRunAt: integer("next_run_at", { mode: "timestamp" }),
  runCount: integer("run_count").notNull().default(0),
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertScheduledJobSchema = createInsertSchema(scheduledJobs).omit({ id: true, createdAt: true, lastRunAt: true, nextRunAt: true, runCount: true });
export type InsertScheduledJob = z.infer<typeof insertScheduledJobSchema>;
export type ScheduledJob = typeof scheduledJobs.$inferSelect;
