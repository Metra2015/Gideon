/**
 * Gideon Semantic Memory — Qdrant Layer
 *
 * Stores research findings, extracted insights, and document summaries
 * as vector embeddings for semantic (meaning-based) search.
 *
 * Embedding strategy: we use the LLM to generate a compact embedding-proxy
 * (a dense summary sentence) then use a simple TF-IDF-style hash embedding
 * when a real embedding model isn't available. When Ollama has nomic-embed-text
 * or mxbai-embed-large loaded it uses those; otherwise falls back to a
 * deterministic pseudo-embedding from the LLM's own text representation.
 */

import { QdrantClient } from "@qdrant/js-client-rest";
import { storage } from "./storage";

const QDRANT_URL = process.env.QDRANT_URL || "http://localhost:6333";
const COLLECTION = "gideon_memory";
const VECTOR_SIZE = 384; // matches all-MiniLM-L6-v2 / nomic-embed-text dimensions

export const qdrant = new QdrantClient({ url: QDRANT_URL });

// ── Initialize collection ─────────────────────────────────────────────────
export async function ensureCollection(): Promise<boolean> {
  try {
    const existing = await qdrant.getCollections();
    const found = existing.collections.find(c => c.name === COLLECTION);
    if (!found) {
      await qdrant.createCollection(COLLECTION, {
        vectors: {
          size: VECTOR_SIZE,
          distance: "Cosine",
        },
        optimizers_config: { default_segment_number: 2 },
        replication_factor: 1,
      });
      console.log(`[Qdrant] Created collection: ${COLLECTION}`);
    }
    return true;
  } catch (err) {
    console.error("[Qdrant] Failed to ensure collection:", err);
    return false;
  }
}

// ── Pseudo-embedding from text ────────────────────────────────────────────
// Deterministic 384-dim vector derived from text character frequencies + bigrams.
// Good enough for dev/testing when no embedding model is available.
// Replace with real embeddings (nomic-embed-text via Ollama, OpenAI embeddings) in prod.
export function pseudoEmbed(text: string): number[] {
  const vec = new Array(VECTOR_SIZE).fill(0);
  const normalized = text.toLowerCase().replace(/[^a-z0-9\s]/g, " ").trim();
  const words = normalized.split(/\s+/).filter(Boolean);

  // Character frequency features (dims 0–51)
  for (const ch of normalized) {
    const code = ch.charCodeAt(0);
    if (code >= 97 && code <= 122) vec[code - 97] += 1; // a-z
    if (code >= 48 && code <= 57) vec[26 + (code - 48)] += 1; // 0-9
  }

  // Word hash features (dims 52–383)
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    let h = 5381;
    for (let j = 0; j < w.length; j++) {
      h = ((h << 5) + h) ^ w.charCodeAt(j);
      h = h >>> 0; // unsigned 32-bit
    }
    const idx = 52 + (h % (VECTOR_SIZE - 52));
    vec[idx] += 1 / (i + 1); // position-weighted
  }

  // Bigram features
  for (let i = 0; i < words.length - 1; i++) {
    const bigram = words[i] + "_" + words[i + 1];
    let h = 0;
    for (const c of bigram) h = (h * 31 + c.charCodeAt(0)) >>> 0;
    const idx = 52 + (h % (VECTOR_SIZE - 52));
    vec[idx] += 0.5;
  }

  // L2 normalize
  const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0)) || 1;
  return vec.map(v => v / norm);
}

// ── Try real embedding via Ollama ─────────────────────────────────────────
export async function embed(text: string, ollamaUrl?: string): Promise<number[]> {
  const url = ollamaUrl || "http://localhost:11434";
  try {
    const res = await fetch(`${url}/api/embeddings`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ model: "nomic-embed-text", prompt: text }),
      signal: AbortSignal.timeout(5000),
    });
    if (res.ok) {
      const data = await res.json() as { embedding?: number[] };
      if (data.embedding && data.embedding.length > 0) {
        // Resize to VECTOR_SIZE if needed
        if (data.embedding.length === VECTOR_SIZE) return data.embedding;
        const resized = new Array(VECTOR_SIZE).fill(0);
        for (let i = 0; i < Math.min(data.embedding.length, VECTOR_SIZE); i++) {
          resized[i] = data.embedding[i];
        }
        const norm = Math.sqrt(resized.reduce((s, v) => s + v * v, 0)) || 1;
        return resized.map(v => v / norm);
      }
    }
  } catch {
    // Ollama not available — fall through to pseudo-embed
  }
  return pseudoEmbed(text);
}

// ── Store a research finding in Qdrant ───────────────────────────────────
export interface QdrantPoint {
  id: string;           // UUID
  title: string;
  content: string;
  source_url?: string;
  source_title?: string;
  category: string;     // research | fact | insight | summary | code
  tags: string[];
  project_id?: number;
  memory_id?: number;   // linked SQLite memory record
  importance: number;
  created_at: string;
}

export async function storeResearchFinding(
  point: QdrantPoint,
  ollamaUrl?: string
): Promise<boolean> {
  try {
    await ensureCollection();
    const text = `${point.title}. ${point.content}`;
    const vector = await embed(text, ollamaUrl);

    await qdrant.upsert(COLLECTION, {
      wait: true,
      points: [{
        id: point.id,
        vector,
        payload: {
          ...point,
          tags: point.tags,
        },
      }],
    });
    return true;
  } catch (err) {
    console.error("[Qdrant] Failed to store finding:", err);
    return false;
  }
}

// ── Semantic search ───────────────────────────────────────────────────────
export async function semanticSearch(
  query: string,
  options: { limit?: number; category?: string; projectId?: number; ollamaUrl?: string } = {}
): Promise<QdrantPoint[]> {
  try {
    await ensureCollection();
    const vector = await embed(query, options.ollamaUrl);

    const filter = options.category || options.projectId
      ? {
          must: [
            ...(options.category ? [{ key: "category", match: { value: options.category } }] : []),
            ...(options.projectId ? [{ key: "project_id", match: { value: options.projectId } }] : []),
          ],
        }
      : undefined;

    const results = await qdrant.search(COLLECTION, {
      vector,
      limit: options.limit || 10,
      with_payload: true,
      filter,
    });

    return results.map(r => r.payload as unknown as QdrantPoint);
  } catch (err) {
    console.error("[Qdrant] Search failed:", err);
    return [];
  }
}

// ── Get all stored points ─────────────────────────────────────────────────
export async function getCollectionStats(): Promise<{
  total: number; categories: Record<string, number>; status: string;
}> {
  try {
    const info = await qdrant.getCollection(COLLECTION);
    const scroll = await qdrant.scroll(COLLECTION, { limit: 100, with_payload: true });
    const categories: Record<string, number> = {};
    for (const pt of scroll.points) {
      const cat = (pt.payload?.category as string) || "unknown";
      categories[cat] = (categories[cat] || 0) + 1;
    }
    return {
      total: info.points_count || 0,
      categories,
      status: "online",
    };
  } catch {
    return { total: 0, categories: {}, status: "offline" };
  }
}

// ── Delete a point ────────────────────────────────────────────────────────
export async function deletePoint(id: string): Promise<boolean> {
  try {
    await qdrant.delete(COLLECTION, { wait: true, points: [id] });
    return true;
  } catch {
    return false;
  }
}

// Initialize on module load
ensureCollection().catch(console.error);
