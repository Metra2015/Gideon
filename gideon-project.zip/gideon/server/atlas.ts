/**
 * Atlas — Research Agent
 *
 * Workflow:
 *   Intent
 *     └─ Query Decomposition (LLM)
 *           └─ Firecrawl Search + Scrape
 *                 └─ Multi-step Extraction (LLM)
 *                       └─ Insight Ranking
 *                             └─ Qdrant Storage
 *                                   └─ SQLite Memory
 *                                         └─ Project Brain Log
 */

import FirecrawlApp from "@mendable/firecrawl-js";
import { v4 as uuidv4 } from "uuid";
import { storage } from "./storage";
import { completeLLM } from "./llm";
import { storeResearchFinding, semanticSearch, type QdrantPoint } from "./qdrant";

// ── Types ─────────────────────────────────────────────────────────────────
export interface ResearchIntent {
  query: string;
  projectId?: number;
  maxSources?: number;       // default 5
  extractDepth?: "fast" | "deep"; // default "deep"
  firecrawlKey?: string;
}

export interface ResearchSource {
  url: string;
  title: string;
  rawContent: string;
  statusCode?: number;
}

export interface ResearchInsight {
  title: string;
  content: string;
  relevance: number;      // 0–10
  category: "fact" | "insight" | "code" | "summary" | "process";
  sourceUrl: string;
  sourceTitle: string;
  tags: string[];
}

export interface ResearchResult {
  query: string;
  subQueries: string[];
  sources: { url: string; title: string; indexed: boolean }[];
  insights: ResearchInsight[];
  summary: string;
  memoryIds: number[];
  qdrantIds: string[];
  projectLogId?: number;
  durationMs: number;
  model: string;
  agentId?: number;
}

// ── Step 1: Decompose intent into sub-queries ─────────────────────────────
async function decomposeQuery(
  query: string,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<string[]> {
  const prompt = `You are Gideon's Atlas research agent. Decompose this research intent into 2–4 specific search queries.

Research intent: "${query}"

Return ONLY a JSON array of strings. No explanation. Example:
["query one", "query two", "query three"]`;

  try {
    const result = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 200 });
    const match = result.text.match(/\[.*?\]/s);
    if (match) {
      const parsed = JSON.parse(match[0]) as string[];
      if (Array.isArray(parsed) && parsed.length > 0) return parsed.slice(0, 4);
    }
  } catch {
    // fall through
  }
  // Fallback: use original query + a variation
  return [query, `${query} explained`, `${query} best practices 2026`];
}

// ── Step 2: Scrape sources via Firecrawl ──────────────────────────────────
async function scrapeSources(
  queries: string[],
  maxSources: number,
  firecrawlKey?: string
): Promise<ResearchSource[]> {
  // If no Firecrawl key, do a lightweight fetch of known good sources
  if (!firecrawlKey) {
    return await fallbackFetch(queries, maxSources);
  }

  const app = new FirecrawlApp({ apiKey: firecrawlKey });
  const sources: ResearchSource[] = [];
  const seen = new Set<string>();

  for (const query of queries) {
    if (sources.length >= maxSources) break;
    try {
      // Use Firecrawl's search endpoint
      const searchResult = await app.search(query, {
        limit: Math.min(3, maxSources - sources.length),
        scrapeOptions: {
          formats: ["markdown"],
          onlyMainContent: true,
        },
      });

      if (searchResult.success && searchResult.data) {
        for (const item of searchResult.data) {
          if (sources.length >= maxSources) break;
          const url = item.url || item.metadata?.url || "";
          if (!url || seen.has(url)) continue;
          seen.add(url);
          sources.push({
            url,
            title: item.metadata?.title || item.title || url,
            rawContent: item.markdown || item.content || "",
            statusCode: item.metadata?.statusCode,
          });
        }
      }
    } catch (err) {
      console.error(`[Atlas] Firecrawl search failed for "${query}":`, err);
    }
  }

  return sources;
}

// ── Fallback: fetch URLs directly without Firecrawl ───────────────────────
async function fallbackFetch(queries: string[], maxSources: number): Promise<ResearchSource[]> {
  // Use DuckDuckGo instant answer API (no key needed) + direct fetches
  const sources: ResearchSource[] = [];

  for (const query of queries.slice(0, 2)) {
    if (sources.length >= maxSources) break;
    try {
      // DuckDuckGo instant answers
      const ddgUrl = `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_redirect=1&no_html=1`;
      const resp = await fetch(ddgUrl, {
        signal: AbortSignal.timeout(8000),
        headers: { "User-Agent": "Gideon/1.0 (Research Agent)" },
      });
      if (resp.ok) {
        const data = await resp.json() as {
          AbstractText?: string;
          AbstractURL?: string;
          AbstractSource?: string;
          RelatedTopics?: { Text?: string; FirstURL?: string }[];
        };

        if (data.AbstractText && data.AbstractURL) {
          sources.push({
            url: data.AbstractURL,
            title: data.AbstractSource || "DuckDuckGo Abstract",
            rawContent: data.AbstractText,
          });
        }

        // Grab related topics as lightweight sources
        for (const topic of (data.RelatedTopics || []).slice(0, 2)) {
          if (sources.length >= maxSources) break;
          if (topic.Text && topic.FirstURL) {
            sources.push({
              url: topic.FirstURL,
              title: topic.Text.slice(0, 80),
              rawContent: topic.Text,
            });
          }
        }
      }
    } catch (err) {
      console.error("[Atlas] Fallback fetch failed:", err);
    }
  }

  return sources;
}

// ── Step 3: Extract insights from each source ─────────────────────────────
async function extractInsights(
  source: ResearchSource,
  query: string,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<ResearchInsight[]> {
  if (!source.rawContent || source.rawContent.length < 50) return [];

  const contentPreview = source.rawContent.slice(0, 3000);

  const prompt = `You are Atlas, Gideon's research agent. Extract high-value insights from this source.

Research query: "${query}"
Source URL: ${source.url}
Source title: ${source.title}

Content:
${contentPreview}

Extract 1–3 key insights. Return ONLY valid JSON array:
[
  {
    "title": "short title",
    "content": "detailed insight text (2–4 sentences)",
    "relevance": 8,
    "category": "fact|insight|code|summary|process",
    "tags": ["tag1", "tag2"]
  }
]

Only include insights with relevance >= 6. If nothing relevant, return [].`;

  try {
    const result = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 800 });
    const match = result.text.match(/\[[\s\S]*?\]/);
    if (match) {
      const parsed = JSON.parse(match[0]) as Omit<ResearchInsight, "sourceUrl" | "sourceTitle">[];
      if (Array.isArray(parsed)) {
        return parsed
          .filter(i => i.relevance >= 6)
          .map(i => ({
            ...i,
            sourceUrl: source.url,
            sourceTitle: source.title,
            tags: Array.isArray(i.tags) ? i.tags : [],
          }));
      }
    }
  } catch (err) {
    console.error("[Atlas] Extraction failed:", err);
  }
  return [];
}

// ── Step 4: Rank and deduplicate insights ─────────────────────────────────
function rankInsights(insights: ResearchInsight[]): ResearchInsight[] {
  // Sort by relevance desc, deduplicate by title similarity
  const sorted = [...insights].sort((a, b) => b.relevance - a.relevance);
  const seen = new Set<string>();
  return sorted.filter(i => {
    const key = i.title.toLowerCase().slice(0, 30);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

// ── Step 5: Generate summary ──────────────────────────────────────────────
async function generateSummary(
  query: string,
  insights: ResearchInsight[],
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<string> {
  if (insights.length === 0) return "No significant findings retrieved for this query.";

  const insightText = insights.slice(0, 6).map((i, idx) =>
    `${idx + 1}. [${i.category}] ${i.title}: ${i.content}`
  ).join("\n");

  const prompt = `You are Atlas. Synthesize these research findings into a clear summary.

Query: "${query}"

Findings:
${insightText}

Write a 3–5 sentence synthesis that:
1. Directly answers the query
2. Highlights the most important findings
3. Notes any gaps or caveats
4. Suggests a next action for the user

Be direct and technical. No fluff.`;

  try {
    const result = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 500 });
    return result.text.trim();
  } catch {
    return insights.map(i => `• ${i.title}: ${i.content.slice(0, 100)}`).join("\n");
  }
}

// ── Step 6: Store everything ──────────────────────────────────────────────
async function storeFindings(
  query: string,
  insights: ResearchInsight[],
  summary: string,
  sources: ResearchSource[],
  projectId: number | undefined,
  agentId: number | undefined,
  ollamaUrl?: string
): Promise<{ memoryIds: number[]; qdrantIds: string[] }> {
  const memoryIds: number[] = [];
  const qdrantIds: string[] = [];

  // Store summary in SQLite semantic memory
  const summaryMem = storage.createMemory({
    category: "semantic",
    type: "fact",
    title: `Research: ${query.slice(0, 60)}`,
    content: summary,
    tags: JSON.stringify(["research", "atlas", "summary"]),
    importance: 7,
    projectId,
  });
  memoryIds.push(summaryMem.id);

  // Store each insight in both SQLite + Qdrant
  for (const insight of insights) {
    // SQLite
    const mem = storage.createMemory({
      category: "semantic",
      type: "fact",
      title: insight.title,
      content: `${insight.content}\n\nSource: ${insight.sourceUrl}`,
      tags: JSON.stringify([...insight.tags, "atlas", insight.category]),
      importance: Math.round(insight.relevance),
      projectId,
    });
    memoryIds.push(mem.id);

    // Qdrant
    const qId = uuidv4();
    const stored = await storeResearchFinding({
      id: qId,
      title: insight.title,
      content: insight.content,
      source_url: insight.sourceUrl,
      source_title: insight.sourceTitle,
      category: insight.category,
      tags: insight.tags,
      project_id: projectId,
      memory_id: mem.id,
      importance: insight.relevance,
      created_at: new Date().toISOString(),
    }, ollamaUrl);

    if (stored) qdrantIds.push(qId);
  }

  return { memoryIds, qdrantIds };
}

// ── Step 7: Log to Project Brain ──────────────────────────────────────────
async function logToProjectBrain(
  query: string,
  sources: ResearchSource[],
  insights: ResearchInsight[],
  summary: string,
  projectId: number
): Promise<number | undefined> {
  const project = storage.getProject(projectId);
  if (!project) return undefined;

  const existing = (() => { try { return JSON.parse(project.decisions); } catch { return []; } })();
  const newEntry = {
    decision: `Research completed: "${query.slice(0, 60)}"`,
    reason: summary.slice(0, 200),
    alternatives: `Sources consulted: ${sources.map(s => s.url).join(", ").slice(0, 300)}`,
    date: new Date().toISOString().split("T")[0],
    type: "research_log",
    insights_count: insights.length,
    sources_count: sources.length,
  };

  storage.updateProject(projectId, {
    decisions: JSON.stringify([...existing, newEntry]),
  });

  // Also store as episodic memory
  const mem = storage.createMemory({
    category: "episodic",
    type: "event",
    title: `Atlas research: ${query.slice(0, 50)}`,
    content: `Query: ${query}\n\nSources: ${sources.length}\nInsights: ${insights.length}\n\nSummary: ${summary.slice(0, 300)}`,
    tags: JSON.stringify(["research_log", "atlas", "project_brain"]),
    importance: 6,
    projectId,
  });

  return mem.id;
}

// ── Master research function ──────────────────────────────────────────────
export async function runAtlasResearch(
  intent: ResearchIntent,
  options: { ollamaUrl?: string; ollamaModel?: string } = {}
): Promise<ResearchResult> {
  const startTime = Date.now();
  const maxSources = intent.maxSources || 5;

  // Find Atlas agent
  const agents = storage.getAgents();
  const atlas = agents.find(a => a.name === "Atlas" || a.type === "research");
  if (atlas) storage.updateAgent(atlas.id, { status: "active", lastActiveAt: new Date() });

  console.log(`[Atlas] Starting research: "${intent.query}"`);

  // 1. Decompose
  console.log("[Atlas] Step 1: Decomposing query...");
  const subQueries = await decomposeQuery(intent.query, options.ollamaUrl, options.ollamaModel);
  console.log(`[Atlas] Sub-queries: ${subQueries.join(", ")}`);

  // 2. Scrape
  console.log("[Atlas] Step 2: Scraping sources...");
  const rawSources = await scrapeSources(subQueries, maxSources, intent.firecrawlKey);
  console.log(`[Atlas] Scraped ${rawSources.length} sources`);

  // 3. Extract insights
  console.log("[Atlas] Step 3: Extracting insights...");
  const allInsights: ResearchInsight[] = [];
  for (const source of rawSources) {
    const insights = await extractInsights(source, intent.query, options.ollamaUrl, options.ollamaModel);
    allInsights.push(...insights);
  }

  // 4. Rank
  const rankedInsights = rankInsights(allInsights);
  console.log(`[Atlas] Ranked ${rankedInsights.length} insights`);

  // 5. Summarize
  console.log("[Atlas] Step 4: Generating synthesis...");
  const summary = await generateSummary(intent.query, rankedInsights, options.ollamaUrl, options.ollamaModel);

  // 6. Store
  console.log("[Atlas] Step 5: Storing to SQLite + Qdrant...");
  const { memoryIds, qdrantIds } = await storeFindings(
    intent.query, rankedInsights, summary, rawSources,
    intent.projectId, atlas?.id, options.ollamaUrl
  );

  // 7. Log to Project Brain
  let projectLogId: number | undefined;
  if (intent.projectId) {
    console.log("[Atlas] Step 6: Logging to Project Brain...");
    projectLogId = await logToProjectBrain(
      intent.query, rawSources, rankedInsights, summary, intent.projectId
    );
  }

  // Update agent task count
  if (atlas) {
    storage.updateAgent(atlas.id, {
      status: "idle",
      taskCount: atlas.taskCount + 1,
      lastActiveAt: new Date(),
    });
  }

  const duration = Date.now() - startTime;
  console.log(`[Atlas] Research complete in ${duration}ms`);

  return {
    query: intent.query,
    subQueries,
    sources: rawSources.map(s => ({ url: s.url, title: s.title, indexed: true })),
    insights: rankedInsights,
    summary,
    memoryIds,
    qdrantIds,
    projectLogId,
    durationMs: duration,
    model: options.ollamaModel || "claude_sonnet_4_6",
    agentId: atlas?.id,
  };
}
