import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { eq, desc, like, and, or } from "drizzle-orm";
import {
  users, memories, projects, tasks, agents, agentRuns, skills, files, conversations, scheduledJobs,
  type User, type InsertUser,
  type Memory, type InsertMemory,
  type Project, type InsertProject,
  type Task, type InsertTask,
  type Agent, type InsertAgent,
  type AgentRun, type InsertAgentRun,
  type Skill, type InsertSkill,
  type File, type InsertFile,
  type Conversation, type InsertConversation,
  type ScheduledJob, type InsertScheduledJob,
} from "@shared/schema";

const sqlite = new Database("data.db");
const db = drizzle(sqlite);

// Run migrations
sqlite.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL DEFAULT 'Gideon',
    avatar TEXT,
    preferred_model TEXT NOT NULL DEFAULT 'ollama/llama3',
    ollama_url TEXT NOT NULL DEFAULT 'http://localhost:11434',
    openai_key TEXT,
    anthropic_key TEXT,
    created_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS memories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    tags TEXT NOT NULL DEFAULT '[]',
    project_id INTEGER,
    importance INTEGER NOT NULL DEFAULT 5,
    access_count INTEGER NOT NULL DEFAULT 0,
    expires_at INTEGER,
    created_at INTEGER,
    updated_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    path TEXT,
    stack TEXT NOT NULL DEFAULT '[]',
    architecture TEXT,
    decisions TEXT NOT NULL DEFAULT '[]',
    created_at INTEGER,
    updated_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    priority TEXT NOT NULL DEFAULT 'medium',
    project_id INTEGER,
    agent_id INTEGER,
    steps TEXT NOT NULL DEFAULT '[]',
    result TEXT,
    risk_score INTEGER NOT NULL DEFAULT 0,
    scheduled_at INTEGER,
    started_at INTEGER,
    completed_at INTEGER,
    created_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS agents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'idle',
    model TEXT NOT NULL DEFAULT 'ollama/llama3',
    capabilities TEXT NOT NULL DEFAULT '[]',
    config TEXT NOT NULL DEFAULT '{}',
    task_count INTEGER NOT NULL DEFAULT 0,
    last_active_at INTEGER,
    created_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS agent_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id INTEGER NOT NULL,
    task_id INTEGER,
    input TEXT NOT NULL,
    output TEXT,
    status TEXT NOT NULL DEFAULT 'running',
    tokens_used INTEGER NOT NULL DEFAULT 0,
    duration_ms INTEGER,
    error TEXT,
    created_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS skills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    category TEXT NOT NULL DEFAULT 'general',
    enabled INTEGER NOT NULL DEFAULT 1,
    config TEXT NOT NULL DEFAULT '{}',
    agents TEXT NOT NULL DEFAULT '[]',
    tools TEXT NOT NULL DEFAULT '[]',
    workflows TEXT NOT NULL DEFAULT '[]',
    version TEXT NOT NULL DEFAULT '1.0.0',
    created_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    path TEXT NOT NULL,
    type TEXT NOT NULL,
    mime_type TEXT,
    size INTEGER,
    summary TEXT,
    tags TEXT NOT NULL DEFAULT '[]',
    project_id INTEGER,
    indexed INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER,
    indexed_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    messages TEXT NOT NULL DEFAULT '[]',
    project_id INTEGER,
    created_at INTEGER,
    updated_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS scheduled_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    cron TEXT,
    run_at INTEGER,
    enabled INTEGER NOT NULL DEFAULT 1,
    agent_type TEXT NOT NULL,
    prompt TEXT NOT NULL,
    last_run_at INTEGER,
    next_run_at INTEGER,
    run_count INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER
  );
`);

export interface IStorage {
  // Users
  getUser(id: number): User | undefined;
  getUsers(): User[];
  createUser(u: InsertUser): User;
  updateUser(id: number, u: Partial<InsertUser>): User | undefined;

  // Memories
  getMemories(filter?: { category?: string; projectId?: number; search?: string }): Memory[];
  getMemory(id: number): Memory | undefined;
  createMemory(m: InsertMemory): Memory;
  updateMemory(id: number, m: Partial<InsertMemory>): Memory | undefined;
  deleteMemory(id: number): void;
  incrementMemoryAccess(id: number): void;

  // Projects
  getProjects(): Project[];
  getProject(id: number): Project | undefined;
  createProject(p: InsertProject): Project;
  updateProject(id: number, p: Partial<InsertProject>): Project | undefined;
  deleteProject(id: number): void;

  // Tasks
  getTasks(filter?: { projectId?: number; status?: string; agentId?: number }): Task[];
  getTask(id: number): Task | undefined;
  createTask(t: InsertTask): Task;
  updateTask(id: number, t: Partial<InsertTask>): Task | undefined;
  deleteTask(id: number): void;

  // Agents
  getAgents(): Agent[];
  getAgent(id: number): Agent | undefined;
  createAgent(a: InsertAgent): Agent;
  updateAgent(id: number, a: Partial<InsertAgent>): Agent | undefined;
  deleteAgent(id: number): void;

  // Agent Runs
  getAgentRuns(agentId?: number, taskId?: number): AgentRun[];
  getAgentRun(id: number): AgentRun | undefined;
  createAgentRun(r: InsertAgentRun): AgentRun;
  updateAgentRun(id: number, r: Partial<InsertAgentRun>): AgentRun | undefined;

  // Skills
  getSkills(): Skill[];
  getSkill(id: number): Skill | undefined;
  createSkill(s: InsertSkill): Skill;
  updateSkill(id: number, s: Partial<InsertSkill>): Skill | undefined;
  deleteSkill(id: number): void;

  // Files
  getFiles(filter?: { projectId?: number; type?: string; indexed?: boolean }): File[];
  getFile(id: number): File | undefined;
  createFile(f: InsertFile): File;
  updateFile(id: number, f: Partial<InsertFile>): File | undefined;
  deleteFile(id: number): void;

  // Conversations
  getConversations(projectId?: number): Conversation[];
  getConversation(id: number): Conversation | undefined;
  createConversation(c: InsertConversation): Conversation;
  updateConversation(id: number, c: Partial<InsertConversation>): Conversation | undefined;
  deleteConversation(id: number): void;

  // Scheduled Jobs
  getScheduledJobs(): ScheduledJob[];
  getScheduledJob(id: number): ScheduledJob | undefined;
  createScheduledJob(j: InsertScheduledJob): ScheduledJob;
  updateScheduledJob(id: number, j: Partial<InsertScheduledJob>): ScheduledJob | undefined;
  deleteScheduledJob(id: number): void;
}

export class SQLiteStorage implements IStorage {
  // ── Users ──────────────────────────────────────────
  getUser(id: number) { return db.select().from(users).where(eq(users.id, id)).get(); }
  getUsers() { return db.select().from(users).all(); }
  createUser(u: InsertUser) { return db.insert(users).values(u).returning().get(); }
  updateUser(id: number, u: Partial<InsertUser>) {
    return db.update(users).set(u).where(eq(users.id, id)).returning().get();
  }

  // ── Memories ───────────────────────────────────────
  getMemories(filter?: { category?: string; projectId?: number; search?: string }) {
    let q = db.select().from(memories);
    const conds = [];
    if (filter?.category) conds.push(eq(memories.category, filter.category));
    if (filter?.projectId) conds.push(eq(memories.projectId, filter.projectId));
    if (filter?.search) conds.push(or(like(memories.title, `%${filter.search}%`), like(memories.content, `%${filter.search}%`)));
    if (conds.length) return q.where(and(...conds)).orderBy(desc(memories.updatedAt)).all();
    return q.orderBy(desc(memories.updatedAt)).all();
  }
  getMemory(id: number) { return db.select().from(memories).where(eq(memories.id, id)).get(); }
  createMemory(m: InsertMemory) {
    const now = new Date();
    return db.insert(memories).values({ ...m, createdAt: now, updatedAt: now }).returning().get();
  }
  updateMemory(id: number, m: Partial<InsertMemory>) {
    return db.update(memories).set({ ...m, updatedAt: new Date() }).where(eq(memories.id, id)).returning().get();
  }
  deleteMemory(id: number) { db.delete(memories).where(eq(memories.id, id)).run(); }
  incrementMemoryAccess(id: number) {
    const mem = this.getMemory(id);
    if (mem) db.update(memories).set({ accessCount: mem.accessCount + 1 }).where(eq(memories.id, id)).run();
  }

  // ── Projects ───────────────────────────────────────
  getProjects() { return db.select().from(projects).orderBy(desc(projects.updatedAt)).all(); }
  getProject(id: number) { return db.select().from(projects).where(eq(projects.id, id)).get(); }
  createProject(p: InsertProject) {
    const now = new Date();
    return db.insert(projects).values({ ...p, createdAt: now, updatedAt: now }).returning().get();
  }
  updateProject(id: number, p: Partial<InsertProject>) {
    return db.update(projects).set({ ...p, updatedAt: new Date() }).where(eq(projects.id, id)).returning().get();
  }
  deleteProject(id: number) { db.delete(projects).where(eq(projects.id, id)).run(); }

  // ── Tasks ──────────────────────────────────────────
  getTasks(filter?: { projectId?: number; status?: string; agentId?: number }) {
    const conds = [];
    if (filter?.projectId) conds.push(eq(tasks.projectId, filter.projectId));
    if (filter?.status) conds.push(eq(tasks.status, filter.status));
    if (filter?.agentId) conds.push(eq(tasks.agentId, filter.agentId));
    if (conds.length) return db.select().from(tasks).where(and(...conds)).orderBy(desc(tasks.createdAt)).all();
    return db.select().from(tasks).orderBy(desc(tasks.createdAt)).all();
  }
  getTask(id: number) { return db.select().from(tasks).where(eq(tasks.id, id)).get(); }
  createTask(t: InsertTask) {
    return db.insert(tasks).values({ ...t, createdAt: new Date() }).returning().get();
  }
  updateTask(id: number, t: Partial<InsertTask>) {
    return db.update(tasks).set(t).where(eq(tasks.id, id)).returning().get();
  }
  deleteTask(id: number) { db.delete(tasks).where(eq(tasks.id, id)).run(); }

  // ── Agents ─────────────────────────────────────────
  getAgents() { return db.select().from(agents).orderBy(desc(agents.createdAt)).all(); }
  getAgent(id: number) { return db.select().from(agents).where(eq(agents.id, id)).get(); }
  createAgent(a: InsertAgent) {
    return db.insert(agents).values({ ...a, createdAt: new Date() }).returning().get();
  }
  updateAgent(id: number, a: Partial<InsertAgent>) {
    return db.update(agents).set(a).where(eq(agents.id, id)).returning().get();
  }
  deleteAgent(id: number) { db.delete(agents).where(eq(agents.id, id)).run(); }

  // ── Agent Runs ─────────────────────────────────────
  getAgentRuns(agentId?: number, taskId?: number) {
    const conds = [];
    if (agentId) conds.push(eq(agentRuns.agentId, agentId));
    if (taskId) conds.push(eq(agentRuns.taskId, taskId));
    if (conds.length) return db.select().from(agentRuns).where(and(...conds)).orderBy(desc(agentRuns.createdAt)).all();
    return db.select().from(agentRuns).orderBy(desc(agentRuns.createdAt)).all();
  }
  getAgentRun(id: number) { return db.select().from(agentRuns).where(eq(agentRuns.id, id)).get(); }
  createAgentRun(r: InsertAgentRun) {
    return db.insert(agentRuns).values({ ...r, createdAt: new Date() }).returning().get();
  }
  updateAgentRun(id: number, r: Partial<InsertAgentRun>) {
    return db.update(agentRuns).set(r).where(eq(agentRuns.id, id)).returning().get();
  }

  // ── Skills ─────────────────────────────────────────
  getSkills() { return db.select().from(skills).orderBy(desc(skills.createdAt)).all(); }
  getSkill(id: number) { return db.select().from(skills).where(eq(skills.id, id)).get(); }
  createSkill(s: InsertSkill) {
    return db.insert(skills).values({ ...s, createdAt: new Date() }).returning().get();
  }
  updateSkill(id: number, s: Partial<InsertSkill>) {
    return db.update(skills).set(s).where(eq(skills.id, id)).returning().get();
  }
  deleteSkill(id: number) { db.delete(skills).where(eq(skills.id, id)).run(); }

  // ── Files ──────────────────────────────────────────
  getFiles(filter?: { projectId?: number; type?: string; indexed?: boolean }) {
    const conds = [];
    if (filter?.projectId) conds.push(eq(files.projectId, filter.projectId));
    if (filter?.type) conds.push(eq(files.type, filter.type));
    if (filter?.indexed !== undefined) conds.push(eq(files.indexed, filter.indexed));
    if (conds.length) return db.select().from(files).where(and(...conds)).orderBy(desc(files.createdAt)).all();
    return db.select().from(files).orderBy(desc(files.createdAt)).all();
  }
  getFile(id: number) { return db.select().from(files).where(eq(files.id, id)).get(); }
  createFile(f: InsertFile) {
    return db.insert(files).values({ ...f, createdAt: new Date() }).returning().get();
  }
  updateFile(id: number, f: Partial<InsertFile>) {
    return db.update(files).set(f).where(eq(files.id, id)).returning().get();
  }
  deleteFile(id: number) { db.delete(files).where(eq(files.id, id)).run(); }

  // ── Conversations ──────────────────────────────────
  getConversations(projectId?: number) {
    if (projectId) return db.select().from(conversations).where(eq(conversations.projectId, projectId)).orderBy(desc(conversations.updatedAt)).all();
    return db.select().from(conversations).orderBy(desc(conversations.updatedAt)).all();
  }
  getConversation(id: number) { return db.select().from(conversations).where(eq(conversations.id, id)).get(); }
  createConversation(c: InsertConversation) {
    const now = new Date();
    return db.insert(conversations).values({ ...c, createdAt: now, updatedAt: now }).returning().get();
  }
  updateConversation(id: number, c: Partial<InsertConversation>) {
    return db.update(conversations).set({ ...c, updatedAt: new Date() }).where(eq(conversations.id, id)).returning().get();
  }
  deleteConversation(id: number) { db.delete(conversations).where(eq(conversations.id, id)).run(); }

  // ── Scheduled Jobs ─────────────────────────────────
  getScheduledJobs() { return db.select().from(scheduledJobs).orderBy(desc(scheduledJobs.createdAt)).all(); }
  getScheduledJob(id: number) { return db.select().from(scheduledJobs).where(eq(scheduledJobs.id, id)).get(); }
  createScheduledJob(j: InsertScheduledJob) {
    return db.insert(scheduledJobs).values({ ...j, createdAt: new Date() }).returning().get();
  }
  updateScheduledJob(id: number, j: Partial<InsertScheduledJob>) {
    return db.update(scheduledJobs).set(j).where(eq(scheduledJobs.id, id)).returning().get();
  }
  deleteScheduledJob(id: number) { db.delete(scheduledJobs).where(eq(scheduledJobs.id, id)).run(); }
}

export const storage = new SQLiteStorage();

// Seed default data on first run
function seedIfEmpty() {
  const existing = storage.getUsers();
  if (existing.length === 0) {
    storage.createUser({ name: "Operator", preferredModel: "glm/glm-5.2", ollamaUrl: "http://localhost:11434" });
  }
  const agentList = storage.getAgents();
  if (agentList.length === 0) {
    const defaultAgents = [
      { name: "Hermes", type: "orchestrator", model: "glm/glm-5.2", capabilities: JSON.stringify(["planning", "routing", "coordination"]), config: "{}" },
      { name: "Atlas", type: "research", model: "glm/glm-5.2", capabilities: JSON.stringify(["web_search", "document_analysis", "summarization"]), config: "{}" },
      { name: "Vulcan", type: "coding", model: "glm/glm-5.2", capabilities: JSON.stringify(["code_generation", "refactoring", "test_generation", "documentation"]), config: "{}" },
      { name: "Mercury", type: "automation", model: "ollama/llama3.2:3b", capabilities: JSON.stringify(["browser_control", "workflow_execution", "form_filling"]), config: "{}" },
      { name: "Minerva", type: "vision", model: "ollama/llava:7b", capabilities: JSON.stringify(["ocr", "screen_understanding", "image_analysis"]), config: "{}" },
    ];
    defaultAgents.forEach(a => storage.createAgent(a));
  }
  const skillList = storage.getSkills();
  if (skillList.length === 0) {
    const defaultSkills = [
      { name: "Web Research", category: "research", description: "Search the web, analyze pages, summarize findings", agents: '["research"]', tools: '["search","fetch","summarize"]', workflows: '["research_workflow"]', enabled: true },
      { name: "Code Generation", category: "coding", description: "Generate, refactor, test, and document code", agents: '["coding"]', tools: '["write_code","run_tests","lint"]', workflows: '["code_workflow"]', enabled: true },
      { name: "File Intelligence", category: "files", description: "Parse, embed, summarize, and search files", agents: '["vision","research"]', tools: '["parse_file","embed","search_semantic"]', workflows: '["file_pipeline"]', enabled: true },
      { name: "Browser Automation", category: "automation", description: "Control browsers, fill forms, navigate sites", agents: '["automation"]', tools: '["playwright","browser_use"]', workflows: '["automation_workflow"]', enabled: true },
      { name: "Data Analysis", category: "data", description: "Analyze datasets, generate charts, statistical insights", agents: '["research","coding"]', tools: '["pandas","charts","stats"]', workflows: '["analysis_workflow"]', enabled: true },
      { name: "Crypto Monitoring", category: "finance", description: "Monitor prices, track divergences, alert on conditions", agents: '["research","automation"]', tools: '["price_feed","alert","notify"]', workflows: '["crypto_monitor"]', enabled: false },
      { name: "DevOps", category: "coding", description: "Deploy, monitor, manage infrastructure and CI/CD", agents: '["coding","automation"]', tools: '["docker","kubectl","github_actions"]', workflows: '["deploy_workflow"]', enabled: false },
    ];
    defaultSkills.forEach(s => storage.createSkill(s));
  }
  const memList = storage.getMemories();
  if (memList.length === 0) {
    const seedMemories = [
      { category: "semantic", type: "fact", title: "Preferred local model stack", content: "Primary model: GLM-5.2 via Z.ai API (glm/glm-5.2) for coding, research, and orchestration. Ollama fallback: any available local model. Vision: llava:7b (Ollama). Set GLM_API_KEY env var to activate GLM-5.2.", importance: 9, tags: JSON.stringify(["models","ollama","preferences"]) },
      { category: "procedural", type: "process", title: "Deployment workflow", content: "1. Build with npm run build. 2. Run docker compose up. 3. Test endpoints. 4. Push to VPS via rsync. 5. Verify with health check.", importance: 8, tags: JSON.stringify(["deployment","docker","devops"]) },
      { category: "episodic", type: "event", title: "Gideon system initialized", content: "Gideon Core initialized. Memory system online. 5 default agents registered. 7 skills loaded. Ready for task execution.", importance: 10, tags: JSON.stringify(["system","init","startup"]) },
      { category: "semantic", type: "fact", title: "Security risk policy", content: "Risk 0-4: Auto-execute. Risk 5-7: Request confirmation. Risk 8-10: Explicit user approval required. Delete operations always score 8+.", importance: 9, tags: JSON.stringify(["security","policy","risk"]) },
    ];
    seedMemories.forEach(m => storage.createMemory(m));
  }
}
seedIfEmpty();
