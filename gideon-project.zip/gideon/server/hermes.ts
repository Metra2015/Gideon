/**
 * Hermes Runtime — Task Execution Loop + Scheduler
 *
 * Responsibilities:
 *   1. Poll `tasks` table every 3s for pending tasks → dispatch to correct agent
 *   2. Poll `scheduled_jobs` every 60s → fire overdue jobs
 *   3. Route tasks by type: research→Atlas, coding→Vulcan, automation→Mercury, vision→Minerva
 *   4. Write AgentRun records for every execution
 *   5. Update task status (in_progress → completed|failed)
 */

import { storage } from "./storage";
import { completeLLM, buildSystemPrompt } from "./llm";
import { runAtlasResearch } from "./atlas";
import { runVulcan } from "./vulcan";
import { runMercury } from "./mercury";
import { runMinerva } from "./minerva";
import { semanticSearch } from "./qdrant";

type AgentType = "research" | "coding" | "automation" | "vision" | "orchestrator";

// ── Intent → agent type mapping ───────────────────────────────────────────
function classifyTask(title: string, description?: string | null): AgentType {
  const text = `${title} ${description || ""}`.toLowerCase();

  if (/\b(research|find|search|analyze|summarize|look up|discover|investigate)\b/.test(text)) return "research";
  if (/\b(code|write|generate|implement|build|create|fix|debug|refactor|script|function|class|api)\b/.test(text)) return "coding";
  if (/\b(automate|fetch|scrape|extract|navigate|click|fill|form|visit|browse|download|monitor)\b/.test(text)) return "automation";
  if (/\b(image|screenshot|ocr|vision|photo|analyze image|read image|detect|recognize)\b/.test(text)) return "vision";

  return "orchestrator"; // fallback: Hermes handles it directly with LLM
}

// ── Build memory context for injection into agent runs ────────────────────
export async function buildMemoryContext(
  query: string,
  projectId?: number | null,
  ollamaUrl?: string
): Promise<string> {
  // 1. SQLite keyword search
  const keywordMems = storage.getMemories({ search: query.slice(0, 50) }).slice(0, 3);

  // 2. Qdrant semantic search
  let semanticMems: { title: string; content: string }[] = [];
  try {
    const results = await semanticSearch(query, { limit: 3, projectId: projectId ?? undefined, ollamaUrl });
    semanticMems = results.map(r => ({ title: r.title, content: r.content }));
  } catch {
    // Qdrant may be offline — skip
  }

  // 3. Project-specific memories
  const projectMems = projectId
    ? storage.getMemories({ projectId }).slice(0, 3)
    : [];

  const all = [...keywordMems, ...projectMems];
  // Increment access counts
  all.forEach(m => storage.incrementMemoryAccess(m.id));

  const combined = [
    ...all.map(m => `[${m.category}] ${m.title}: ${m.content}`),
    ...semanticMems.map(m => `[semantic] ${m.title}: ${m.content}`),
  ].slice(0, 6);

  if (combined.length === 0) return "";
  return `## Relevant Memory\n${combined.join("\n")}`;
}

// ── Execute a single task ─────────────────────────────────────────────────
async function executeTask(taskId: number): Promise<void> {
  const task = storage.getTask(taskId);
  if (!task) return;

  // Mark in-progress
  storage.updateTask(taskId, {
    status: "in_progress",
    startedAt: new Date(),
  });

  const users = storage.getUsers();
  const user = users[0];
  const ollamaUrl = user?.ollamaUrl || "http://localhost:11434";
  const ollamaModel = (user?.preferredModel || "ollama/llama3.2:3b").replace(/^ollama\//, "");

  // Find matching agent
  const agentType = classifyTask(task.title, task.description);
  const agents = storage.getAgents();
  const agent = agents.find(a => a.type === agentType) || agents.find(a => a.type === "orchestrator") || agents[0];

  // Create agent run record
  const run = storage.createAgentRun({
    agentId: agent?.id ?? 0,
    taskId,
    input: JSON.stringify({ title: task.title, description: task.description, steps: task.steps }),
    status: "running",
  });

  // Set agent active
  if (agent) storage.updateAgent(agent.id, { status: "active", lastActiveAt: new Date() });

  const startTime = Date.now();
  let result = "";
  let error: string | undefined;

  try {
    // Inject relevant memory context
    const memCtx = await buildMemoryContext(task.title, task.projectId, ollamaUrl);

    if (agentType === "research") {
      // ── Atlas research ──
      const res = await runAtlasResearch(
        { query: task.title + (task.description ? `. ${task.description}` : ""), projectId: task.projectId ?? undefined, maxSources: 5 },
        { ollamaUrl, ollamaModel }
      );
      result = JSON.stringify({
        summary: res.summary,
        insights: res.insights.length,
        sources: res.sources.length,
        vectors: res.qdrantIds.length,
        memoryIds: res.memoryIds,
      });

    } else if (agentType === "coding") {
      // ── Vulcan coding ──
      const res = await runVulcan(
        { task: task.title, description: task.description || "", projectId: task.projectId ?? undefined, memoryContext: memCtx },
        { ollamaUrl, ollamaModel }
      );
      result = JSON.stringify({ files: res.files, explanation: res.explanation, language: res.language });

    } else if (agentType === "automation") {
      // ── Mercury automation ──
      const res = await runMercury(
        { task: task.title, description: task.description || "", memoryContext: memCtx },
        { ollamaUrl, ollamaModel }
      );
      result = JSON.stringify({ output: res.output, steps: res.steps, data: res.data });

    } else if (agentType === "vision") {
      // ── Minerva vision ──
      const filePath = (() => {
        try { return (JSON.parse(task.steps || "[]") as string[])[0] || ""; } catch { return ""; }
      })();
      const res = await runMinerva(
        { task: task.title, filePath, memoryContext: memCtx },
        { ollamaUrl, ollamaModel }
      );
      result = JSON.stringify({ analysis: res.analysis, entities: res.entities, summary: res.summary });

    } else {
      // ── Orchestrator fallback: direct LLM ──
      const systemPrompt = buildSystemPrompt(memCtx);
      const prompt = `Execute this task and provide a detailed result:\n\nTask: ${task.title}\n${task.description ? `Description: ${task.description}` : ""}\n\nProvide:\n1. Step-by-step execution plan\n2. Actual result/output\n3. What was accomplished`;
      const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, systemPrompt });
      result = res.text;

      // Store result as memory
      storage.createMemory({
        category: "episodic",
        type: "event",
        title: `Task completed: ${task.title.slice(0, 60)}`,
        content: result.slice(0, 500),
        tags: JSON.stringify(["task", "hermes", "completed"]),
        importance: 5,
        projectId: task.projectId ?? undefined,
      });
    }

    // Mark task completed
    storage.updateTask(taskId, {
      status: "completed",
      result,
      completedAt: new Date(),
    });

    // Update agent run
    storage.updateAgentRun(run.id, {
      output: result,
      status: "completed",
      durationMs: Date.now() - startTime,
    });

    // Update agent stats
    if (agent) {
      storage.updateAgent(agent.id, {
        status: "idle",
        taskCount: agent.taskCount + 1,
        lastActiveAt: new Date(),
      });
    }

    console.log(`[Hermes] Task ${taskId} completed in ${Date.now() - startTime}ms via ${agentType}`);

  } catch (err) {
    error = String(err);
    console.error(`[Hermes] Task ${taskId} failed:`, err);

    storage.updateTask(taskId, { status: "failed", result: error });
    storage.updateAgentRun(run.id, {
      output: error,
      status: "failed",
      error,
      durationMs: Date.now() - startTime,
    });

    if (agent) storage.updateAgent(agent.id, { status: "idle", lastActiveAt: new Date() });
  }
}

// ── Cron expression parser (simple — supports */N, N, * for minute/hour) ──
function parseCronNext(cronExpr: string): Date | null {
  try {
    const parts = cronExpr.trim().split(/\s+/);
    if (parts.length < 5) return null;

    const [minute, hour] = parts;
    const now = new Date();
    const next = new Date(now);
    next.setSeconds(0, 0);

    // Parse minute
    let nextMinute = now.getMinutes();
    if (minute === "*") {
      nextMinute = now.getMinutes() + 1;
    } else if (minute.startsWith("*/")) {
      const interval = parseInt(minute.slice(2));
      nextMinute = Math.ceil((now.getMinutes() + 1) / interval) * interval;
    } else {
      nextMinute = parseInt(minute);
    }

    // Parse hour
    let nextHour = now.getHours();
    if (hour !== "*" && !hour.startsWith("*/")) {
      nextHour = parseInt(hour);
    }

    if (nextMinute >= 60) {
      nextMinute = 0;
      nextHour += 1;
    }
    if (nextHour >= 24) {
      next.setDate(next.getDate() + 1);
      nextHour = nextHour % 24;
    }

    next.setHours(nextHour, nextMinute, 0, 0);
    if (next <= now) next.setMinutes(next.getMinutes() + 1);

    return next;
  } catch {
    return null;
  }
}

// ── Fire a scheduled job ──────────────────────────────────────────────────
async function fireScheduledJob(jobId: number): Promise<void> {
  const job = storage.getScheduledJob(jobId);
  if (!job || !job.enabled) return;

  console.log(`[Hermes] Firing scheduled job ${jobId}: "${job.name}"`);

  // Create a task for the job
  const task = storage.createTask({
    title: job.name,
    description: job.description || job.prompt,
    status: "pending",
    priority: "medium",
    steps: JSON.stringify([job.prompt]),
  });

  // Update job metadata
  const nextRun = job.cron ? parseCronNext(job.cron) : null;
  storage.updateScheduledJob(jobId, {
    lastRunAt: new Date(),
    nextRunAt: nextRun || undefined,
    runCount: job.runCount + 1,
  });

  // Execute immediately
  await executeTask(task.id);
}

// ── Main polling loop ─────────────────────────────────────────────────────
let isTaskLoopRunning = false;
let isJobLoopRunning = false;
let activeTasks = new Set<number>();
const MAX_CONCURRENT = 3;

async function taskLoop(): Promise<void> {
  if (isTaskLoopRunning) return;
  isTaskLoopRunning = true;

  try {
    if (activeTasks.size >= MAX_CONCURRENT) return;

    const pending = storage.getTasks({ status: "pending" });
    for (const task of pending) {
      if (activeTasks.size >= MAX_CONCURRENT) break;
      if (activeTasks.has(task.id)) continue;

      // Skip tasks with future scheduledAt
      if (task.scheduledAt && task.scheduledAt > new Date()) continue;

      activeTasks.add(task.id);
      // Fire and forget — don't await so we can process multiple tasks
      executeTask(task.id).finally(() => activeTasks.delete(task.id));
    }
  } catch (err) {
    console.error("[Hermes] Task loop error:", err);
  } finally {
    isTaskLoopRunning = false;
  }
}

async function schedulerLoop(): Promise<void> {
  if (isJobLoopRunning) return;
  isJobLoopRunning = true;

  try {
    const jobs = storage.getScheduledJobs();
    const now = new Date();

    for (const job of jobs) {
      if (!job.enabled) continue;

      // One-time job: fire if runAt has passed and never run
      if (job.runAt && job.runCount === 0 && job.runAt <= now) {
        await fireScheduledJob(job.id);
        continue;
      }

      // Recurring job: fire if nextRunAt has passed (or never computed)
      if (job.cron) {
        const shouldFire = !job.nextRunAt || job.nextRunAt <= now;
        if (shouldFire) {
          await fireScheduledJob(job.id);
        }
      }
    }
  } catch (err) {
    console.error("[Hermes] Scheduler loop error:", err);
  } finally {
    isJobLoopRunning = false;
  }
}

// ── Public start function ─────────────────────────────────────────────────
let hermesStarted = false;

export function startHermes(): void {
  if (hermesStarted) return;
  hermesStarted = true;

  console.log("[Hermes] Runtime started — task loop every 5s, scheduler every 60s");

  // Task polling — every 5 seconds
  setInterval(() => { taskLoop().catch(console.error); }, 5000);

  // Scheduler — every 60 seconds
  setInterval(() => { schedulerLoop().catch(console.error); }, 60_000);

  // Run immediately on start
  setTimeout(() => { taskLoop().catch(console.error); }, 2000);
  setTimeout(() => { schedulerLoop().catch(console.error); }, 3000);
}

// ── Expose for SSE task dispatch ─────────────────────────────────────────
export { executeTask, classifyTask };
