import { streamLLM, checkOllama, completeLLM, buildSystemPrompt, type LLMMessage } from "./llm";
import { runAtlasResearch, type ResearchIntent } from "./atlas";
import { semanticSearch, getCollectionStats, deletePoint, storeResearchFinding } from "./qdrant";
import { runVulcan } from "./vulcan";
import { runMercury } from "./mercury";
import { runMinerva } from "./minerva";
import { startHermes, executeTask, classifyTask, buildMemoryContext } from "./hermes";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertMemorySchema, insertProjectSchema, insertTaskSchema, insertAgentSchema,
  insertAgentRunSchema, insertSkillSchema, insertFileSchema, insertConversationSchema,
  insertScheduledJobSchema, insertUserSchema
} from "@shared/schema";

// ─── Gideon Core: Intent Analysis ──────────────────────────
function analyzeIntent(input: string): {
  goal: string; complexity: "low" | "medium" | "high";
  agents: string[]; riskScore: number; plan: string[];
} {
  const lower = input.toLowerCase();
  let goal = "general";
  let complexity: "low" | "medium" | "high" = "low";
  let agents: string[] = [];
  let riskScore = 0;
  let plan: string[] = [];

  if (/\b(create|build|generate|write|develop|code|implement)\b/.test(lower) && /\b(app|api|service|script|dashboard|website|backend|frontend)\b/.test(lower)) {
    goal = "software_development";
    complexity = "high";
    agents = ["orchestrator", "research", "coding"];
    riskScore = 4;
    plan = ["Analyze requirements", "Research patterns & libraries", "Design architecture", "Generate code", "Write tests", "Document"];
  } else if (/\b(research|find|search|look up|analyze|summarize|explain)\b/.test(lower)) {
    goal = "research";
    complexity = "medium";
    agents = ["research"];
    riskScore = 1;
    plan = ["Formulate search queries", "Collect sources", "Rank & filter", "Extract key info", "Synthesize findings", "Store in memory"];
  } else if (/\b(automate|click|fill|navigate|scrape|extract from|open browser)\b/.test(lower)) {
    goal = "automation";
    complexity = "medium";
    agents = ["automation"];
    riskScore = 5;
    plan = ["Identify target site/app", "Map required actions", "Generate automation script", "Execute & monitor", "Handle errors", "Report results"];
  } else if (/\b(delete|remove|destroy|drop|purge|wipe)\b/.test(lower)) {
    goal = "destructive_operation";
    complexity = "low";
    agents = ["orchestrator"];
    riskScore = 9;
    plan = ["Verify target", "Check dependencies", "Require explicit approval", "Execute deletion", "Log to episodic memory"];
  } else if (/\b(schedule|every day|every week|recurring|cron|monitor|watch|alert)\b/.test(lower)) {
    goal = "scheduling";
    complexity = "medium";
    agents = ["orchestrator", "research"];
    riskScore = 2;
    plan = ["Parse schedule expression", "Define trigger conditions", "Create job definition", "Register in scheduler", "Verify first run"];
  } else if (/\b(analyze|ocr|read file|understand image|screenshot)\b/.test(lower)) {
    goal = "vision";
    complexity = "medium";
    agents = ["vision"];
    riskScore = 1;
    plan = ["Load visual input", "Run OCR/perception model", "Extract structured data", "Store findings", "Return analysis"];
  } else if (/\b(remember|store|save this|note that|add to memory)\b/.test(lower)) {
    goal = "memory_management";
    complexity = "low";
    agents = ["orchestrator"];
    riskScore = 0;
    plan = ["Classify memory type", "Extract key facts", "Store with embeddings", "Update knowledge graph"];
  } else {
    goal = "conversation";
    complexity = "low";
    agents = ["orchestrator"];
    riskScore = 0;
    plan = ["Load context", "Retrieve relevant memories", "Generate response", "Update working memory"];
  }

  return { goal, complexity, agents, riskScore, plan };
}

// ─── Planning Engine ──────────────────────────────────────
function buildExecutionPlan(goal: string, input: string, agents: string[]): { title: string; steps: string[] } {
  const analysis = analyzeIntent(input);
  return {
    title: `Execute: ${input.slice(0, 60)}${input.length > 60 ? "..." : ""}`,
    steps: analysis.plan,
  };
}

// ─── Quality Evaluator ────────────────────────────────────
function evaluateResult(result: string): { passed: boolean; score: number; feedback: string } {
  if (!result || result.trim().length < 10) return { passed: false, score: 0, feedback: "Empty or too short result" };
  if (result.toLowerCase().includes("error") || result.toLowerCase().includes("failed")) {
    return { passed: false, score: 3, feedback: "Result contains errors — revision needed" };
  }
  return { passed: true, score: 8, feedback: "Objective met successfully" };
}

export async function registerRoutes(httpServer: Server, app: Express): Promise<void> {

  // ── System / Core ───────────────────────────────────────
  app.get("/api/system/status", (_req, res) => {
    const agentList = storage.getAgents();
    const taskList = storage.getTasks();
    const memList = storage.getMemories();
    const runningTasks = taskList.filter(t => t.status === "in_progress").length;
    const activeAgents = agentList.filter(a => a.status === "active").length;
    res.json({
      status: "online",
      version: "1.0.0",
      uptime: process.uptime(),
      agents: { total: agentList.length, active: activeAgents },
      tasks: { total: taskList.length, running: runningTasks },
      memories: memList.length,
      timestamp: new Date().toISOString(),
    });
  });

  // ── Gideon Core: Intent Analysis ────────────────────────
  app.post("/api/core/analyze", (req, res) => {
    const { input } = req.body;
    if (!input) return res.status(400).json({ error: "input required" });
    const analysis = analyzeIntent(input);
    res.json({ input, ...analysis });
  });

  // ── Gideon Core: Execute Task ────────────────────────────
  app.post("/api/core/execute", (req, res) => {
    const { input, projectId } = req.body;
    if (!input) return res.status(400).json({ error: "input required" });
    const analysis = analyzeIntent(input);
    const plan = buildExecutionPlan(analysis.goal, input, analysis.agents);

    // Create task
    const task = storage.createTask({
      title: plan.title,
      description: input,
      status: analysis.riskScore >= 8 ? "pending" : "in_progress",
      priority: analysis.complexity === "high" ? "high" : analysis.complexity === "medium" ? "medium" : "low",
      projectId: projectId || undefined,
      steps: JSON.stringify(plan.steps.map((s, i) => ({ step: i + 1, label: s, status: "pending" }))),
      riskScore: analysis.riskScore,
    });

    // Store episodic memory of execution
    storage.createMemory({
      category: "episodic",
      type: "event",
      title: `Task initiated: ${plan.title.slice(0, 60)}`,
      content: `Goal: ${analysis.goal}. Agents: ${analysis.agents.join(", ")}. Risk: ${analysis.riskScore}. Steps: ${plan.steps.length}`,
      tags: JSON.stringify(["task", "execution", analysis.goal]),
      importance: analysis.complexity === "high" ? 7 : analysis.complexity === "medium" ? 5 : 3,
    });

    res.json({
      task,
      analysis,
      plan,
      requiresApproval: analysis.riskScore >= 8,
      message: analysis.riskScore >= 8
        ? `⚠️ Risk score ${analysis.riskScore}/10 — explicit approval required before execution`
        : analysis.riskScore >= 5
        ? `⚡ Risk score ${analysis.riskScore}/10 — will prompt for confirmation`
        : `✓ Risk score ${analysis.riskScore}/10 — auto-executing`,
    });
  });

  // ── Gideon Core: Evaluate Result ────────────────────────
  app.post("/api/core/evaluate", (req, res) => {
    const { taskId, result } = req.body;
    if (!taskId || result === undefined) return res.status(400).json({ error: "taskId and result required" });
    const evaluation = evaluateResult(result);
    const task = storage.updateTask(taskId, {
      status: evaluation.passed ? "completed" : "failed",
      result: result,
      completedAt: new Date(),
    });
    res.json({ task, evaluation });
  });

  // ── Users ───────────────────────────────────────────────
  app.get("/api/users", (_req, res) => res.json(storage.getUsers()));
  app.get("/api/users/:id", (req, res) => {
    const u = storage.getUser(Number(req.params.id));
    if (!u) return res.status(404).json({ error: "not found" });
    res.json(u);
  });
  app.post("/api/users", (req, res) => {
    const parsed = insertUserSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    res.status(201).json(storage.createUser(parsed.data));
  });
  app.patch("/api/users/:id", (req, res) => {
    const updated = storage.updateUser(Number(req.params.id), req.body);
    if (!updated) return res.status(404).json({ error: "not found" });
    res.json(updated);
  });

  // ── Memories ────────────────────────────────────────────
  app.get("/api/memories", (req, res) => {
    const { category, projectId, search } = req.query;
    const mems = storage.getMemories({
      category: category as string,
      projectId: projectId ? Number(projectId) : undefined,
      search: search as string,
    });
    res.json(mems);
  });
  app.get("/api/memories/:id", (req, res) => {
    const m = storage.getMemory(Number(req.params.id));
    if (!m) return res.status(404).json({ error: "not found" });
    storage.incrementMemoryAccess(Number(req.params.id));
    res.json(m);
  });
  app.post("/api/memories", (req, res) => {
    const parsed = insertMemorySchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    res.status(201).json(storage.createMemory(parsed.data));
  });
  app.patch("/api/memories/:id", (req, res) => {
    const updated = storage.updateMemory(Number(req.params.id), req.body);
    if (!updated) return res.status(404).json({ error: "not found" });
    res.json(updated);
  });
  app.delete("/api/memories/:id", (req, res) => {
    storage.deleteMemory(Number(req.params.id));
    res.json({ success: true });
  });

  // ── Projects ────────────────────────────────────────────
  app.get("/api/projects", (_req, res) => res.json(storage.getProjects()));
  app.get("/api/projects/:id", (req, res) => {
    const p = storage.getProject(Number(req.params.id));
    if (!p) return res.status(404).json({ error: "not found" });
    res.json(p);
  });
  app.post("/api/projects", (req, res) => {
    const parsed = insertProjectSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    res.status(201).json(storage.createProject(parsed.data));
  });
  app.patch("/api/projects/:id", (req, res) => {
    const updated = storage.updateProject(Number(req.params.id), req.body);
    if (!updated) return res.status(404).json({ error: "not found" });
    res.json(updated);
  });
  app.delete("/api/projects/:id", (req, res) => {
    storage.deleteProject(Number(req.params.id));
    res.json({ success: true });
  });

  // ── Tasks ───────────────────────────────────────────────
  app.get("/api/tasks", (req, res) => {
    const { projectId, status, agentId } = req.query;
    res.json(storage.getTasks({
      projectId: projectId ? Number(projectId) : undefined,
      status: status as string,
      agentId: agentId ? Number(agentId) : undefined,
    }));
  });
  app.get("/api/tasks/:id", (req, res) => {
    const t = storage.getTask(Number(req.params.id));
    if (!t) return res.status(404).json({ error: "not found" });
    res.json(t);
  });
  app.post("/api/tasks", (req, res) => {
    const parsed = insertTaskSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    res.status(201).json(storage.createTask(parsed.data));
  });
  app.patch("/api/tasks/:id", (req, res) => {
    const updated = storage.updateTask(Number(req.params.id), req.body);
    if (!updated) return res.status(404).json({ error: "not found" });
    res.json(updated);
  });
  app.delete("/api/tasks/:id", (req, res) => {
    storage.deleteTask(Number(req.params.id));
    res.json({ success: true });
  });

  // ── Agents ──────────────────────────────────────────────
  app.get("/api/agents", (_req, res) => res.json(storage.getAgents()));
  app.get("/api/agents/:id", (req, res) => {
    const a = storage.getAgent(Number(req.params.id));
    if (!a) return res.status(404).json({ error: "not found" });
    res.json(a);
  });
  app.post("/api/agents", (req, res) => {
    const parsed = insertAgentSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    res.status(201).json(storage.createAgent(parsed.data));
  });
  app.patch("/api/agents/:id", (req, res) => {
    const updated = storage.updateAgent(Number(req.params.id), req.body);
    if (!updated) return res.status(404).json({ error: "not found" });
    res.json(updated);
  });
  app.delete("/api/agents/:id", (req, res) => {
    storage.deleteAgent(Number(req.params.id));
    res.json({ success: true });
  });
  // Activate/deactivate agent
  app.post("/api/agents/:id/activate", (req, res) => {
    const updated = storage.updateAgent(Number(req.params.id), { status: "active", lastActiveAt: new Date() });
    res.json(updated);
  });
  app.post("/api/agents/:id/deactivate", (req, res) => {
    const updated = storage.updateAgent(Number(req.params.id), { status: "idle" });
    res.json(updated);
  });

  // ── Agent Runs ──────────────────────────────────────────
  app.get("/api/agent-runs", (req, res) => {
    const { agentId, taskId } = req.query;
    res.json(storage.getAgentRuns(agentId ? Number(agentId) : undefined, taskId ? Number(taskId) : undefined));
  });
  app.post("/api/agent-runs", (req, res) => {
    const parsed = insertAgentRunSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    res.status(201).json(storage.createAgentRun(parsed.data));
  });
  app.patch("/api/agent-runs/:id", (req, res) => {
    const updated = storage.updateAgentRun(Number(req.params.id), req.body);
    if (!updated) return res.status(404).json({ error: "not found" });
    res.json(updated);
  });

  // ── Skills ──────────────────────────────────────────────
  app.get("/api/skills", (_req, res) => res.json(storage.getSkills()));
  app.get("/api/skills/:id", (req, res) => {
    const s = storage.getSkill(Number(req.params.id));
    if (!s) return res.status(404).json({ error: "not found" });
    res.json(s);
  });
  app.post("/api/skills", (req, res) => {
    const parsed = insertSkillSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    res.status(201).json(storage.createSkill(parsed.data));
  });
  app.patch("/api/skills/:id", (req, res) => {
    const updated = storage.updateSkill(Number(req.params.id), req.body);
    if (!updated) return res.status(404).json({ error: "not found" });
    res.json(updated);
  });
  app.delete("/api/skills/:id", (req, res) => {
    storage.deleteSkill(Number(req.params.id));
    res.json({ success: true });
  });

  // ── Files ───────────────────────────────────────────────
  app.get("/api/files", (req, res) => {
    const { projectId, type, indexed } = req.query;
    res.json(storage.getFiles({
      projectId: projectId ? Number(projectId) : undefined,
      type: type as string,
      indexed: indexed !== undefined ? indexed === "true" : undefined,
    }));
  });
  app.get("/api/files/:id", (req, res) => {
    const f = storage.getFile(Number(req.params.id));
    if (!f) return res.status(404).json({ error: "not found" });
    res.json(f);
  });
  app.post("/api/files", (req, res) => {
    const parsed = insertFileSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    res.status(201).json(storage.createFile(parsed.data));
  });
  app.patch("/api/files/:id", (req, res) => {
    const updated = storage.updateFile(Number(req.params.id), req.body);
    if (!updated) return res.status(404).json({ error: "not found" });
    res.json(updated);
  });
  app.delete("/api/files/:id", (req, res) => {
    storage.deleteFile(Number(req.params.id));
    res.json({ success: true });
  });

  // File Intelligence: Minerva-powered indexing
  app.post("/api/files/:id/index", async (req, res) => {
    const file = storage.getFile(Number(req.params.id));
    if (!file) return res.status(404).json({ error: "file not found" });

    const users = storage.getUsers();
    const user = users[0];
    const ollamaUrl = user?.ollamaUrl || "http://localhost:11434";
    const ollamaModel = (user?.preferredModel || "ollama/llama3.2:3b").replace(/^ollama\//, "");

    try {
      const result = await runMinerva(
        { task: `Index and summarize: ${file.name}`, filePath: file.path, fileType: file.type, mimeType: file.mimeType || undefined, projectId: file.projectId || undefined },
        { ollamaUrl, ollamaModel }
      );

      storage.updateFile(file.id, {
        summary: result.summary,
        indexed: true,
        tags: JSON.stringify([...JSON.parse(file.tags || "[]"), result.fileType, "indexed"]),
      });

      res.json({ file: storage.getFile(file.id), analysis: result.analysis, entities: result.entities, keyPoints: result.keyPoints });
    } catch (err) {
      res.status(500).json({ error: String(err) });
    }
  });
  // Index a file (simulate processing pipeline)
  app.post("/api/files/:id/index", (req, res) => {
    const file = storage.getFile(Number(req.params.id));
    if (!file) return res.status(404).json({ error: "not found" });
    const updated = storage.updateFile(Number(req.params.id), {
      indexed: true,
      indexedAt: new Date(),
      summary: `Processed: ${file.name}. Type: ${file.type}. Ready for semantic search.`,
    });
    // Store in memory
    storage.createMemory({
      category: "long_term",
      type: "fact",
      title: `Indexed file: ${file.name}`,
      content: `File ${file.name} (${file.type}, ${file.size ? Math.round(file.size/1024)+'KB' : 'unknown size'}) indexed and available for semantic search.`,
      tags: JSON.stringify(["file", "indexed", file.type]),
      importance: 4,
    });
    res.json(updated);
  });

  // ── Conversations ────────────────────────────────────────
  app.get("/api/conversations", (req, res) => {
    res.json(storage.getConversations(req.query.projectId ? Number(req.query.projectId) : undefined));
  });
  app.get("/api/conversations/:id", (req, res) => {
    const c = storage.getConversation(Number(req.params.id));
    if (!c) return res.status(404).json({ error: "not found" });
    res.json(c);
  });
  app.post("/api/conversations", (req, res) => {
    const parsed = insertConversationSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    res.status(201).json(storage.createConversation(parsed.data));
  });
  app.patch("/api/conversations/:id", (req, res) => {
    const updated = storage.updateConversation(Number(req.params.id), req.body);
    if (!updated) return res.status(404).json({ error: "not found" });
    res.json(updated);
  });
  app.delete("/api/conversations/:id", (req, res) => {
    storage.deleteConversation(Number(req.params.id));
    res.json({ success: true });
  });
  // Add message to conversation
  app.post("/api/conversations/:id/messages", (req, res) => {
    const conv = storage.getConversation(Number(req.params.id));
    if (!conv) return res.status(404).json({ error: "not found" });
    const { role, content } = req.body;
    const messages = JSON.parse(conv.messages || "[]");
    messages.push({ role, content, ts: new Date().toISOString() });
    // Auto-generate response for assistant
    let response = null;
    if (role === "user") {
      const analysis = analyzeIntent(content);
      const responseMsg = {
        role: "assistant",
        content: `[Gideon Core] Intent: ${analysis.goal} | Complexity: ${analysis.complexity} | Agents: ${analysis.agents.join(", ")} | Risk: ${analysis.riskScore}/10\n\nPlan:\n${analysis.plan.map((s, i) => `${i+1}. ${s}`).join("\n")}`,
        ts: new Date().toISOString(),
      };
      messages.push(responseMsg);
      response = responseMsg;
    }
    const updated = storage.updateConversation(Number(req.params.id), {
      messages: JSON.stringify(messages),
      title: conv.title || content.slice(0, 50),
    });
    res.json({ conversation: updated, response });
  });

  // ── Scheduled Jobs ───────────────────────────────────────
  app.get("/api/scheduled-jobs", (_req, res) => res.json(storage.getScheduledJobs()));
  app.get("/api/scheduled-jobs/:id", (req, res) => {
    const j = storage.getScheduledJob(Number(req.params.id));
    if (!j) return res.status(404).json({ error: "not found" });
    res.json(j);
  });
  app.post("/api/scheduled-jobs", (req, res) => {
    const parsed = insertScheduledJobSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    res.status(201).json(storage.createScheduledJob(parsed.data));
  });
  app.patch("/api/scheduled-jobs/:id", (req, res) => {
    const updated = storage.updateScheduledJob(Number(req.params.id), req.body);
    if (!updated) return res.status(404).json({ error: "not found" });
    res.json(updated);
  });
  app.delete("/api/scheduled-jobs/:id", (req, res) => {
    storage.deleteScheduledJob(Number(req.params.id));
    res.json({ success: true });
  });



  // ── Hermes Runtime: dispatch to Atlas ────────────────────────────────────
  app.post("/api/hermes/research", async (req, res) => {
    const { query, projectId, maxSources, extractDepth, firecrawlKey } = req.body;
    if (!query) return res.status(400).json({ error: "query required" });

    const users = storage.getUsers();
    const user = users[0];
    const ollamaUrl = user?.ollamaUrl || "http://localhost:11434";
    const ollamaModel = (user?.preferredModel || "ollama/llama3.2:3b").replace(/^ollama\//, "");

    try {
      const result = await runAtlasResearch(
        { query, projectId, maxSources: maxSources || 5, extractDepth, firecrawlKey } as ResearchIntent,
        { ollamaUrl, ollamaModel }
      );

      // Create a completed task record for this research run
      const task = storage.createTask({
        title: `Atlas research: ${query.slice(0, 60)}`,
        description: query,
        status: "completed",
        priority: "medium",
        projectId,
        steps: JSON.stringify([
          { step: 1, label: "Decompose query", status: "completed" },
          { step: 2, label: `Scrape ${result.sources.length} sources`, status: "completed" },
          { step: 3, label: `Extract insights`, status: "completed" },
          { step: 4, label: "Rank & deduplicate", status: "completed" },
          { step: 5, label: "Synthesize summary", status: "completed" },
          { step: 6, label: `Store ${result.qdrantIds.length} vectors in Qdrant`, status: "completed" },
          { step: 7, label: "Log to Project Brain", status: result.projectLogId ? "completed" : "skipped" },
        ]),
        result: result.summary.slice(0, 500),
        riskScore: 1,
      });
      storage.updateTask(task.id, { startedAt: new Date(), completedAt: new Date() });

      res.json({ ...result, taskId: task.id });
    } catch (err: unknown) {
      console.error("[Hermes] Research dispatch error:", err);
      res.status(500).json({ error: String(err) });
    }
  });

  // ── Hermes: Streaming research (SSE) ─────────────────────────────────────
  // Emits step-by-step SSE events so the UI can render live pipeline progress.
  app.post("/api/hermes/research/stream", async (req, res) => {
    const { query, projectId, maxSources, firecrawlKey } = req.body;
    if (!query) return res.status(400).json({ error: "query required" });

    const users = storage.getUsers();
    const user = users[0];
    const ollamaUrl = user?.ollamaUrl || "http://localhost:11434";
    const ollamaModel = (user?.preferredModel || "ollama/llama3.2:3b").replace(/^ollama\//, "");

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no");
    res.flushHeaders();

    const emit = (event: string, data: Record<string, unknown>) => {
      res.write("data: " + JSON.stringify({ event, ...data }) + "\n\n");
    };

    try {
      // Step 0 — initializing
      emit("status", { message: "Atlas initializing research pipeline...", step: 0, total: 7 });

      // Step 1 — decompose
      emit("status", { message: "Decomposing query into sub-queries", step: 1 });

      // Step 2 — scrape (emit before the heavy work)
      // We run the full pipeline and emit events as results arrive
      const result = await runAtlasResearch(
        { query, projectId, maxSources: maxSources || 5, firecrawlKey } as ResearchIntent,
        { ollamaUrl, ollamaModel }
      );

      // Emit individual step completions
      emit("decomposed", { queries: result.subQueries, step: 1 });
      emit("status", { message: `Scraped ${result.sources.length} sources`, step: 2 });
      emit("scraped", { sources: result.sources, count: result.sources.length, step: 2 });
      emit("status", { message: `Extracted ${result.insights.length} insights`, step: 3 });
      emit("insights", { insights: result.insights, count: result.insights.length, step: 3 });
      emit("status", { message: "Ranking and deduplicating insights", step: 4 });
      emit("status", { message: "Generating synthesis summary", step: 5 });
      emit("summary", { summary: result.summary, step: 5 });
      emit("status", { message: `Storing ${result.qdrantIds.length} vectors in Qdrant`, step: 6 });
      emit("stored", { qdrantIds: result.qdrantIds, memoryIds: result.memoryIds, vectors: result.qdrantIds.length, step: 6 });
      if (result.projectLogId) {
        emit("status", { message: "Logged to Project Brain", step: 7 });
      }

      // Final complete event — include ALL result data for the UI
      emit("complete", {
        query: result.query,
        subQueries: result.subQueries,
        sources: result.sources,
        insights: result.insights,
        summary: result.summary,
        memoryIds: result.memoryIds,
        qdrantIds: result.qdrantIds,
        projectLogId: result.projectLogId,
        durationMs: result.durationMs,
        model: result.model,
        step: 7,
      });
    } catch (err: unknown) {
      emit("error", { error: String(err), step: -1 });
    }

    res.end();
  });

  // ── Qdrant: semantic search ───────────────────────────────────────────────
  app.get("/api/qdrant/search", async (req, res) => {
    const { q, category, projectId, limit } = req.query;
    if (!q) return res.status(400).json({ error: "q required" });

    const users = storage.getUsers();
    const ollamaUrl = users[0]?.ollamaUrl || "http://localhost:11434";

    const results = await semanticSearch(q as string, {
      category: category as string,
      projectId: projectId ? Number(projectId) : undefined,
      limit: limit ? Number(limit) : 10,
      ollamaUrl,
    });
    res.json({ results, count: results.length });
  });

  // ── Qdrant: collection stats ──────────────────────────────────────────────
  app.get("/api/qdrant/stats", async (_req, res) => {
    const stats = await getCollectionStats();
    res.json(stats);
  });

  // ── Qdrant: delete a point ────────────────────────────────────────────────
  app.delete("/api/qdrant/:id", async (req, res) => {
    const ok = await deletePoint(req.params.id);
    res.json({ success: ok });
  });

  // ── LLM: Ollama health check ──────────────────────────────────────────────
  app.get("/api/llm/status", async (_req, res) => {
    const users = storage.getUsers();
    const ollamaUrl = users[0]?.ollamaUrl || "http://localhost:11434";
    const result = await checkOllama(ollamaUrl);
    res.json({
      ollamaUrl,
      ...result,
      hasAnthropicKey: !!(users[0]?.anthropicKey),
      hasOpenaiKey: !!(users[0]?.openaiKey),
      fallback: result.available ? null : "anthropic",
    });
  });

  // ── LLM: Streaming chat via SSE ───────────────────────────────────────────
  app.post("/api/llm/chat", async (req, res) => {
    const { messages, conversationId, agentId, extraContext } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "messages array required" });
    }

    const users = storage.getUsers();
    const user = users[0];
    const ollamaUrl = user?.ollamaUrl || "http://localhost:11434";
    const rawModel = user?.preferredModel || "ollama/llama3.2:3b";
    const ollamaModel = rawModel.replace(/^ollama\//, "");

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no");
    res.flushHeaders();

    let runId: number | null = null;
    const startTime = Date.now();
    if (agentId) {
      const run = storage.createAgentRun({
        agentId,
        taskId: undefined,
        input: messages[messages.length - 1]?.content || "",
        status: "running",
        tokensUsed: 0,
      });
      runId = run.id;
      storage.updateAgent(agentId, { status: "active", lastActiveAt: new Date() });
    }

    let fullResponse = "";
    let totalTokens = 0;
    let modelSource = "unknown";

    try {
      for await (const chunk of streamLLM(messages as LLMMessage[], {
        ollamaUrl,
        ollamaModel,
        extraContext,
      })) {
        fullResponse += chunk.text;
        if (chunk.tokensUsed) totalTokens = chunk.tokensUsed;
        modelSource = chunk.source;
        res.write(`data: ${JSON.stringify({ text: chunk.text, done: chunk.done, source: chunk.source })}\n\n`);
        if (chunk.done) break;
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      res.write(`data: ${JSON.stringify({ error: msg, done: true })}\n\n`);
    }

    if (runId && agentId) {
      storage.updateAgentRun(runId, {
        output: fullResponse, status: "completed",
        tokensUsed: totalTokens, durationMs: Date.now() - startTime,
      });
      const agent = storage.getAgent(agentId);
      if (agent) storage.updateAgent(agentId, { status: "idle", taskCount: agent.taskCount + 1 });
    }

    if (conversationId && fullResponse) {
      const conv = storage.getConversation(conversationId);
      if (conv) {
        const msgs = JSON.parse(conv.messages || "[]");
        msgs.push({ role: "assistant", content: fullResponse, ts: new Date().toISOString(), source: modelSource });
        storage.updateConversation(conversationId, { messages: JSON.stringify(msgs) });
      }
    }

    if (fullResponse.length > 200) {
      const lastUser = [...(messages as LLMMessage[])].reverse().find(m => m.role === "user");
      if (lastUser) {
        storage.createMemory({
          category: "episodic", type: "conversation",
          title: `Chat: ${String(lastUser.content).slice(0, 60)}`,
          content: `User: ${String(lastUser.content).slice(0, 200)}\n\nGideon: ${fullResponse.slice(0, 400)}`,
          tags: JSON.stringify(["conversation", modelSource]),
          importance: 3,
        });
      }
    }

    res.write(`data: ${JSON.stringify({ done: true, source: modelSource, tokensUsed: totalTokens })}\n\n`);
    res.end();
  });

  // ── LLM: Non-streaming completion ────────────────────────────────────────
  app.post("/api/llm/complete", async (req, res) => {
    const { prompt, agentId, taskId, storeMemory } = req.body;
    if (!prompt) return res.status(400).json({ error: "prompt required" });

    const users = storage.getUsers();
    const user = users[0];
    const ollamaUrl = user?.ollamaUrl || "http://localhost:11434";
    const ollamaModel = (user?.preferredModel || "ollama/llama3.2:3b").replace(/^ollama\//, "");

    const startTime = Date.now();
    let runId: number | null = null;

    if (agentId) {
      const run = storage.createAgentRun({ agentId, taskId, input: prompt, status: "running", tokensUsed: 0 });
      runId = run.id;
      storage.updateAgent(agentId, { status: "active", lastActiveAt: new Date() });
    }

    try {
      const result = await completeLLM(prompt, { ollamaUrl, ollamaModel });

      if (runId && agentId) {
        storage.updateAgentRun(runId, {
          output: result.text, status: "completed",
          tokensUsed: result.tokensUsed, durationMs: Date.now() - startTime,
        });
        const agent = storage.getAgent(agentId);
        if (agent) storage.updateAgent(agentId, { status: "idle", taskCount: agent.taskCount + 1 });
      }

      if (storeMemory && result.text.length > 100) {
        storage.createMemory({
          category: "episodic", type: "event",
          title: `Agent result: ${prompt.slice(0, 50)}`,
          content: result.text.slice(0, 600),
          tags: JSON.stringify(["agent_run", result.source]),
          importance: 4,
        });
      }

      res.json({ text: result.text, source: result.source, tokensUsed: result.tokensUsed, durationMs: Date.now() - startTime });
    } catch (err: unknown) {
      if (runId) storage.updateAgentRun(runId, { status: "failed", error: String(err) });
      if (agentId) storage.updateAgent(agentId, { status: "error" });
      res.status(500).json({ error: String(err) });
    }
  });

  // ── LLM: Execute a stored task with inference ─────────────────────────────
  app.post("/api/llm/execute-task", async (req, res) => {
    const { taskId } = req.body;
    if (!taskId) return res.status(400).json({ error: "taskId required" });

    const task = storage.getTask(taskId);
    if (!task) return res.status(404).json({ error: "task not found" });

    const users = storage.getUsers();
    const user = users[0];
    const ollamaUrl = user?.ollamaUrl || "http://localhost:11434";
    const ollamaModel = (user?.preferredModel || "ollama/llama3.2:3b").replace(/^ollama\//, "");

    storage.updateTask(taskId, { status: "in_progress", startedAt: new Date() });

    try {
      const stepsText = (() => {
        try { return JSON.parse(task.steps).map((s: {step: number; label: string}) => `${s.step}. ${s.label}`).join("\n"); }
        catch { return ""; }
      })();

      const prompt = `Execute this task completely:\n\nTask: ${task.title}\n${task.description ? `Description: ${task.description}` : ""}\n\nPlan steps:\n${stepsText}\n\nProvide a complete, detailed response. Include code blocks, commands, or analysis as appropriate.`;

      const result = await completeLLM(prompt, { ollamaUrl, ollamaModel });

      storage.updateTask(taskId, { status: "completed", result: result.text.slice(0, 2000), completedAt: new Date() });

      storage.createMemory({
        category: "long_term", type: "event",
        title: `Task completed: ${task.title.slice(0, 60)}`,
        content: result.text.slice(0, 600),
        tags: JSON.stringify(["task_result", result.source]),
        importance: 6,
        projectId: task.projectId || undefined,
      });

      res.json({ task: storage.getTask(taskId), result: result.text, source: result.source });
    } catch (err: unknown) {
      storage.updateTask(taskId, { status: "failed", result: String(err) });
      res.status(500).json({ error: String(err) });
    }
  });

  // ── Memory Stats ────────────────────────────────────────
  app.get("/api/memory/stats", (_req, res) => {
    const all = storage.getMemories();
    const byCategory = ["working", "episodic", "semantic", "procedural", "long_term"].map(cat => ({
      category: cat,
      count: all.filter(m => m.category === cat).length,
    }));
    const topAccessed = [...all].sort((a, b) => b.accessCount - a.accessCount).slice(0, 5);
    const highImportance = all.filter(m => m.importance >= 8).length;
    res.json({ total: all.length, byCategory, topAccessed, highImportance });
  });

  // -- Vulcan: coding agent --
  app.post("/api/vulcan/generate", async (req, res) => {
    const { task, description, language, framework, projectId, writeFiles } = req.body;
    if (!task) return res.status(400).json({ error: "task required" });
    const users = storage.getUsers();
    const user = users[0];
    const ollamaUrl = user?.ollamaUrl || "http://localhost:11434";
    const ollamaModel = (user?.preferredModel || "ollama/llama3.2:3b").replace(/^ollama\//, "");
    const memCtx = await buildMemoryContext(task, projectId, ollamaUrl);
    const taskRecord = storage.createTask({
      title: task, description, status: "in_progress", priority: "medium",
      steps: JSON.stringify(["Plan","Generate","Review","Store"]), startedAt: new Date(),
    });
    try {
      const result = await runVulcan(
        { task, description: description || "", language, framework, projectId, writeFiles: writeFiles !== false, memoryContext: memCtx },
        { ollamaUrl, ollamaModel }
      );
      storage.updateTask(taskRecord.id, { status: "completed", result: JSON.stringify({ files: result.files.map(f => f.filename), explanation: result.explanation }), completedAt: new Date() });
      res.json({ ...result, taskId: taskRecord.id });
    } catch (err) {
      storage.updateTask(taskRecord.id, { status: "failed", result: String(err) });
      res.status(500).json({ error: String(err) });
    }
  });

  // -- Mercury: automation agent --
  app.post("/api/mercury/run", async (req, res) => {
    const { task, description, targetUrl, extractFields, projectId } = req.body;
    if (!task) return res.status(400).json({ error: "task required" });
    const users = storage.getUsers();
    const user = users[0];
    const ollamaUrl = user?.ollamaUrl || "http://localhost:11434";
    const ollamaModel = (user?.preferredModel || "ollama/llama3.2:3b").replace(/^ollama\//, "");
    const memCtx = await buildMemoryContext(task, projectId, ollamaUrl);
    const taskRecord = storage.createTask({
      title: task, description, status: "in_progress", priority: "medium",
      steps: JSON.stringify(["Plan","Execute","Extract","Store"]), startedAt: new Date(),
    });
    try {
      const result = await runMercury(
        { task, description: description || "", targetUrl, extractFields, projectId, memoryContext: memCtx },
        { ollamaUrl, ollamaModel }
      );
      storage.updateTask(taskRecord.id, { status: "completed", result: result.output, completedAt: new Date() });
      res.json({ ...result, taskId: taskRecord.id });
    } catch (err) {
      storage.updateTask(taskRecord.id, { status: "failed", result: String(err) });
      res.status(500).json({ error: String(err) });
    }
  });

  // -- Minerva: vision/file intelligence --
  app.post("/api/minerva/analyze", async (req, res) => {
    const { task, filePath, fileContent, fileType, mimeType, projectId } = req.body;
    if (!task) return res.status(400).json({ error: "task required" });
    const users = storage.getUsers();
    const user = users[0];
    const ollamaUrl = user?.ollamaUrl || "http://localhost:11434";
    const ollamaModel = (user?.preferredModel || "ollama/llama3.2:3b").replace(/^ollama\//, "");
    const memCtx = await buildMemoryContext(task, projectId, ollamaUrl);
    try {
      const result = await runMinerva(
        { task, filePath, fileContent, fileType, mimeType, projectId, memoryContext: memCtx },
        { ollamaUrl, ollamaModel }
      );
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: String(err) });
    }
  });

  // -- Hermes: direct task dispatch by ID --
  app.post("/api/hermes/execute/:taskId", async (req, res) => {
    const taskId = parseInt(req.params.taskId);
    if (isNaN(taskId)) return res.status(400).json({ error: "invalid taskId" });
    const task = storage.getTask(taskId);
    if (!task) return res.status(404).json({ error: "task not found" });
    if (task.status === "in_progress") return res.status(409).json({ error: "task already running" });
    if (task.status === "completed") return res.json({ message: "already completed", task });
    executeTask(taskId).catch(console.error);
    res.json({ message: "dispatched", taskId, agentType: classifyTask(task.title, task.description) });
  });

  // -- Hermes: task classification preview --
  app.post("/api/hermes/classify", (req, res) => {
    const { title, description } = req.body;
    if (!title) return res.status(400).json({ error: "title required" });
    const agentType = classifyTask(title, description);
    res.json({ agentType, title, description });
  });

  // -- Agent runs: list and get --
  app.get("/api/agent-runs", (req, res) => {
    const { agentId, taskId } = req.query;
    const runs = storage.getAgentRuns(
      agentId ? Number(agentId) : undefined,
      taskId ? Number(taskId) : undefined
    );
    res.json(runs);
  });

  app.get("/api/agent-runs/:id", (req, res) => {
    const run = storage.getAgentRun(Number(req.params.id));
    if (!run) return res.status(404).json({ error: "not found" });
    res.json(run);
  });

  // -- Start Hermes runtime loop on server boot --
  startHermes();
}

// ─── LLM Engine Routes ─────────────────────────────────────────────────────
// (appended after registerRoutes - imported inline)
