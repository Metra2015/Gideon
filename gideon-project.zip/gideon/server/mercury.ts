/**
 * Mercury — Automation Agent
 *
 * Handles web fetch, content extraction, form data simulation,
 * structured data parsing, monitoring tasks, and browser-like
 * workflows — without requiring a real browser (uses Node fetch).
 *
 * Workflow:
 *   Intent
 *     └─ Action planning (LLM)
 *           └─ Execute steps: fetch, extract, transform, monitor
 *                 └─ Structure results (LLM)
 *                       └─ Store in SQLite memory
 */

import { completeLLM } from "./llm";
import { storage } from "./storage";

// ── Types ──────────────────────────────────────────────────────────────────
export interface MercuryIntent {
  task: string;
  description: string;
  targetUrl?: string;
  extractFields?: string[];
  memoryContext?: string;
  projectId?: number;
}

export interface AutomationStep {
  action: string;  // fetch | extract | transform | store | check | compute
  target?: string;
  result?: string;
  status: "pending" | "completed" | "failed" | "skipped";
  durationMs?: number;
}

export interface MercuryResult {
  task: string;
  steps: AutomationStep[];
  data: Record<string, unknown>;
  output: string;
  memoryIds: number[];
  durationMs: number;
  model: string;
}

// ── Step 1: Plan automation steps ────────────────────────────────────────
async function planAutomation(
  task: string,
  description: string,
  targetUrl?: string,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<{ steps: { action: string; target: string; description: string }[]; approach: string }> {
  const prompt = `You are Mercury, Gideon's automation agent. Plan the automation steps for this task.

Task: "${task}"
Description: "${description}"
${targetUrl ? `Target URL: ${targetUrl}` : ""}

Return ONLY valid JSON:
{
  "approach": "one sentence summary",
  "steps": [
    {"action": "fetch", "target": "https://example.com", "description": "Fetch the page"},
    {"action": "extract", "target": "title, price, description", "description": "Extract key fields"},
    {"action": "transform", "target": "normalize prices to USD", "description": "Clean the data"},
    {"action": "store", "target": "memory", "description": "Save findings"}
  ]
}

Actions available: fetch (HTTP GET), extract (parse content), transform (process data), compute (calculate), check (validate), store (save result)
Maximum 6 steps. Be concrete.`;

  try {
    const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 600 });
    const match = res.text.match(/\{[\s\S]*?\}/s);
    if (match) {
      const parsed = JSON.parse(match[0]);
      if (parsed.steps && Array.isArray(parsed.steps)) return parsed;
    }
  } catch {
    // fall through
  }

  // Fallback plan
  return {
    approach: "Direct task execution",
    steps: targetUrl
      ? [
          { action: "fetch", target: targetUrl, description: "Fetch target URL" },
          { action: "extract", target: "main content", description: "Extract content" },
          { action: "store", target: "memory", description: "Store findings" },
        ]
      : [
          { action: "compute", target: task, description: "Process task" },
          { action: "store", target: "memory", description: "Store result" },
        ],
  };
}

// ── HTTP fetch with timeout ───────────────────────────────────────────────
async function safeFetch(url: string, timeoutMs = 10000): Promise<{ ok: boolean; text: string; status: number }> {
  try {
    const res = await fetch(url, {
      signal: AbortSignal.timeout(timeoutMs),
      headers: {
        "User-Agent": "Gideon/1.0 Mercury-Agent (+https://github.com/gideon)",
        "Accept": "text/html,application/json,text/plain,*/*",
      },
    });
    const text = await res.text();
    return { ok: res.ok, text: text.slice(0, 15000), status: res.status };
  } catch (err) {
    return { ok: false, text: String(err), status: 0 };
  }
}

// ── Extract structured data from raw content (LLM) ───────────────────────
async function extractFromContent(
  content: string,
  fields: string,
  task: string,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<Record<string, unknown>> {
  const prompt = `You are Mercury. Extract structured data from this content.

Task context: "${task}"
Fields to extract: ${fields}

Content:
${content.slice(0, 4000)}

Return ONLY valid JSON with the extracted fields. If a field is not found, use null.
Example: {"title": "...", "price": "...", "description": "..."}`;

  try {
    const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 600 });
    const match = res.text.match(/\{[\s\S]*?\}/);
    if (match) return JSON.parse(match[0]) as Record<string, unknown>;
  } catch {
    // fall through
  }
  return { raw_content: content.slice(0, 500) };
}

// ── Transform / compute step ──────────────────────────────────────────────
async function computeStep(
  target: string,
  task: string,
  accumulated: Record<string, unknown>,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<Record<string, unknown>> {
  const prompt = `You are Mercury. Perform this computation/transformation.

Task: "${task}"
Step: "${target}"
Current data:
${JSON.stringify(accumulated, null, 2).slice(0, 1000)}

Return ONLY valid JSON with the result of this step added to or transforming the data.`;

  try {
    const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 400 });
    const match = res.text.match(/\{[\s\S]*?\}/);
    if (match) return { ...accumulated, ...JSON.parse(match[0]) as Record<string, unknown> };
  } catch {
    // fall through
  }
  return accumulated;
}

// ── Generate final summary ────────────────────────────────────────────────
async function summarizeAutomation(
  task: string,
  steps: AutomationStep[],
  data: Record<string, unknown>,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<string> {
  const completedSteps = steps.filter(s => s.status === "completed");
  const prompt = `You are Mercury. Summarize what was accomplished.

Task: "${task}"
Steps completed: ${completedSteps.length}/${steps.length}
Data collected:
${JSON.stringify(data, null, 2).slice(0, 800)}

Write 2-3 sentences: what was done, what was found, what the result is. Be direct.`;

  try {
    const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 200 });
    return res.text.trim();
  } catch {
    return `Automation completed ${completedSteps.length}/${steps.length} steps for: ${task}`;
  }
}

// ── Master Mercury function ────────────────────────────────────────────────
export async function runMercury(
  intent: MercuryIntent,
  options: { ollamaUrl?: string; ollamaModel?: string } = {}
): Promise<MercuryResult> {
  const startTime = Date.now();
  const { ollamaUrl, ollamaModel } = options;

  // Find Mercury agent
  const agents = storage.getAgents();
  const mercury = agents.find(a => a.name === "Mercury" || a.type === "automation");
  if (mercury) storage.updateAgent(mercury.id, { status: "active", lastActiveAt: new Date() });

  console.log(`[Mercury] Starting: "${intent.task}"`);

  // 1. Plan
  const plan = await planAutomation(
    intent.task,
    intent.description,
    intent.targetUrl,
    ollamaUrl,
    ollamaModel
  );
  console.log(`[Mercury] Plan: ${plan.steps.length} steps — ${plan.approach}`);

  // 2. Execute steps
  const executedSteps: AutomationStep[] = [];
  const accumulated: Record<string, unknown> = {};
  let lastFetchedContent = "";

  for (const step of plan.steps) {
    const stepStart = Date.now();
    const execStep: AutomationStep = {
      action: step.action,
      target: step.target,
      status: "pending",
    };

    try {
      if (step.action === "fetch") {
        const url = step.target.startsWith("http") ? step.target : intent.targetUrl || step.target;
        if (!url || !url.startsWith("http")) {
          execStep.status = "skipped";
          execStep.result = "No valid URL";
        } else {
          const fetched = await safeFetch(url);
          lastFetchedContent = fetched.text;
          accumulated.fetch_status = fetched.status;
          accumulated.fetch_ok = fetched.ok;
          accumulated.content_length = fetched.text.length;
          execStep.status = fetched.ok ? "completed" : "failed";
          execStep.result = `HTTP ${fetched.status}, ${fetched.text.length} chars`;
        }

      } else if (step.action === "extract") {
        const content = lastFetchedContent || JSON.stringify(accumulated);
        const fields = intent.extractFields?.join(", ") || step.target || "all relevant fields";
        const extracted = await extractFromContent(content, fields, intent.task, ollamaUrl, ollamaModel);
        Object.assign(accumulated, extracted);
        execStep.status = "completed";
        execStep.result = `Extracted ${Object.keys(extracted).length} fields`;

      } else if (step.action === "transform" || step.action === "compute" || step.action === "check") {
        const transformed = await computeStep(step.target, intent.task, accumulated, ollamaUrl, ollamaModel);
        Object.assign(accumulated, transformed);
        execStep.status = "completed";
        execStep.result = `Processed: ${step.target.slice(0, 60)}`;

      } else if (step.action === "store") {
        // Storage happens after all steps — mark as done
        execStep.status = "completed";
        execStep.result = "Queued for storage";

      } else {
        execStep.status = "skipped";
        execStep.result = `Unknown action: ${step.action}`;
      }
    } catch (err) {
      execStep.status = "failed";
      execStep.result = String(err);
      console.error(`[Mercury] Step ${step.action} failed:`, err);
    }

    execStep.durationMs = Date.now() - stepStart;
    executedSteps.push(execStep);
    console.log(`[Mercury] ${step.action} → ${execStep.status} (${execStep.durationMs}ms)`);
  }

  // 3. Summarize
  const output = await summarizeAutomation(intent.task, executedSteps, accumulated, ollamaUrl, ollamaModel);

  // 4. Store in memory
  const memoryIds: number[] = [];
  const mem = storage.createMemory({
    category: "episodic",
    type: "event",
    title: `Mercury: ${intent.task.slice(0, 60)}`,
    content: `${output}\n\nData: ${JSON.stringify(accumulated).slice(0, 300)}`,
    tags: JSON.stringify(["mercury", "automation", "completed"]),
    importance: 5,
    projectId: intent.projectId,
  });
  memoryIds.push(mem.id);

  // Update agent
  if (mercury) {
    storage.updateAgent(mercury.id, {
      status: "idle",
      taskCount: mercury.taskCount + 1,
      lastActiveAt: new Date(),
    });
  }

  console.log(`[Mercury] Done in ${Date.now() - startTime}ms`);

  return {
    task: intent.task,
    steps: executedSteps,
    data: accumulated,
    output,
    memoryIds,
    durationMs: Date.now() - startTime,
    model: ollamaModel || "cloud",
  };
}
