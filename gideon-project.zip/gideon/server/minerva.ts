/**
 * Minerva — Vision Agent
 *
 * Handles: OCR, image analysis, file content parsing (PDF/text/code),
 * entity extraction, document understanding, screenshot analysis.
 *
 * Workflow:
 *   File/Image input
 *     └─ File type detection
 *           └─ Content extraction (read file, base64 encode for images)
 *                 └─ LLM analysis (multimodal if image, text if document)
 *                       └─ Entity + structure extraction
 *                             └─ Summary generation
 *                                   └─ Store in SQLite memory + files table
 */

import { completeLLM } from "./llm";
import { storage } from "./storage";
import * as fs from "fs";
import * as path from "path";

// ── Types ──────────────────────────────────────────────────────────────────
export interface MinervaIntent {
  task: string;
  filePath?: string;       // path to file on disk
  fileContent?: string;    // raw content if already loaded
  fileType?: string;       // document | image | code | data | unknown
  mimeType?: string;
  memoryContext?: string;
  projectId?: number;
  extractEntities?: boolean; // default true
}

export interface ExtractedEntity {
  type: string;   // person | org | date | number | url | email | code | concept
  value: string;
  context?: string;
}

export interface MinervaResult {
  task: string;
  fileType: string;
  filename: string;
  analysis: string;          // detailed LLM analysis
  summary: string;           // 2-3 sentence summary
  entities: ExtractedEntity[];
  keyPoints: string[];
  wordCount: number;
  memoryIds: number[];
  fileIds: number[];
  durationMs: number;
  model: string;
}

// ── Detect file type from extension ──────────────────────────────────────
function detectFileType(filePath: string): { type: string; mimeType: string } {
  const ext = path.extname(filePath).toLowerCase();
  const imageExts = [".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg"];
  const docExts = [".pdf", ".docx", ".doc", ".txt", ".md", ".rtf"];
  const codeExts = [".ts", ".tsx", ".js", ".jsx", ".py", ".go", ".rs", ".cpp", ".c", ".java", ".sh", ".json", ".yaml", ".yml", ".toml"];
  const dataExts = [".csv", ".xlsx", ".xls", ".xml", ".jsonl"];

  if (imageExts.includes(ext)) return { type: "image", mimeType: `image/${ext.slice(1)}` };
  if (docExts.includes(ext)) return { type: "document", mimeType: "text/plain" };
  if (codeExts.includes(ext)) return { type: "code", mimeType: "text/plain" };
  if (dataExts.includes(ext)) return { type: "data", mimeType: "text/csv" };
  return { type: "unknown", mimeType: "text/plain" };
}

// ── Read file content ─────────────────────────────────────────────────────
function readFileContent(filePath: string, fileType: string): string {
  try {
    if (fileType === "image") {
      // Return base64 for images — used by multimodal LLMs
      const buf = fs.readFileSync(filePath);
      return buf.toString("base64");
    }
    // Text-based files
    const content = fs.readFileSync(filePath, "utf-8");
    return content.slice(0, 20000); // cap at 20k chars
  } catch (err) {
    return `[Error reading file: ${err}]`;
  }
}

// ── Analyze text content ──────────────────────────────────────────────────
async function analyzeTextContent(
  content: string,
  filename: string,
  task: string,
  fileType: string,
  memoryContext: string,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<string> {
  const prompt = `You are Minerva, Gideon's vision and intelligence agent. Analyze this ${fileType} file.

Task: "${task}"
File: ${filename}
${memoryContext ? `\n${memoryContext}` : ""}

Content:
${content.slice(0, 6000)}

Provide a comprehensive analysis:
1. **Purpose**: What is this file/document for?
2. **Key Content**: What are the main topics, functions, or data points?
3. **Structure**: How is it organized?
4. **Notable Elements**: Highlight anything important, unusual, or actionable
5. **Quality Assessment**: Is it complete? Any gaps or issues?

Be specific and technical. Reference actual content from the file.`;

  const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 1000 });
  return res.text.trim();
}

// ── Analyze image content (with Ollama vision or text fallback) ───────────
async function analyzeImageContent(
  base64Content: string,
  filename: string,
  task: string,
  memoryContext: string,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<string> {
  // Try Ollama vision model (llava, minicpm-v, etc.)
  const url = ollamaUrl || "http://localhost:11434";
  const visionModels = ["llava", "minicpm-v", "moondream", "bakllava"];

  for (const model of visionModels) {
    try {
      const resp = await fetch(`${url}/api/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model,
          prompt: `Task: "${task}"\n\nAnalyze this image: What does it show? Describe in detail — objects, text, layout, colors, purpose. Be specific.`,
          images: [base64Content],
          stream: false,
        }),
        signal: AbortSignal.timeout(30000),
      });

      if (resp.ok) {
        const data = await resp.json() as { response?: string };
        if (data.response && data.response.length > 20) {
          console.log(`[Minerva] Vision model: ${model}`);
          return data.response;
        }
      }
    } catch {
      continue;
    }
  }

  // Fallback: use text LLM to describe what it knows about the file
  const prompt = `You are Minerva. I have an image file called "${filename}" that was submitted for the task: "${task}".
Without being able to see the image directly, provide:
1. What this type of image file likely contains based on its name
2. What analysis would typically be performed on such images
3. What the user should know about processing this file type
${memoryContext ? `\n${memoryContext}` : ""}`;

  const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 500 });
  return `[Vision model not available — text analysis only]\n\n${res.text.trim()}`;
}

// ── Extract entities ──────────────────────────────────────────────────────
async function extractEntities(
  content: string,
  fileType: string,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<ExtractedEntity[]> {
  const prompt = `You are Minerva. Extract named entities and key elements from this ${fileType} content.

Content (first 3000 chars):
${content.slice(0, 3000)}

Return ONLY valid JSON array:
[
  {"type": "person", "value": "John Smith", "context": "mentioned as author"},
  {"type": "url", "value": "https://example.com", "context": "reference link"},
  {"type": "concept", "value": "machine learning", "context": "main topic"}
]

Entity types: person | org | date | number | url | email | code_function | concept | file | command
Extract 3-10 most important entities. Return [] if nothing notable found.`;

  try {
    const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 600 });
    const match = res.text.match(/\[[\s\S]*?\]/);
    if (match) {
      const parsed = JSON.parse(match[0]) as ExtractedEntity[];
      if (Array.isArray(parsed)) return parsed.slice(0, 10);
    }
  } catch {
    // fall through
  }
  return [];
}

// ── Extract key points ────────────────────────────────────────────────────
async function extractKeyPoints(
  analysis: string,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<string[]> {
  const prompt = `Extract 3-5 key bullet points from this analysis. Return ONLY a JSON array of strings.

Analysis:
${analysis.slice(0, 2000)}

Example: ["Point one", "Point two", "Point three"]`;

  try {
    const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 300 });
    const match = res.text.match(/\[[\s\S]*?\]/);
    if (match) {
      const parsed = JSON.parse(match[0]) as string[];
      if (Array.isArray(parsed)) return parsed.slice(0, 5);
    }
  } catch {
    // fall through
  }
  // Fallback: split analysis into sentences
  return analysis.split(/[.!?]\s+/).slice(0, 3).filter(s => s.length > 20);
}

// ── Generate summary ──────────────────────────────────────────────────────
async function generateSummary(
  task: string,
  filename: string,
  analysis: string,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<string> {
  const prompt = `Summarize this file analysis in 2-3 sentences. Be concise and direct.

Task: "${task}"
File: ${filename}
Analysis: ${analysis.slice(0, 1000)}`;

  try {
    const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 150 });
    return res.text.trim();
  } catch {
    return `Analyzed ${filename}: ${analysis.slice(0, 100)}...`;
  }
}

// ── Master Minerva function ───────────────────────────────────────────────
export async function runMinerva(
  intent: MinervaIntent,
  options: { ollamaUrl?: string; ollamaModel?: string } = {}
): Promise<MinervaResult> {
  const startTime = Date.now();
  const { ollamaUrl, ollamaModel } = options;
  const memCtx = intent.memoryContext || "";

  // Find Minerva agent
  const agents = storage.getAgents();
  const minerva = agents.find(a => a.name === "Minerva" || a.type === "vision");
  if (minerva) storage.updateAgent(minerva.id, { status: "active", lastActiveAt: new Date() });

  const filename = intent.filePath ? path.basename(intent.filePath) : "unknown";
  console.log(`[Minerva] Starting: "${intent.task}" on ${filename}`);

  // 1. Detect file type
  const { type: detectedType } = intent.filePath
    ? detectFileType(intent.filePath)
    : { type: intent.fileType || "document", mimeType: "text/plain" };

  const fileType = intent.fileType || detectedType;

  // 2. Load content
  let rawContent = intent.fileContent || "";
  if (!rawContent && intent.filePath) {
    rawContent = readFileContent(intent.filePath, fileType);
  }
  if (!rawContent) rawContent = `[No content provided for task: ${intent.task}]`;

  // 3. Analyze
  console.log(`[Minerva] Analyzing ${fileType}...`);
  let analysis: string;

  if (fileType === "image") {
    analysis = await analyzeImageContent(rawContent, filename, intent.task, memCtx, ollamaUrl, ollamaModel);
  } else {
    analysis = await analyzeTextContent(rawContent, filename, intent.task, fileType, memCtx, ollamaUrl, ollamaModel);
  }

  // 4. Extract entities + key points in parallel
  const [entities, keyPoints] = await Promise.all([
    intent.extractEntities !== false
      ? extractEntities(fileType !== "image" ? rawContent : analysis, fileType, ollamaUrl, ollamaModel)
      : Promise.resolve([]),
    extractKeyPoints(analysis, ollamaUrl, ollamaModel),
  ]);

  // 5. Summary
  const summary = await generateSummary(intent.task, filename, analysis, ollamaUrl, ollamaModel);

  // 6. Word count
  const wordCount = fileType !== "image"
    ? rawContent.split(/\s+/).filter(Boolean).length
    : 0;

  // 7. Store in SQLite
  const memoryIds: number[] = [];
  const fileIds: number[] = [];

  const mem = storage.createMemory({
    category: "semantic",
    type: "fact",
    title: `Minerva analysis: ${filename}`,
    content: `${summary}\n\nKey points:\n${keyPoints.map(p => `• ${p}`).join("\n")}`,
    tags: JSON.stringify(["minerva", "vision", fileType]),
    importance: 6,
    projectId: intent.projectId,
  });
  memoryIds.push(mem.id);

  // Register file if path given and not already tracked
  if (intent.filePath) {
    const existingFiles = storage.getFiles();
    const alreadyTracked = existingFiles.find(f => f.path === intent.filePath);
    if (!alreadyTracked) {
      const fileRecord = storage.createFile({
        name: filename,
        path: intent.filePath,
        type: fileType,
        mimeType: intent.mimeType,
        size: rawContent.length,
        summary: summary,
        tags: JSON.stringify(["minerva", fileType]),
        projectId: intent.projectId,
        indexed: true,
      });
      fileIds.push(fileRecord.id);
    }
  }

  // Update agent
  if (minerva) {
    storage.updateAgent(minerva.id, {
      status: "idle",
      taskCount: minerva.taskCount + 1,
      lastActiveAt: new Date(),
    });
  }

  console.log(`[Minerva] Done in ${Date.now() - startTime}ms — ${entities.length} entities, ${keyPoints.length} key points`);

  return {
    task: intent.task,
    fileType,
    filename,
    analysis,
    summary,
    entities,
    keyPoints,
    wordCount,
    memoryIds,
    fileIds,
    durationMs: Date.now() - startTime,
    model: ollamaModel || "cloud",
  };
}
