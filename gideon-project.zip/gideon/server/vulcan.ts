/**
 * Vulcan — Coding Agent
 *
 * Workflow:
 *   Intent
 *     └─ Language + framework detection (LLM)
 *           └─ Code generation (LLM, streamed internally)
 *                 └─ Code review pass (LLM)
 *                       └─ File write to workspace
 *                             └─ Store in SQLite memory + files table
 *                                   └─ Optional test generation
 */

import { completeLLM } from "./llm";
import { storage } from "./storage";
import * as path from "path";
import * as fs from "fs";

// ── Types ──────────────────────────────────────────────────────────────────
export interface VulcanIntent {
  task: string;
  description: string;
  language?: string;
  framework?: string;
  projectId?: number;
  writeFiles?: boolean; // default true
  memoryContext?: string;
}

export interface GeneratedFile {
  filename: string;
  content: string;
  language: string;
  description: string;
}

export interface VulcanResult {
  task: string;
  language: string;
  framework: string;
  files: GeneratedFile[];
  explanation: string;
  testFile?: GeneratedFile;
  memoryIds: number[];
  fileIds: number[];
  durationMs: number;
  model: string;
}

const WORKSPACE_CODE_DIR = "/home/user/workspace/gideon/generated";

// ── Step 1: Detect language and plan ──────────────────────────────────────
async function planCoding(
  task: string,
  description: string,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<{ language: string; framework: string; files: { filename: string; purpose: string }[]; approach: string }> {
  const prompt = `You are Vulcan, Gideon's coding agent. Analyze this coding task and produce a file plan.

Task: "${task}"
Description: "${description}"

Return ONLY valid JSON (no markdown, no explanation):
{
  "language": "typescript",
  "framework": "express",
  "files": [
    {"filename": "server.ts", "purpose": "Express server entry point"}
  ],
  "approach": "one sentence describing the architecture"
}

Rules:
- language: typescript | python | javascript | rust | go | bash | sql | html | css
- framework: the main framework/library, or "none"
- files: 1-4 files maximum
- filename: use snake_case or camelCase appropriate for the language`;

  try {
    const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 400 });
    const match = res.text.match(/\{[\s\S]*?\}/);
    if (match) {
      const parsed = JSON.parse(match[0]);
      if (parsed.language && parsed.files) return parsed;
    }
  } catch {
    // fall through
  }

  // Fallback plan
  const isTypeScript = /typescript|ts\b/.test(task.toLowerCase());
  const isPython = /python|py\b/.test(task.toLowerCase());
  return {
    language: isPython ? "python" : isTypeScript ? "typescript" : "javascript",
    framework: "none",
    files: [{ filename: isPython ? "solution.py" : isTypeScript ? "solution.ts" : "solution.js", purpose: task }],
    approach: "Direct implementation",
  };
}

// ── Step 2: Generate code for a file ─────────────────────────────────────
async function generateFile(
  task: string,
  description: string,
  filename: string,
  purpose: string,
  language: string,
  framework: string,
  allFiles: { filename: string; purpose: string }[],
  memoryContext: string,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<GeneratedFile> {
  const otherFiles = allFiles.filter(f => f.filename !== filename)
    .map(f => `- ${f.filename}: ${f.purpose}`).join("\n");

  const prompt = `You are Vulcan, Gideon's expert coding agent. Write production-quality ${language} code.

Task: "${task}"
Description: "${description}"
File to generate: ${filename} (${purpose})
Language: ${language}
Framework: ${framework}
${otherFiles ? `Other files in this project:\n${otherFiles}` : ""}
${memoryContext ? `\n${memoryContext}` : ""}

Requirements:
- Write complete, working, production-quality code
- Include proper error handling
- Add clear comments for complex logic
- Follow ${language} best practices and conventions
- Do NOT include markdown code fences — output raw code only

Output the complete code for ${filename}:`;

  const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 2000 });

  // Strip any accidental markdown fences
  let code = res.text.trim();
  code = code.replace(/^```[\w]*\n?/, "").replace(/\n?```$/, "").trim();

  return {
    filename,
    content: code,
    language,
    description: purpose,
  };
}

// ── Step 3: Review and refine ─────────────────────────────────────────────
async function reviewCode(
  file: GeneratedFile,
  task: string,
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<GeneratedFile> {
  const prompt = `You are a senior code reviewer. Review this ${file.language} code for the task: "${task}"

Code:
\`\`\`${file.language}
${file.content.slice(0, 3000)}
\`\`\`

If the code is correct and complete, output it unchanged.
If there are bugs or improvements needed, output the corrected version.
Output raw code only — no markdown fences, no explanation.`;

  try {
    const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 2000 });
    let reviewed = res.text.trim();
    reviewed = reviewed.replace(/^```[\w]*\n?/, "").replace(/\n?```$/, "").trim();
    if (reviewed.length > 50) {
      return { ...file, content: reviewed };
    }
  } catch {
    // skip review on error
  }
  return file;
}

// ── Step 4: Generate explanation ─────────────────────────────────────────
async function generateExplanation(
  task: string,
  files: GeneratedFile[],
  ollamaUrl?: string,
  ollamaModel?: string
): Promise<string> {
  const fileList = files.map(f => `- **${f.filename}** (${f.language}): ${f.description}`).join("\n");
  const prompt = `You are Vulcan. Briefly explain what was built for this task.

Task: "${task}"
Files generated:
${fileList}

Write 2-3 sentences: what was built, how it works, how to use it. Be direct and technical.`;

  try {
    const res = await completeLLM(prompt, { ollamaUrl, ollamaModel, maxTokens: 200 });
    return res.text.trim();
  } catch {
    return `Generated ${files.length} file(s) for: ${task}`;
  }
}

// ── Step 5: Write files to disk ────────────────────────────────────────────
function writeFilesToDisk(files: GeneratedFile[], projectId?: number): string[] {
  const dir = projectId
    ? path.join(WORKSPACE_CODE_DIR, `project_${projectId}`)
    : path.join(WORKSPACE_CODE_DIR, `gen_${Date.now()}`);

  fs.mkdirSync(dir, { recursive: true });

  const writtenPaths: string[] = [];
  for (const file of files) {
    const filePath = path.join(dir, file.filename);
    fs.writeFileSync(filePath, file.content, "utf-8");
    writtenPaths.push(filePath);
  }

  return writtenPaths;
}

// ── Master Vulcan function ────────────────────────────────────────────────
export async function runVulcan(
  intent: VulcanIntent,
  options: { ollamaUrl?: string; ollamaModel?: string } = {}
): Promise<VulcanResult> {
  const startTime = Date.now();
  const { ollamaUrl, ollamaModel } = options;
  const memCtx = intent.memoryContext || "";

  // Find Vulcan agent
  const agents = storage.getAgents();
  const vulcan = agents.find(a => a.name === "Vulcan" || a.type === "coding");
  if (vulcan) storage.updateAgent(vulcan.id, { status: "active", lastActiveAt: new Date() });

  console.log(`[Vulcan] Starting: "${intent.task}"`);

  // 1. Plan
  console.log("[Vulcan] Step 1: Planning...");
  const plan = await planCoding(intent.task, intent.description, ollamaUrl, ollamaModel);
  console.log(`[Vulcan] Plan: ${plan.language}/${plan.framework}, ${plan.files.length} file(s)`);

  // 2. Generate each file
  console.log("[Vulcan] Step 2: Generating code...");
  const generatedFiles: GeneratedFile[] = [];
  for (const filePlan of plan.files) {
    const file = await generateFile(
      intent.task,
      intent.description,
      filePlan.filename,
      filePlan.purpose,
      plan.language,
      plan.framework,
      plan.files,
      memCtx,
      ollamaUrl,
      ollamaModel
    );
    generatedFiles.push(file);
  }

  // 3. Review first file (most important)
  console.log("[Vulcan] Step 3: Reviewing...");
  if (generatedFiles.length > 0) {
    generatedFiles[0] = await reviewCode(generatedFiles[0], intent.task, ollamaUrl, ollamaModel);
  }

  // 4. Explanation
  const explanation = await generateExplanation(intent.task, generatedFiles, ollamaUrl, ollamaModel);

  // 5. Write to disk
  let writtenPaths: string[] = [];
  if (intent.writeFiles !== false) {
    writtenPaths = writeFilesToDisk(generatedFiles, intent.projectId);
    console.log(`[Vulcan] Wrote ${writtenPaths.length} file(s) to disk`);
  }

  // 6. Store in SQLite
  const memoryIds: number[] = [];
  const fileIds: number[] = [];

  // Summary memory
  const mem = storage.createMemory({
    category: "semantic",
    type: "fact",
    title: `Vulcan generated: ${intent.task.slice(0, 60)}`,
    content: `${explanation}\n\nFiles: ${generatedFiles.map(f => f.filename).join(", ")}`,
    tags: JSON.stringify(["vulcan", "code", plan.language]),
    importance: 6,
    projectId: intent.projectId,
  });
  memoryIds.push(mem.id);

  // File records
  for (let i = 0; i < generatedFiles.length; i++) {
    const f = generatedFiles[i];
    const diskPath = writtenPaths[i] || f.filename;
    const fileRecord = storage.createFile({
      name: f.filename,
      path: diskPath,
      type: "code",
      mimeType: `text/${f.language}`,
      size: f.content.length,
      summary: f.description,
      tags: JSON.stringify([f.language, plan.framework, "vulcan"]),
      projectId: intent.projectId,
      indexed: true,
    });
    fileIds.push(fileRecord.id);
  }

  // Update agent
  if (vulcan) {
    storage.updateAgent(vulcan.id, {
      status: "idle",
      taskCount: vulcan.taskCount + 1,
      lastActiveAt: new Date(),
    });
  }

  console.log(`[Vulcan] Done in ${Date.now() - startTime}ms`);

  return {
    task: intent.task,
    language: plan.language,
    framework: plan.framework,
    files: generatedFiles,
    explanation,
    memoryIds,
    fileIds,
    durationMs: Date.now() - startTime,
    model: ollamaModel || "cloud",
  };
}
