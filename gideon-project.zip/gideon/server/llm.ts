/**
 * Gideon LLM Engine
 *
 * Provider priority:
 *   1. GLM-5.2  (Z.ai API — primary, OpenAI-compatible, $1.40/$4.40 per M tokens)
 *   2. Ollama   (local fallback — free, runs any local model)
 *   3. Anthropic Claude (cloud fallback — requires llm-api:website credential)
 *
 * Set GLM_API_KEY environment variable to activate GLM-5.2 as the primary provider.
 * When preferredModel is "glm/glm-5.2", the GLM provider is used.
 * Falls back automatically to Ollama if GLM_API_KEY is missing or call fails.
 */

import { storage } from "./storage";

export interface LLMMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface LLMStreamChunk {
  text: string;
  done: boolean;
  model?: string;
  tokensUsed?: number;
}

// ── Build system prompt with live memory context ──────────────────────────────
export function buildSystemPrompt(extraContext?: string): string {
  const memories = storage.getMemories({ category: "semantic" }).slice(0, 5);
  const procedural = storage.getMemories({ category: "procedural" }).slice(0, 3);
  const projects = storage.getProjects().filter(p => p.status === "active").slice(0, 3);
  const agents = storage.getAgents();

  const memoryBlock = memories.length > 0
    ? `\n\n## Semantic Memory (known facts)\n${memories.map(m => `- ${m.title}: ${m.content}`).join("\n")}`
    : "";

  const proceduralBlock = procedural.length > 0
    ? `\n\n## Procedural Memory (how things are done)\n${procedural.map(m => `- ${m.title}: ${m.content}`).join("\n")}`
    : "";

  const projectBlock = projects.length > 0
    ? `\n\n## Active Projects\n${projects.map(p => `- ${p.name}: ${p.description || "no description"} [stack: ${JSON.parse(p.stack || "[]").join(", ")}]`).join("\n")}`
    : "";

  const agentBlock = `\n\n## Available Agents\n${agents.map(a => {
    const caps = (() => { try { return JSON.parse(a.capabilities); } catch { return []; } })();
    return `- ${a.name} (${a.type}): ${caps.join(", ")} — model: ${a.model}`;
  }).join("\n")}`;

  const extra = extraContext ? `\n\n## Current Context\n${extraContext}` : "";

  return `You are Gideon, a personal AI operating system. You are not just an assistant — you are an intelligent runtime that reasons about tasks, manages memory, coordinates agents, and executes plans autonomously.

Your architecture:
- Gideon Core (you) — intent analysis, planning, decision-making
- Hermes Runtime — agent lifecycle and coordination
- Memory System — working, episodic, semantic, procedural, long-term
- Divisions — Research (Atlas), Coding (Vulcan), Automation (Mercury), Vision (Minerva)

When responding:
1. Analyze the user's intent thoroughly
2. Consider which agents are best suited
3. Build a concrete execution plan with numbered steps
4. Assess risk (0-10 scale: 0-4 auto, 5-7 confirm, 8-10 explicit approval)
5. Execute or explain exactly what you would do
6. Store important findings in memory

Be direct, technical, and precise. You speak like a mission control system — concise, structured, confident. Format plans with clear numbered steps. Use code blocks for any code or commands.${memoryBlock}${proceduralBlock}${projectBlock}${agentBlock}${extra}`;
}

// ── GLM-5.2 helpers ───────────────────────────────────────────────────────────
const GLM_BASE_URL = "https://open.bigmodel.cn/api/paas/v4";
const GLM_DEFAULT_MODEL = "glm-5.2";

export function isGLMModel(model: string): boolean {
  return model.startsWith("glm/") || model.startsWith("glm-");
}

export function resolveGLMModelId(model: string): string {
  return model.replace(/^glm\//, "");
}

export async function checkGLM(): Promise<{ available: boolean; apiKey: string | null }> {
  const apiKey = process.env.GLM_API_KEY || null;
  return { available: !!apiKey, apiKey };
}

export async function* streamGLM(
  messages: LLMMessage[],
  modelId: string = GLM_DEFAULT_MODEL,
  apiKey: string
): AsyncGenerator<LLMStreamChunk> {
  const resp = await fetch(`${GLM_BASE_URL}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: modelId,
      messages: messages.map(m => ({ role: m.role, content: m.content })),
      stream: true,
      max_tokens: 8192,
    }),
  });

  if (!resp.ok || !resp.body) {
    const errText = await resp.text().catch(() => resp.statusText);
    throw new Error(`GLM-5.2 API error: ${resp.status} — ${errText}`);
  }

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let totalTokens = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const lines = decoder.decode(value).split("\n").filter(l => l.startsWith("data: "));
    for (const line of lines) {
      const payload = line.slice(6).trim();
      if (payload === "[DONE]") {
        yield { text: "", done: true, model: modelId, tokensUsed: totalTokens };
        return;
      }
      try {
        const parsed = JSON.parse(payload) as {
          choices?: Array<{ delta?: { content?: string }; finish_reason?: string }>;
          usage?: { total_tokens?: number };
        };
        const delta = parsed.choices?.[0]?.delta?.content;
        if (delta) yield { text: delta, done: false, model: modelId };
        if (parsed.usage?.total_tokens) totalTokens = parsed.usage.total_tokens;
        if (parsed.choices?.[0]?.finish_reason === "stop") {
          yield { text: "", done: true, model: modelId, tokensUsed: totalTokens };
          return;
        }
      } catch { /* skip malformed SSE lines */ }
    }
  }
  yield { text: "", done: true, model: modelId, tokensUsed: totalTokens };
}

// ── Ollama helpers ────────────────────────────────────────────────────────────
export async function checkOllama(ollamaUrl: string): Promise<{ available: boolean; models: string[] }> {
  try {
    const resp = await fetch(`${ollamaUrl}/api/tags`, { signal: AbortSignal.timeout(3000) });
    if (!resp.ok) return { available: false, models: [] };
    const data = await resp.json() as { models?: { name: string }[] };
    return { available: true, models: (data.models || []).map((m: { name: string }) => m.name) };
  } catch {
    return { available: false, models: [] };
  }
}

export async function* streamOllama(
  messages: LLMMessage[],
  model: string,
  ollamaUrl: string
): AsyncGenerator<LLMStreamChunk> {
  const resp = await fetch(`${ollamaUrl}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model, messages, stream: true }),
  });
  if (!resp.ok || !resp.body) throw new Error(`Ollama error: ${resp.status} ${resp.statusText}`);

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    for (const line of decoder.decode(value).split("\n").filter(Boolean)) {
      try {
        const parsed = JSON.parse(line) as {
          message?: { content?: string };
          done?: boolean;
          eval_count?: number;
          prompt_eval_count?: number;
        };
        if (parsed.message?.content) {
          yield { text: parsed.message.content, done: parsed.done ?? false,
            tokensUsed: (parsed.eval_count || 0) + (parsed.prompt_eval_count || 0) };
        }
        if (parsed.done) return;
      } catch { /* skip */ }
    }
  }
}

// ── Anthropic helpers ─────────────────────────────────────────────────────────
export async function* streamAnthropic(
  messages: LLMMessage[],
  systemPrompt: string,
  model: string = "claude_sonnet_4_6"
): AsyncGenerator<LLMStreamChunk> {
  let Anthropic: typeof import("@anthropic-ai/sdk").default;
  try {
    const mod = await import("@anthropic-ai/sdk");
    Anthropic = mod.default;
  } catch {
    throw new Error("Anthropic SDK not available");
  }
  const client = new Anthropic();
  const userMessages = messages.filter(m => m.role !== "system");
  const stream = await client.messages.stream({
    model, max_tokens: 4096, system: systemPrompt,
    messages: userMessages.map(m => ({ role: m.role as "user" | "assistant", content: m.content })),
  });
  let totalTokens = 0;
  for await (const event of stream) {
    if (event.type === "content_block_delta" && event.delta.type === "text_delta")
      yield { text: event.delta.text, done: false, model };
    if (event.type === "message_delta" && event.usage) totalTokens = event.usage.output_tokens;
  }
  yield { text: "", done: true, model, tokensUsed: totalTokens };
}

// ── Master streaming function ─────────────────────────────────────────────────
//
// Chain: GLM-5.2 (if GLM_API_KEY set + model is glm/*) → Ollama → Anthropic
//
export async function* streamLLM(
  messages: LLMMessage[],
  options: {
    ollamaUrl?: string;
    ollamaModel?: string;
    fallbackModel?: string;
    extraContext?: string;
    systemPrompt?: string;
  } = {}
): AsyncGenerator<LLMStreamChunk & { source: "glm" | "ollama" | "anthropic" | "openai" }> {
  const ollamaUrl   = options.ollamaUrl   || "http://localhost:11434";
  const ollamaModel = options.ollamaModel || "llama3.2:3b";
  const systemPrompt = options.systemPrompt || buildSystemPrompt(options.extraContext);

  const fullMessages: LLMMessage[] = [
    { role: "system", content: systemPrompt },
    ...messages.filter(m => m.role !== "system"),
  ];

  // 1. GLM-5.2 ─────────────────────────────────────────────────────────────
  if (isGLMModel(ollamaModel)) {
    const glm = await checkGLM();
    if (glm.available && glm.apiKey) {
      const modelId = resolveGLMModelId(ollamaModel) || GLM_DEFAULT_MODEL;
      console.log(`[LLM] GLM-5.2 → ${modelId}`);
      try {
        for await (const chunk of streamGLM(fullMessages, modelId, glm.apiKey))
          yield { ...chunk, source: "glm" };
        return;
      } catch (err) {
        console.error("[LLM] GLM failed, falling back:", err);
      }
    } else {
      console.warn("[LLM] GLM_API_KEY not set — falling back to Ollama");
    }
  }

  // 2. Ollama ───────────────────────────────────────────────────────────────
  const ollamaCheck = await checkOllama(ollamaUrl);
  if (ollamaCheck.available) {
    const localModel = isGLMModel(ollamaModel)
      ? (ollamaCheck.models[0] || "llama3.2:3b")
      : (ollamaCheck.models.find(m => m.startsWith(ollamaModel.split(":")[0]))
          || ollamaCheck.models[0] || ollamaModel);
    console.log(`[LLM] Ollama → ${localModel}`);
    try {
      for await (const chunk of streamOllama(fullMessages, localModel, ollamaUrl))
        yield { ...chunk, source: "ollama" };
      return;
    } catch (err) {
      console.error("[LLM] Ollama failed, falling back:", err);
    }
  }

  // 3. Anthropic ────────────────────────────────────────────────────────────
  console.log(`[LLM] Anthropic → ${options.fallbackModel || "claude_sonnet_4_6"}`);
  try {
    for await (const chunk of streamAnthropic(messages, systemPrompt, options.fallbackModel || "claude_sonnet_4_6"))
      yield { ...chunk, source: "anthropic" };
    return;
  } catch (err) {
    console.error("[LLM] Anthropic failed:", err);
    throw new Error("All LLM providers unavailable. Set GLM_API_KEY, start Ollama, or check Anthropic credentials.");
  }
}

// ── Non-streaming completion ──────────────────────────────────────────────────
export async function completeLLM(
  prompt: string,
  options: {
    ollamaUrl?: string;
    ollamaModel?: string;
    systemOverride?: string;
    systemPrompt?: string;
    maxTokens?: number;
  } = {}
): Promise<{ text: string; source: string; tokensUsed: number }> {
  const messages: LLMMessage[] = [{ role: "user", content: prompt }];
  let fullText = "";
  let source = "unknown";
  let tokensUsed = 0;
  for await (const chunk of streamLLM(messages, options)) {
    fullText += chunk.text;
    source = chunk.source;
    if (chunk.tokensUsed) tokensUsed = chunk.tokensUsed;
  }
  return { text: fullText, source, tokensUsed };
}
